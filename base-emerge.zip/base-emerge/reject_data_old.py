import os
import datetime
from collections import OrderedDict
import string
from django.db.models import Q
from operator import itemgetter
from core.models import Application,InsurerApplication
import re
def reject_data(fdata,ins_fdata):
    
    #import pdb; pdb.set_trace()    
    #if match_name:
    #    reason = "First Name Testing failed %s for position %s" % (match_name.group(), str(match_name.span()))
    #    return (True, reason)

    #try:        
    #    if fdata.get('mobile_no').lower() in ['9999999999','9898989898','9892098920','9820098200','9892012345','9797979797','9696969696','9876543210','9090909090', '8800000000']:
    #        reason = "Mobile Number is blacklisted -----------------"
    #        return (True, reason)
    #except:
    #    reason = "Mobile Number does not exist"
    #    return (True, reason)



    # standard regular expression syntax
    # re.search(r"[!@#$%^&*()[]{};:,./<>?\|`~-=_+]", dob)


    try:      
        res_list = []
                               
        salutaion = fdata.get("salutaion") 
        if re.search(r"[~\!#@_\$%\^&\*\(\)\+{}\":;'\[\]0123456789]", salutaion) or len(salutaion)> 25:
                 res_list.append("salutaion")
                 
        first_name  = fdata.get("first_name")
        if not first_name.isalpha() or  len(first_name) > 25:
             res_list.append("first_name")
             
        
        father_name  = fdata.get("father_name")
        if len(father_name) > 0:

            if not father_name.isalpha() or  len(father_name) > 25:
                res_list.append("father_name")

     
        last_name  = fdata.get("last_name")
        if not last_name.isalpha() or  len(last_name)>25 :
            res_list.append("last_name")

        dob = fdata.get("dob")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";'\[\]]", dob):
            res_list.append("dob")

        birth_city  = fdata.get("birth_city")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", birth_city) or len(birth_city) >25:
            res_list.append("birth_city")
        

        birth_state = fdata.get("birth_state")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", birth_state) or len(birth_state) >25:
            res_list.append("birth_state")


        gender  = fdata.get("gender")
        if not gender.isalpha():
            res_list.append("gender")
        
        marital_status  = fdata.get("marital_status")
        if not marital_status.isalpha():
            res_list.append("marital_status")

        nationality  = fdata.get("nationality")
        if not nationality.isalpha():
            res_list.append("nationality")

        education = fdata.get("education")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]0147852369]", education):
            res_list.append("education")

        occupation = fdata.get("occupation")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0147852369]", occupation):
            res_list.append("occupation")

        employer_name = fdata.get("employer_name") 
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", employer_name) or len(employer_name) >25:
            res_list.append("employer_name")

      
        uid_no = fdata.get("uid_no")     
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", uid_no) or len(uid_no) >20:
                res_list.append("uid_no")
        

        illustration_uid = fdata.get("illustration_uid")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", illustration_uid) or len(illustration_uid) >50:
            res_list.append("illustration_uid")
            
        duty_nature = fdata.get("duty_nature")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",duty_nature) or len(duty_nature) >50:
            res_list.append("duty_nature")
            
        designation = fdata.get("designation")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'/'\[\]0123456789]",designation):
            res_list.append("designation")

        years_withemployer  = fdata.get("years_withemployer")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'/'\[\]a-zA-Z]",years_withemployer):
            res_list.append("years_withemployer")


        months_withemployer  = fdata.get("months_withemployer")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'/'\[\]a-zA-Z]",months_withemployer):
            res_list.append("months_withemployer")

                
        
        pan_no =  fdata.get("pan_no")
        if pan_no == "":
            pass
        elif not pan_no.isalnum(): 
            res_list.append("pan_no")

    
        # Some Special charactor are allowed   charactors ===   , . - / 
        # start here
        p_area = fdata.get("p_area")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",p_area) or len(p_area) >25:
            res_list.append("p_area")

        p_building = fdata.get("p_building")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",p_building) or len(p_building) >25:
            res_list.append("p_building")

        p_landmark = fdata.get("p_landmark")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",p_landmark) or len(p_landmark) >25:
            res_list.append("p_landmark")

    
        p_flat = fdata.get("p_flat")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",p_flat) or len(p_flat) >25:
            res_list.append("p_flat")


        road = fdata.get("road")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",road) or len(road) >25:
            res_list.append("road")

        area = fdata.get("area")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",area) or len(area) >25:
            res_list.append("area")

        building = fdata.get("building")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",building) or len(building) >25:
            res_list.append("building")

        landmark = fdata.get("landmark")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",landmark) or len(landmark) >25:
            res_list.append("landmark")


        flat = fdata.get("flat")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",flat) or len(flat) >25:
            res_list.append("flat")


        road = fdata.get("road")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]]",road) or len(road) >25:
            res_list.append("road")
    
        # end here
            
        p_state =  fdata.get("p_state")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]123456789]",p_state):
            res_list.append("p_state")

            
        p_city =  fdata.get("p_city")      
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]123456789]",p_city) or len(p_state) >25:
            res_list.append("p_city")

        
        state =  fdata.get("state")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]123456789]",state):
            res_list.append("state")


        city =  fdata.get("city")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;'\[\]123456789]",city) or len(state) >25:
            res_list.append("city")


        p_pincode =  fdata.get("p_pincode")
        if p_pincode  == "":
            pass
        elif not p_pincode.isdigit():
            res_list.append("p_pincode")


        pincode =  fdata.get("pincode")
        if pincode  == "":
            pass
        elif not pincode.isdigit():
            res_list.append("pincode")


        p_landline =  fdata.get("p_landline")
        if p_landline  == "":
            pass
        elif not p_landline.isdigit() or len(p_landline)>15:
            res_list.append("p_landline")

        landline =  fdata.get("landline")
        if landline  == "":
            pass
        elif not landline.isdigit() or len(landline)>15:
            res_list.append("landline")

        mobile_no =  fdata.get("mobile_no")
        if not mobile_no.isdigit() or len(mobile_no)>10:
            res_list.append("mobile_no")


        email_id = fdata.get("email_id")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", email_id) or len(email_id) >50:
            res_list.append("email_id")


        ir_emailid = fdata.get("ir_emailid")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", ir_emailid) or len(ir_emailid) >50:
            res_list.append("ir_emailid")

        ir_name =  fdata.get("ir_name")
        if ir_name  == "":
            pass
        elif not ir_name.isalpha():
            res_list.append("ir_name")

        eia_number =  fdata.get("eia_number")
        if eia_number  == "":
            pass
        elif not eia_number.isdigit() or len(eia_number)>14 :
            res_list.append("eia_number")


        nominee_title = fdata.get("nominee_title")
        if re.search(r"[~\!#@_\$%\^&\*\(\)\+{}\":;?'\[\]]", nominee_title) or len(nominee_title)> 25:
            res_list.append("nominee_title")
            
        
        nominee_first_name = fdata.get("nominee_first_name")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", nominee_first_name) or len(nominee_first_name) >25:
            res_list.append("nominee_first_name")
        
        nominee_last_name = fdata.get("nominee_last_name")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", nominee_last_name) or len(nominee_last_name) >25:
            res_list.append("nominee_last_name")

        nominee_relationship = fdata.get("nominee_relationship")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", nominee_relationship) or len(nominee_relationship) >25:
            res_list.append("nominee_relationship")

        nominee_dob = fdata.get("nominee_dob")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]]", nominee_dob) or len(nominee_dob) >25:
            res_list.append("nominee_dob")
    
        
        
        appointee_title = fdata.get("appointee_title")
        if re.search(r"[~\!#@_\$%\^&\*\(\)\+{}\":;?'\[\]]", appointee_title) or len(appointee_title)> 25:
            res_list.append("appointee_title")

        appointee_first_name = fdata.get("appointee_first_name")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", appointee_first_name) or len(appointee_first_name) >25:
            res_list.append("appointee_first_name")

        appointee_last_name = fdata.get("appointee_last_name")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", appointee_last_name) or len(appointee_last_name) >25:
            res_list.append("appointee_last_name")

        appointee_relationship = fdata.get("appointee_relationship")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", appointee_relationship) or len(appointee_relationship) >25:
            res_list.append("appointee_relationship")

        appointee_dob = fdata.get("appointee_dob")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]]", appointee_dob) or len(appointee_dob) >25:
            res_list.append("appointee_dob")

        # for prooof need to open some special charactor and numbers and also some some fields rdate and rupload are pending
        # forward / and single quote '  are allowd and numbers for address proof
        id_proof = fdata.get("id_proof")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,\[\]]", id_proof):
            res_list.append("id_proof")
                     
        
        address_proof = fdata.get("address_proof")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,\[\]]", address_proof):
            res_list.append("address_proof")
                     
        
        income_proof = fdata.get("income_proof")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,\[\]]", income_proof):
            res_list.append("income_proof")


        address_proof_upload = fdata.get("address_proof_upload")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", address_proof_upload):
            res_list.append("address_proof_upload") 
        
        age_proof_upload = fdata.get("age_proof_upload")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", age_proof_upload):
            res_list.append("age_proof_upload")

        income_proof_upload = fdata.get("income_proof_upload")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", income_proof_upload):
            res_list.append("income_proof_upload")


        # application details 
        app_id = fdata.get("app_id")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", app_id) or len(app_id) >15:
            res_list.append("app_id")
       
        
       
        # date format common for all 
        online_created_date = fdata.get("online_created_date")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", online_created_date):
            res_list.append("online_created_date")

        address_proof_rdate = fdata.get("address_proof_rdate")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", address_proof_rdate):
            res_list.append("address_proof_rdate")

        age_proof_rdate = fdata.get("age_proof_rdate")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", age_proof_rdate):
            res_list.append("age_proof_rdate")
            
        income_proof_rdate = fdata.get("income_proof_rdate")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", income_proof_rdate):
            res_list.append("income_proof_rdate")

        medicalappointment_date1 =  fdata.get("medicalappointment_date1")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", medicalappointment_date1):
            res_list.append("medicalappointment_date1")

        medicalappointment_date2 =  fdata.get("medicalappointment_date2")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", medicalappointment_date2):
            res_list.append("medicalappointment_date2")

        otp =  fdata.get("otp")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", otp):
            res_list.append("otp")


        otpfromdate =  fdata.get("otpfromdate")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", otpfromdate):
            res_list.append("otpfromdate")

        otptodate =  fdata.get("otptodate")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", otptodate):
            res_list.append("otptodate")

        transaction_end_time =  fdata.get("transaction_end_time")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-Z]", transaction_end_time):
            res_list.append("transaction_end_time")


        # Rider . allowed and alphanumric
        accidentaldeath = fdata.get("accidentaldeath")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", accidentaldeath):
            res_list.append("accidentaldeath")
         
        accidentaldeathpre = fdata.get("accidentaldeathpre")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", accidentaldeathpre):
            res_list.append("accidentaldeathpre")

            
        accidentalDeathAndBenefitPlus = fdata.get("accidentalDeathAndBenefitPlus")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", accidentalDeathAndBenefitPlus):
            res_list.append("accidentalDeathAndBenefitPlus")


        accidentalDeathAndBenefitPlusPre = fdata.get("accidentalDeathAndBenefitPlusPre")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", accidentalDeathAndBenefitPlusPre):
            res_list.append("accidentalDeathAndBenefitPlusPre")

        criticalillness = fdata.get("criticalillness")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", criticalillness):
            res_list.append("criticalillness")

        criticalillnesspre = fdata.get("criticalillnesspre")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", criticalillnesspre):
            res_list.append("criticalillnesspre")

        hospitalcareillness = fdata.get("hospitalcareillness")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", hospitalcareillness):
            res_list.append("hospitalcareillness")

        hospitalcareillnesspre = fdata.get("hospitalcareillnesspre")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", hospitalcareillnesspre):
            res_list.append("hospitalcareillnesspre")

        surgicalcare = fdata.get("surgicalcare")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", surgicalcare):
            res_list.append("surgicalcare")

        surgicalcarepre  = fdata.get("surgicalcarepre")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", surgicalcarepre):
            res_list.append("surgicalcarepre")


        product_category = fdata.get("product_category")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", product_category) or len(product_category) >25:
            res_list.append("product_category")


        annual_income = fdata.get("annual_income")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", annual_income):
            res_list.append("annual_income")

        annual_premium = fdata.get("annual_premium")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", annual_premium):
            res_list.append("annual_premium")
            
        pay_amount = fdata.get("pay_amount")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", pay_amount):
            res_list.append("pay_amount")

        total_premium_amount = fdata.get("total_premium_amount")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", total_premium_amount):
            res_list.append("total_premium_amount")


        insurance_purpose = fdata.get("insurance_purpose")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",insurance_purpose):
            res_list.append("insurance_purpose")

        interval = fdata.get("interval")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", interval):
            res_list.append("interval")        

        oneshotpayment = fdata.get("oneshotpayment")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",oneshotpayment):
            res_list.append("oneshotpayment")

        pay_status = fdata.get("pay_status")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",pay_status):
            res_list.append("pay_status")

        pay_type = fdata.get("pay_type")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",pay_type):
            res_list.append("pay_type")
        
        riderdisc = fdata.get("riderdisc")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", riderdisc):
            res_list.append("riderdisc")

        
        sum_assured= fdata.get("sum_assured")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", sum_assured):
            res_list.append("sum_assured")

        sumassured_type = fdata.get("sumassured_type")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]",sumassured_type):
            res_list.append("sumassured_type")


        term_period = fdata.get("term_period")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", term_period) or len(term_period)>10:
            res_list.append("term_period")


        # TRACKER DETAILS / SLASH removed and similar symbol removed in tracker details table
        tracker_campaign = fdata.get("tracker_campaign")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,'\[\]]", tracker_campaign):
            res_list.append("tracker_campaign")

        tracker_channel  = fdata.get("tracker_channel")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", tracker_channel):
            res_list.append("tracker_channel")
    
        tracker_details = fdata.get("tracker_details")
        if re.search(r"[@_\!#\$%\^&\*\(\)\+{}\":;,'\[\]]", tracker_details):
            res_list.append("tracker_details")

        tracker_id = fdata.get("tracker_id")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", tracker_id):
            res_list.append("tracker_id")

        tracker_source = fdata.get("tracker_source")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", tracker_source):
            res_list.append("tracker_source")

        # Tracker end here

        transaction_id = fdata.get("transaction_id")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", transaction_id):
            res_list.append("transaction_id")


        # Medical Question is any - YES and NO
        IsAdvisedOperation = fdata.get("IsAdvisedOperation")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsAdvisedOperation) or len(IsAdvisedOperation) >3:
            res_list.append("IsAdvisedOperation")


        IsAnemiadisorder = fdata.get("IsAnemiadisorder")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsAnemiadisorder) or len(IsAnemiadisorder) >3:
            res_list.append("IsAnemiadisorder")


        IsAnyDisease = fdata.get("IsAnyDisease")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsAnyDisease) or len(IsAnyDisease) >3:
            res_list.append("IsAnyDisease")

        IsAnyPhysicalDefect = fdata.get("IsAnyPhysicalDefect")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsAnyPhysicalDefect) or len(IsAnyPhysicalDefect) >3:
            res_list.append("IsAnyPhysicalDefect")

        IsDisorderOfEyes = fdata.get("IsDisorderOfEyes")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsDisorderOfEyes) or len(IsDisorderOfEyes) >3:
            res_list.append("IsDisorderOfEyes")


        IsKidneyDisorder = fdata.get("IsKidneyDisorder")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsKidneyDisorder) or len(IsKidneyDisorder) >3:
            res_list.append("IsKidneyDisorder")

        IsOnDiet = fdata.get("IsOnDiet")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsOnDiet) or len(IsOnDiet) >3:
            res_list.append("IsOnDiet")
    
        IsOtherIllness = fdata.get("IsOtherIllness")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsOtherIllness) or len(IsOtherIllness) >3:
            res_list.append("IsOtherIllness")


        IsUndergoingTreatment = fdata.get("IsUndergoingTreatment")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", IsUndergoingTreatment) or len(IsUndergoingTreatment) >3:
            res_list.append("IsUndergoingTreatment")


        # ANY PHYSICAL QUESTIONS START WITH - 0,2,3 AND YES OR NO AND LIMIT - 3

        any_complaints_not_consulted = fdata.get("any_complaints_not_consulted")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", any_complaints_not_consulted) or len(any_complaints_not_consulted) >3:
            res_list.append("any_complaints_not_consulted")

        any_gynaecological = fdata.get("any_gynaecological")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", any_gynaecological) or len(any_gynaecological) >3:
            res_list.append("any_gynaecological")

        any_medical_advice = fdata.get("any_medical_advice")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", any_medical_advice) or len(any_medical_advice) >3:
            res_list.append("any_gynaecological")

        any_physical_defects = fdata.get("any_physical_defects")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", any_physical_defects) or len(any_physical_defects) >3:
            res_list.append("any_physical_defects")

        
        height_feet = fdata.get("height_feet")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]",height_feet) or len(height_feet) >5:
            res_list.append("height_feet")

        height_inches = fdata.get("height_inches")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]",height_inches) or len(height_inches) >5:
            res_list.append("height_inches")
        
        weight_change = fdata.get("weight_change")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]",weight_change) or len(weight_change) >5:
            res_list.append("weight_change")

        weight = fdata.get("weight")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]",weight) or len(weight) >5:
            res_list.append("weight")

        physician_firstname = fdata.get("physician_firstname")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", physician_firstname) or len(physician_firstname) >25:
            res_list.append("physician_firstname")

        physician_lastname = fdata.get("physician_lastname")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", physician_lastname) or len(physician_lastname) >25:
            res_list.append("physician_lastname")


        physician_mobile =  fdata.get("physician_mobile")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", physician_mobile) or len(physician_mobile) >10:
            res_list.append("physician_mobile")


        physician_email = fdata.get("physician_email")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", physician_email) or len(physician_email) >50:
            res_list.append("physician_email")
    
        physician_officenumber = fdata.get("physician_officenumber")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", physician_officenumber) or len(physician_officenumber) >15:
            res_list.append("physician_officenumber")
                
        policy_cover = fdata.get("policy_cover")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", policy_cover):
            res_list.append("policy_cover") 

        politically_exposed = fdata.get("politically_exposed")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0123456789]", politically_exposed):
            res_list.append("politically_exposed") 
    
        politically_exposeddetails = fdata.get("politically_exposeddetails")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", politically_exposeddetails):
            res_list.append("politically_exposeddetails")

        premium_amount = fdata.get("premium_amount")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", premium_amount):
            res_list.append("premium_amount")

        premium_frequency = fdata.get("premium_frequency")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", premium_frequency):
            res_list.append("premium_frequency")

        smoker = fdata.get("smoker")
        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]0-9]", smoker):
            res_list.append("smoker")
        
        # Bp medical question list - alphanumric
        
        bp_list = ["bp_complications",
                "bp_consumetobacco",
                "bp_consumetobacco_details",
                "bp_firstnoticed",
                "bp_investigatedhypertension",
                "bp_investigatedhypertension_details",
                "bp_level",
                "bp_regulartreatment",
                "bp_regulartreatment_details",
                "bp_sufferdiabetes",
                "bp_treatmentdiscontinued",
                "bp_treatmentdiscontinued_details"
                ]

        for bp_row in bp_list:
            bplevel = fdata.get(bp_row)
            if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", bplevel):
                res_list.append(bp_row)
            
        # chest pain medical question - alphanumric
        chest_list = [
            "chestpain_bloodpressure",
            "chestpain_chestpain",
            "chestpain_heartattack",
            "chestpain_heartmurmur",
            "chestpain_highcholesterol"
            ]
            
        for chest_row in chest_list:            
            chestlevel = fdata.get(chest_row)
            if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", chestlevel):
                 res_list.append(chest_row)



        al_list = [ "consumed_alcohol",
                        "consumed_narcotic"]
        for alcol_row in al_list:
            alcol_level = fdata.get(alcol_row)
            if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]a-zA-Z]", alcol_level):
                 res_list.append(alcol_row)



        dbt_list = [
            "diabetes_albumin",
            "diabetes_cigarettessmoked",
            "diabetes_cigarettessmoked_details",
            "diabetes_control",
            "diabetes_doctorname",
            "diabetes_electrocardiogram",
            "diabetes_eyeabnormality",
            "diabetes_heartdisease",
            "diabetes_highbp",
            "diabetes_hospitalized",
            "diabetes_hospitalized_details",
            "diabetes_kidneyproblem",
            "diabetes_type",
            "diabetes_weightatdiagnosis",
            "diabetes_weightloss",
            "diabetes_weightloss_details"
            
            ]

        for db_row in dbt_list:
            db_level = fdata.get(db_row)
            if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", db_level):
                 res_list.append(db_row)

        # "diabetes_datediagnosed", "diabetes_doctorlastseen",- dATE FORMAT
        diabetes_datediagnosed = fdata.get("diabetes_datediagnosed")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";'\[\]]", diabetes_datediagnosed):
            res_list.append("diabetes_datediagnosed")

        diabetes_doctorlastseen = fdata.get("diabetes_doctorlastseen")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";'\[\]]", diabetes_doctorlastseen):
            res_list.append("diabetes_doctorlastseen")



        dizziness  = fdata.get("dizziness")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", dizziness):
            res_list.append("dizziness")

        pregnant  = fdata.get("pregnant")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", pregnant):
            res_list.append("pregnant")


        pregnant_details  = fdata.get("pregnant_details")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", pregnant_details):
            res_list.append("pregnant_details")

        premium_mode = fdata.get("premium_mode")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", premium_mode):
            res_list.append("premium_mode")

        prior_illness = fdata.get("prior_illness")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", prior_illness):
            res_list.append("prior_illness")

        prior_illnessdetails = fdata.get("prior_illnessdetails")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", prior_illnessdetails):
            res_list.append("prior_illnessdetails")

        remained_absent = fdata.get("remained_absent")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", remained_absent):
            res_list.append("remained_absent")


        suffered_list = [
            "suffered_albumin",
            "suffered_asthma",
            "suffered_cancer",
            "suffered_chestpain",
            "suffered_diabetic",
            "suffered_ulcer",
            "surgical_operation"
            ]

        for suffer_row in suffered_list:
            sufferlevel = fdata.get(suffer_row)
            if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", sufferlevel):
                 res_list.append(suffer_row)

        travel_outside = fdata.get("travel_outside")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", travel_outside):
            res_list.append("travel_outside")

        job_hazardous =  fdata.get("job_hazardous")
        if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", job_hazardous):
            res_list.append("job_hazardous")

            
        # if "medicalquestion_details"  array is present

        if len(fdata["medicalquestion_details"]) > 0:
            medical_dict = fdata["medicalquestion_details"]
           
            for medi_row in medical_dict:
                
                questiontype = medi_row["questiontype"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", questiontype):
                    res_list.append("Medical Question array - questiontype")
                
                exactdiagnosis = medi_row["exactdiagnosis"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", exactdiagnosis):
                    res_list.append("Medical Question array - exactdiagnosis")
                    
                doctordetails = medi_row["doctordetails"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", doctordetails):
                    res_list.append("Medical Question array - doctordetails")
                        
                dateofdiagnosis = medi_row["dateofdiagnosis"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", dateofdiagnosis):
                    res_list.append("Medical Question array - dateofdiagnosis")
                            
                dateoflastconsultation = medi_row["dateoflastconsultation"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", dateoflastconsultation):
                    res_list.append("Medical Question array - dateoflastconsultation")
        
        # if "family_medicalquestion_details"  array is present
                    
        if len(fdata["familymedicalhistory_details"]) > 0:
            family_medical_dict = fdata["familymedicalhistory_details"]
    
            for family_medi_row in family_medical_dict:
       
                membertype = family_medi_row["membertype"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", membertype):
                    res_list.append("Family Medical Question array - membertype")

                deathcause = family_medi_row["deathcause"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", deathcause):
                    res_list.append("Family Medical Question array - deathcause")

                stateofhealth = family_medi_row["stateofhealth"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", stateofhealth):
                    res_list.append("Family Medical Question array - stateofhealth")

                agedeath  = family_medi_row["agedeath"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", agedeath):
                    res_list.append("Family Medical Question array - agedeath")

                ageliving = family_medi_row["ageliving"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", ageliving):
                    res_list.append("Family Medical Question array - ageliving")


        # recent level array

        if len(fdata["recent_bplevel"]) > 0:
            recent_level_dict = fdata["recent_bplevel"]

            for recent_level_row in recent_level_dict:
                
                bprecentleveldate = recent_level_row["bprecentleveldate"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", bprecentleveldate):
                    res_list.append("Recent level array array - bprecentleveldate")

                bprecentlevel = recent_level_row["bprecentlevel"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", bprecentlevel):
                    res_list.append("Recent level array array - bprecentlevel")

                    
        # diabetes measurement array - 
        if fdata["diabetessugarmeasurement"] >0:
            dia_sugar_dict =fdata["diabetessugarmeasurement"]

            for sugar_row in dia_sugar_dict:

                diabetes_hba1cmeasuredate = sugar_row["diabetes_hba1cmeasuredate"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", diabetes_hba1cmeasuredate):
                    res_list.append("diabetes suagar array - diabetes_hba1cmeasuredate")


                diabetes_measurementsbloodsugarlevel = sugar_row["diabetes_measurementsbloodsugarlevel"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", diabetes_measurementsbloodsugarlevel):
                    res_list.append("diabetes suagar array - diabetes_measurementsbloodsugarlevel")

                diabetes_measurementsdatetaken = sugar_row["diabetes_measurementsdatetaken"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\";,'\[\]a-zA-z]", diabetes_measurementsdatetaken):
                    res_list.append("diabetes suagar array - diabetes_measurementsdatetaken")

                diabetes_hba1cmeasurelevel = sugar_row["diabetes_hba1cmeasurelevel"]
                if re.search(r"[@_~\!#\$%\^&\*\(\)\+{}\":;,/'\[\]]", diabetes_hba1cmeasurelevel):
                    res_list.append("Medical Question array - diabetes_hba1cmeasurelevel")

        # diabetes control array pending
        
        # Insurer Validation - 
        try:
            ins_salutaion = ins_fdata.get("ins_salutaion")
            if re.search(r"[~\!#@_\$%\^&\*\(\)\+{}\":;'\[\]0123456789]", ins_salutaion) or len(ins_salutaion)> 25:
                res_list.append("ins_salutaion")
        except Exception as e:
            print "Invalid Insurer JSON"



        if res_list:
            return (True, res_list)
               
    except Exception as  e:
        res_list = "Invalid JSON - proposer",e
        print e
        return (True,res_list)

    return (False, "")
        
    
    # start here - special charactor remove project - vapt
    #try:
    #    dump = fdata.copy()

        #list1 = ["tracker_details",
        #         "medicalquestion_details",
        #         "online_created_date",
        #         "familymedicalhistory_details",
        #         "diabetescontrol_details",
        #         "recent_bplevel",
        #         "diabetes_datediagnosed",
        #         "diabetessugarmeasurement",
        #         "diabetes_doctorlastseen"]

        #for rm in list1:
        #            del(dump[rm])

        #for k,v in  dump.items():
        #        if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;'\[\]]", str(v)):
        #            print "special charactor present in Dict %s",str(k)
        #            reason =  "special charactor present in EMERGE  Input Json %s" % (str(k))
        #            return (True,reason)

    #except:
    #   reason = "Special Charactor present"
    #   return (True,reason)

    
    #import simplejson

    # insurer  Json logic VAPT
    #if insurer != "":
    #    try:
    #        ins_dump = simplejson.loads(insurer)

    #        ins_dumpdata = ins_dump.copy()
    #        ins_list = ["ins_tracker_details",
    #                    "ins_medicalquestion_details",
    #                    "ins_online_created_date",
     #                   "ins_familymedicalhistory_details",
    #                    "ins_diabetescontrol_details",
    #                    "ins_recent_bplevel",
     #                   "ins_diabetes_datediagnosed",
      #                  "ins_diabetessugarmeasurement",
       #                 "ins_diabetes_doctorlastseen"]

     #       for ins_remove in ins_list:
     #           del(ins_dumpdata[ins_remove])

     #       for ins_key,ins_value in  ins_dumpdata.items():
     #           if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;'\[\]]", str(ins_value)):
     #               print "special charactor present in Dict %s",str(ins_key)
     #               reason =  "special charactor present in LMS Insurer Input Json %s" % (str(ins_key))
     #               return (True,reason)

     #   except:
     #       reason = "Special Charactor present in Insurer Json header"
     #       return (True,reason)


    # end here VAPT remove specail charactor project



