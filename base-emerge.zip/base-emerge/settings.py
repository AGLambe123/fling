# Django settings for BSLI project.
from logging.handlers import TimedRotatingFileHandler
import sys
import os
from path import path

SETTINGS_FILE_FOLDER = path(__file__).parent.abspath()
REPO_FOLDER = path(__file__).parent.parent.parent.abspath() 
sys.path.append(SETTINGS_FILE_FOLDER.joinpath("../libs").abspath())
WHITELISTED_IPS = []

# PBZ VAPT 179
DEBUG = False
# end here

DEBUG_PROPAGATE_EXCEPTIONS=True
TEMPLATE_DEBUG = DEBUG
INTERNAL_IPS = ("127.0.0.1", "localhost")
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
USE_THOUSAND_SEPARATOR = True

#mysql -uemerge -pc9c178eb -h presales.glitterbug.in
#LMS_HOST = 'presales.glitterbug.in'
#LMS_USER = 'emerge'
#LMS_PASSWORD = 'c9c178eb'
#LMS_NAME = 'bsli'

LMS_HOST = 'localhost'
LMS_USER = 'root'
LMS_PASSWORD = 'asd'
LMS_NAME = 'lms'

SERVER_NAME = "localhost"

ADMINS = (
    ("Devendra K Rane", "ranedk@gmail.com"),
    ("Nikhil Subramanian", "nikhil.subramanian@birlasunlife.com"),
    ("Amardeep Mann", "amardeep.mann@birlasunlife.com"),
)
MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'emerge',                      # Or path to database file if using sqlite3.
        'USER': 'root',                      # Not used with sqlite3.
        'PASSWORD': 'admin@0101',                  # Not used with sqlite3.
        'HOST': '',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

# Hosts/domain names that are valid for this site; required if DEBUG is False
# See https://docs.djangoproject.com/en/1.5/ref/settings/#allowed-hosts

# allowed host commented for pbz vapt  - django debug = false ID - 179 
#ALLOWED_HOSTS = [] 

# end here
# new added PBZ - VAPT ID - 179
ALLOWED_HOSTS = ["https://docs.djangoproject.com/en/1.5/ref/settings/",'10.155.1.233','127.0.0.1','localhost']

#end here

BROKER_HOST = "localhost"
BROKER_PORT = 5672
BROKER_USER = "guest"
BROKER_PASSWORD = "guest"
BROKER_VHOST = "/"
# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'Asia/Calcutta'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
MEDIA_ROOT = os.path.join(SETTINGS_FILE_FOLDER,'../static')
STATIC_PATH = '/static'
SITE_NAME = 'www.example.com'
SITE_URL = 'http://10.155.1.17:81'

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = '/static/'

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
ADMIN_MEDIA_PREFIX = '/media/'
STATIC_URL = '/media/'

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'w%_%(hu!pfu*99i%$^*($%#@#%@23423343@#&*)!m8nwoez59n0'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.load_template_source',
    'django.template.loaders.app_directories.load_template_source',
)

MIDDLEWARE_CLASSES = (
    #'utils.RestrictMiddleware',
    'django.middleware.cache.UpdateCacheMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.middleware.gzip.GZipMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.cache.FetchFromCacheMiddleware',
    'session_security.middleware.SessionSecurityMiddleware',
)

ROOT_URLCONF = 'urls'

TEMPLATE_DIRS = (
   SETTINGS_FILE_FOLDER.joinpath("templates"),
)


TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)


INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.admin',
    'django.contrib.admindocs',
    'django.contrib.messages',
    'django.contrib.humanize',
    'django.contrib.staticfiles',

    'gunicorn',
    'widget_tweaks',
    'core',
    'south',
    'session_security',
)

SESSION_SECURITY_EXPIRE_AFTER=900
SESSION_SECURITY_WARN_AFTER=840

TEMPLATE_CONTEXT_PROCESSORS = (
    "django.contrib.auth.context_processors.auth",
    "django.core.context_processors.debug",
    "django.core.context_processors.i18n",
    "django.contrib.messages.context_processors.messages",
    "django.core.context_processors.request",
    "utils.context_processor",
)

#SERIALIZATION_MODULES = { 'modeljson' : 'modelserializer.json' }

# python -m smtpd -n -c DebuggingServer localhost:1025
DEFAULT_FROM_EMAIL = "customer.support@birlasunlife.com"
if DEBUG:
#    EMAIL_HOST = 'localhost'
    EMAIL_HOST = '10.155.1.73'
else:
    EMAIL_HOST = "10.155.1.73"
EMAIL_HOST_PASSWORD = ''
#EMAIL_HOST_USER = 'customer.support@birlasunlife.com'
EMAIL_HOST_USER = ''
EMAIL_PORT = '25'
EMAIL_USE_TLS = False

LOGFILE = os.path.join(REPO_FOLDER, 'logs/bsliemerge/bsli.log')
DRLOG_HANDLER = TimedRotatingFileHandler(LOGFILE, when='D', interval=1, backupCount=0, encoding=None, delay=False, utc=False)
DRLOG_APP_NAME = 'BSLI'

try:
    from local_settings import *
    print "Loading from local settings"
except ImportError: 
    pass
