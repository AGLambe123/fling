from django.db import models

from django.contrib.auth.models import User
from customdb.uuidfield import UUIDField
from utils import get_image_path

import re

#6109
from django.contrib.auth.signals import user_logged_in
from django.contrib.sessions.models import Session

from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect


def user_logged_in_handler(sender, request, user, **kwargs):
    try:
        UserSession.objects.get_or_create(
            user = user,
        session_id = request.session.session_key
        )
    except IntegrityError as e:
        return HttpResponseRedirect('/accounts/login')

user_logged_in.connect(user_logged_in_handler)

def delete_user_sessions(user):
    user_sessions = UserSession.objects.filter(user = user)
    for user_session in user_sessions:
        user_session.session.delete()
#6109

BASE_PLAN_MAP = {
    'id' : 'Protect@Ease'
    
}

USER_ROLES = (
    ('CALLCENTER', 'CALLCENTER'),
    ('REPORT', 'REPORT'),
    ('MANAGER', 'MANAGER'),
    ('UPLOAD', 'UPLOAD'),
    ('COURIER', 'COURIER'),
    ('COURIER_REP', 'COURIER_REP'),
    ('REVIEWER', 'REVIEWER'),
    ('UHC', 'UHC'),
    ('NEW_TELECALLER', 'NEW_TELECALLER'),
    ('AFFILIATE', 'AFFILIATE'),
    ('AFFILIATE_ADMIN', 'AFFILIATE_ADMIN'),
    ('UHCREPORT', 'UHCREPORT'),
    ('EMERGE','EMERGE'), #newly added 17th may 2016
)

ORGANISATION = (
    ('ENSER','Enser'),
    ('GLITTERBUG','Glitterbug'),
    ('ICICIPRU','ICICI Prudential'),
)

AUTO_NOTES = (
    ('','-------------'),
    ('DA_NOT_ASSIGNED','Doctor not assigned'),
    ('DA_CHANGE','Customer wants to change doctor'),
    ('THIRD_PARTY_DECLINE', 'Third Party Payment Decline'),
    ('POLICY_CHANGE','Customer wants to change policy'),
    ('MONEY_BACK','Customer wants his money back'),
    ('SMS_TRIGGERED','SMS triggered call'),
    ('DOCS_SENT','Document sent and not received > 3 days'),
    ('MEDICALS_COMPLETED','Medicals completed and not received > 5 days'),
    ('DOCS_NOT_AVAILABLE', 'Not Interested - documents not available'),
    ('MEDICALS_NOT_WANTED', 'Not Interested - does not want to do the medicals'),
    ('UNHAPPY_XRT_COFF', 'Not Interested - not happy with XRT / COFF'),
    ('NOT_INTERESTED_OTHERS', 'Not Interested - Others'),
)

DISPOSITIONS = (
    ('', '------------'),
    ('SUCCESS', 'Successfully Completed'),
    ('CALLBACK', 'Call Customer Later'),
    ('RINGING', 'Ringing - No Response'),
    ('BUSY', 'Busy - No Response'),
    ('UNREACHABLE', 'Unreachable - No Response'),
    ('DO_NOT_CALL', 'Never Call Again'),
    ('CALL_DROPPED', 'Call Dropped'),
)

CALL_TYPE = (
    ('F', 'Fresh'),
    ('W', 'Welcome'),
    ('WV', 'Welcome and Verification'),
    ('V', 'Verification'),
    ('R' ,'Reminder'),
    ('TI' ,'Thank in-progress'),
    ('TF' ,'Thanks final'),
    ('TF-AUTO' ,'System Disposed : Thanks final'),
)

APP_STATUS = (
    ('IF', 'Issued'),
    ('DC', 'Declined'),
    ('WD', 'Withdrawn'),
    ('FL', 'Withdrawn'),
    ('PO', 'Postpone'),
    ('PS', 'Proposal'),
    ('LA', 'Lapsed'),
    ('PU', 'Paid Up'),
)

PHOTO_ID_PROOF_CHOICES = (
    ('', '--------------'),
    ("bank certificate", "bank certificate"),
    ("telephone bills (not older than 6 months)", "telephone bills (not older than 6 months)"),
    ("bank account statement (not older than 6 months)", "bank account statement (not older than 6 months)"),
    ("electricity bill", "electricity bill"),
    ("ration card", "ration card"),
    ("lease agreement + rent recipt (not older than 3 months)", "lease agreement + rent recipt (not older than 3 months)"),
    ("mobile bills( not older than 6 months)", "mobile bills( not older than 6 months)"),
    ("employer's certificate", "employer's certificate"),
    ("all utility bills", "all utility bills"),
    ("document unknown/not acceptable", "document unknown/not acceptable"),
    ("passport", "passport"),
    ("driving licence", "driving licence"),
    ("not applicable", "not applicable"),
    ("insurers employee certificate", "insurers employee certificate"),
    ("letter fom recognised public authority/servant", "letter fom recognised public authority/servant"),
    ("voter's identity card", "voter's identity card"),
    ("adhar card", "adhar card"),
    ("domicile certificate", "domicile certificate"),
    ("esic card with address", "esic card with address"),
    ("property tax document", "property tax document"),
    ('NR', 'Not required'),
)

AGE_PROOF_CHOICES = (
    ('', '--------------'),
    ("school/college certificate", "school/college certificate"),
    ("municipal birth certificate", "municipal birth certificate"),
    ("baptism or marriage certificate", "baptism or marriage certificate"),
    ("passport", "passport"),
    ("govt employment certificate", "govt employment certificate"),
    ("domicile certificate", "domicile certificate"),
    ("military record", "military record"),
    ("prev policies with std age proof", "prev policies with std age proof"),
    ("pan card", "pan card"),
    ("government id card", "government id card"),
    ("1 year old driving license", "1 year old driving license"),
    ("court affidavit from kerala government", "court affidavit from kerala government"),
    ("lic document", "lic document"),
    ("nursing hospital certificate/discharge card if minor is below 5 yrs", "nursing hospital certificate/discharge card if minor is below 5 yrs"))

ADDRESS_PROOF_CHOICES = (
    ('', '--------------'),
    ("aadhar card", "aadhar card"),
    ("bank certificate", "bank certificate"),
    ("driving licence", "driving licence"),
    ("document unknown/ not acceptable", "document unknown/ not acceptable"),
    ("employer's certificate", "employer's certificate"),
    ("esic card with photograph", "esic card with photograph"),
    ("insurer's employee certificate", "insurer's employee certificate"),
    ("letter fom recognised public authority/servant", "letter fom recognised public authority/servant"),
    ("ppf a/c with photograph", "ppf a/c with photograph"),
    ("pio card with photograph", "pio card with photograph"),
    ("passport", "passport"),
    ("voter's identity card", "voter's identity card"),
    ('NR','Not required'),
)

INCOME_PROOF_CHOICES = (
    ('', '--------------'),
    ("agricultural income certificate", "agricultural income certificate"),
    ("agricultural-land details & income assessments", "agricultural-land details & income assessments"),
    ("bank cash-flows statements transactions not older then 6 months", "bank cash-flows statements transactions not older then 6 months"),
    ("chartered accountant's certificate", "chartered accountant's certificate"),
    ("pass-book with regular cash flow statement", "pass-book with regular cash flow statement"),
    ("salary slip /form 16", "salary slip /form 16"),
    ("audited company accounts", "audited company accounts"),
    ("audited firm accounts and partnership", "audited firm accounts and partnership"),
    ("employer's certificate for income", "employer's certificate for income"),
    ("income tax assessment orders/income tax returns", "income tax assessment orders/income tax returns"),
    ("khatha papers (sath bara utara)", "khatha papers (sath bara utara)"),
    ("deeds to property", "deeds to property"),
    ("document unknown/ not acceptable", "document unknown/ not acceptable"),
    ('NR', 'Not required'),
)

DOCUMENT_DELIVERY_CHOICES = (
    ('SELF_COURIER', 'Self Courier'),
    ('EMAIL', 'Email buyonline'),
    ('UPLOAD', 'upload on site'),
    ('SUBMIT_AT_BRANCH', 'Submit At Branch'),
    ('PROVIDE_COURIER', 'Provide Courier'),
)

PREMIUM_FREQUENCY= (
    ('annual', 'annual'),
    ('monthly', 'monthly'),
    
)




class ServicableCourierPincode(models.Model):
    pin = models.IntegerField(primary_key=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.pin

class Plan(models.Model):
    code = models.CharField(max_length=200)
    name = models.CharField(max_length=200)

    def __str__(self):
        return

class CallPriority(models.Model):
    call_later = models.IntegerField(null=True, blank=True)
    fresh = models.IntegerField(null=True, blank=True)
    welcome = models.IntegerField(null=True, blank=True)
    welcome_and_verification = models.IntegerField(null=True, blank=True)
    verification = models.IntegerField(null=True, blank=True)
    reminder = models.IntegerField(null=True, blank=True)
    thankinprogress = models.IntegerField(null=True, blank=True)

class Mecode(models.Model):
    me_code = models.CharField(max_length=200)
    me_name = models.CharField(max_length=200)
    type = models.CharField(max_length=200, choices=(('Individual','Individual'),('Institution','Institution')))
    address1 = models.CharField(max_length=200)
    address2 = models.CharField(max_length=200, blank=True)
    address3 = models.CharField(max_length=200, blank=True)
    address4 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    phone1 = models.CharField(max_length=200, blank=True)
    phone2 = models.CharField(max_length=200, blank=True)
    mobileno = models.CharField(max_length=200, blank=True)
    emailid = models.CharField(max_length=200, blank=True)
    contact_person = models.CharField(max_length=200, blank=True)
    ownership = models.CharField(max_length=200, blank=True)
    pan = models.CharField(max_length=200, blank=True)
    mode_of_payment = models.CharField(max_length=200)
    account = models.CharField(max_length=200, blank=True)
    bank_name = models.CharField(max_length=200, blank=True)
    payor_name = models.CharField(max_length=200, blank=True)
    rating = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.me_code

class UserProfile(models.Model):
    user = models.OneToOneField(User)
    role = models.CharField(max_length=100, choices=USER_ROLES, blank=True)
    phone = models.CharField(max_length=10, blank=True)
    organization = models.CharField(max_length=100, blank=True)
    job_title = models.CharField(max_length=100, blank=True)
    network_id = models.CharField(max_length=100, blank=True)
    activation_key = models.CharField(max_length=40, blank=True)
    aspect_username = models.CharField(max_length=100, blank=True)
    def __str__(self):
        return self.user.username

class CallHistory(models.Model):
    application = models.ForeignKey('Application')
    created_on = models.DateTimeField(auto_now_add=True)
    disposition = models.CharField(max_length=150, choices=DISPOSITIONS)
    call_type = models.CharField(max_length=150, choices=CALL_TYPE)
    is_success = models.BooleanField(default=True)
    next_calltime = models.DateTimeField(blank=True, null=True)
    priority = models.IntegerField(blank=True, null=True)
    assigned_to = models.ForeignKey(User, null=True, blank=True)
    remarks = models.TextField(blank=True)
    predefined_remark = models.CharField(max_length=150, choices=AUTO_NOTES, blank=True)
    is_call_later = models.BooleanField(default=False)
    aspectcall_start_date = models.DateTimeField(null=True, blank=True)#5896-aspect data                                                            
    aspectcall_end_date = models.DateTimeField(null=True, blank=True)#5896                                                                           
    aspectcall_duration= models.CharField(max_length=30, blank=True)#5896                                                                            
    aspectcall_created_on = models.DateTimeField(null=True, blank=True)#5896
    aspectcall_dialflag = models.CharField(max_length=30, blank=True)#5896                                                                           
    def __str__(self):
        return

#TODO: Can write a sanity check algorithm which makes sure that all applications are pickable at any given point of time
class ApplicationCallAttribute(models.Model):
    application = models.OneToOneField('Application')
    contract_id = models.TextField(blank=True)
    mecode = models.ManyToManyField('Mecode', blank=True, null=True)
    is_uhc = models.BooleanField(default=False)

    address1 = models.TextField(blank=True)
    p_address1 = models.TextField(blank=True)
    courier_date = models.DateField(null=True, blank=True)
    courier_time = models.CharField(max_length=100,blank=True)
    fup_commited_date = models.DateField(null=True, blank=True)
    document_commited_date = models.DateField(null=True, blank=True)

    created_on = models.DateTimeField(auto_now_add=True)
    #Documents
    photo_id_proof = models.CharField(max_length=200, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    age_proof = models.CharField(max_length=200, choices=AGE_PROOF_CHOICES, blank=True)
    address_proof = models.CharField(max_length=200, choices=ADDRESS_PROOF_CHOICES, blank=True)
    income_proof = models.CharField(max_length=200, choices=INCOME_PROOF_CHOICES, blank=True)
    attested_photograph = models.BooleanField(default=False)
    #Document extra data
    photo_id_proof_rcvd = models.CharField(max_length=200, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    age_proof_rcvd = models.CharField(max_length=200, choices=AGE_PROOF_CHOICES, blank=True)
    address_proof_rcvd = models.CharField(max_length=200, choices=ADDRESS_PROOF_CHOICES, blank=True)
    income_proof_rcvd = models.CharField(max_length=200, choices=INCOME_PROOF_CHOICES, blank=True)
    attested_photograph_rcvd = models.BooleanField(default=False, verbose_name="Photograph rcvd")
    document_delivery_method_used = models.CharField(max_length=200, choices=DOCUMENT_DELIVERY_CHOICES, blank=True)
    document_remarks = models.TextField(blank=True)
    #Document recieved status
    photo_id_proof_rcvd_date = models.DateField(null=True, blank=True)
    age_proof_rcvd_date = models.DateField(null=True, blank=True)
    address_proof_rcvd_date = models.DateField(null=True, blank=True)
    income_proof_rcvd_date = models.DateField(null=True, blank=True)
    attested_photograph_rcvd_date = models.DateField(null=True, blank=True)
    if_courier_servicable = models.BooleanField(default=False)
    document_delivery_method = models.CharField(max_length=200, choices=DOCUMENT_DELIVERY_CHOICES, blank=True)

    #Call logic parameters
    is_fup_closed = models.BooleanField(default=False)
    last_fup_received_on = models.DateField(null=True, blank=True)
    app_status = models.CharField(max_length=150, choices=APP_STATUS)
    app_status_reason = models.CharField(max_length=255, blank=True)
    last_call_status = models.CharField(max_length=150, choices=CALL_TYPE) #Always update to latest call type of history, If call_type is TF,make call_barred=True
    is_taken = models.BooleanField(default=False) #Always set before giving it to caller and unset when closing disposition
    assigned_to = models.ForeignKey(User, null=True, blank=True) #Always set before giving it to caller and unset when closing disposition
    call_barred = models.BooleanField(default=False) #Set is to True if no calls should be made ever
    next_calltime = models.DateTimeField(blank=True, null=True) #always set this some value, never leave it null
    is_call_later = models.BooleanField(default=False)
    is_ats_uploaded = models.BooleanField(default=False)
    airway_bill_no = models.CharField(max_length=250, blank=True)
    courier_company_name = models.CharField(max_length=250, blank=True)
                           
                                                                   
                                                                               
                                                                              
      
    def __str__(self):
        return str(self.application)

class AppStatus(models.Model):
    name = models.CharField(max_length=10)
    description = models.TextField()

    def __str__(self):
        return self.name

class FupAssociated(models.Model):
    code = models.ForeignKey('FUP')
    generated_on = models.DateField(blank=True, null=True)
    received_on = models.DateField(blank=True, null=True)
    jet_decision = models.CharField(max_length=100, blank=True)
    reqt_desc_text = models.CharField(max_length=200, blank=True)
    order_status = models.CharField(max_length=100, blank=True)
    med_indicator = models.CharField(max_length=10, blank=True)
    def __str__(self):
        return self.code.name

INTERNAL_FUP_LIST = ['IRU','CAN','MED','GMI','FLW','CUW','RKI','IMR']
class FUP(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    is_medical = models.BooleanField(default=False)

    def __str__(self):
        return self.name


#Match status will tell the status of the claim
MATCH_STATUS =  (
    ('FREE_CLAIM', 'FREE_CLAIM'),
    ('CLAIM_NOTFOUND', 'CLAIM_NOTFOUND'),  #Wrong Application ID
    ('CLAIM_FOUND_PAYMENT_NOT_MADE', 'CLAIM_FOUND_PAYMENT_NOT_MADE'), #Application ID Found but number is incorrect
    ('CLAIM_FOUND_NUMBER_INCORRECT', 'CLAIM_FOUND_NUMBER_INCORRECT'), #Application ID Found but number is incorrect
    ('CLAIM_FOUND_EMAIL_INCORRECT', 'CLAIM_FOUND_EMAIL_INCORRECT'), #Application ID Found but email is incorrect
    ('CLAIM_REJECTED_BAD_PAYMENT_DATE', 'CLAIM_REJECTED_BAD_PAYMENT_DATE'), #Claim rejected because payment date is fradulent
    ('CLAIM_REJECTED_ALREADY_CLAIMED_GENUINE', 'CLAIM_REJECTED_ALREADY_CLAIMED_GENUINE'), # Claim already done by someone else, though it looks GENUINE
    ('CLAIM_REJECTED_ALREADY_CLAIMED_FRAUD', 'CLAIM_REJECTED_ALREADY_CLAIMED_FRAUD'), # Claim already done by someone else and this looks FRAUD
    ('CLAIM_REJECTED_ALREADY_DUPLICATED', 'CLAIM_REJECTED_ALREADY_DUPLICATED'), # Claim duplicated by same affiliate
    ('CLAIM_FOUND', 'CLAIM_FOUND'),

    ('CLAIM_MOBILE_MATCH_NAME_INCORRECT', 'CLAIM_MOBILE_MATCH_NAME_INCORRECT'),
    ('CLAIM_MOBILE_REJECTED_ALREADY_CLAIMED_GENUINE', 'CLAIM_MOBILE_REJECTED_ALREADY_CLAIMED_GENUINE'), # Claim already done by someone else, though it looks GENUINE
    ('CLAIM_MOBILE_REJECTED_ALREADY_CLAIMED_FRAUD', 'CLAIM_MOBILE_REJECTED_ALREADY_CLAIMED_FRAUD'), # Claim already done by someone else and this looks FRAUD
    ('CLAIM_MOBILE_REJECTED_MOBILE_INCORRECT', 'CLAIM_MOBILE_REJECTED_MOBILE_INCORRECT'),
    ('CLAIM_MOBILE_FOUND', 'CLAIM_MOBILE_FOUND'),
)
class SaleClaim(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255, blank=True)
    email = models.EmailField(max_length=255, blank=True)
    mobile = models.CharField(max_length=255)
    premium = models.CharField(max_length=255, blank=True)
    first_call_date = models.DateTimeField()
    last_call_date = models.DateTimeField()
    app_id = models.CharField(max_length=255, blank=True, db_index=True)
    campaign_id = models.CharField(max_length=100, blank=True)
    sem = models.CharField(max_length=100, blank=True)
    debug_log = models.TextField(blank=True)

    associated_applications = models.ManyToManyField('Application', null=True, blank=True)
    disposition = models.CharField(max_length=255, blank=True)
    created_on = models.DateTimeField(auto_now_add=True)
    match_status = models.CharField(max_length=200, choices=MATCH_STATUS, blank=True)
    user = models.ForeignKey(User)
    organization = models.CharField(max_length=200)

    def __str__(self):
        return

sales_claim_map = {
    '0' : 'first_name',   # required
    '1' : 'last_name',    # optional
    '2' : 'email',        # optional
    '3' : 'mobile',       # required
    '4' : 'premium',      # optional
    '5' : ('first_call_date','date', '%d/%m/%Y'), #required
    '6' : ('last_call_date','date', '%d/%m/%Y'),  #required
    '7' : 'app_id',       # optional
}

class Application(models.Model):
    app_id = models.CharField(max_length=50, unique=True)
    contract_id = models.TextField(blank=True)
    app_number = models.CharField(max_length=100, blank=True)
    tracker_id = models.CharField(max_length=50, blank=True)
    tracker_details = models.TextField(blank=True)

    bill_date = models.CharField(max_length=50, blank=True)
    deliveryDate = models.CharField(max_length=50, blank=True)
    courier_name = models.CharField(max_length=50, blank=True)
    deliveryStatus = models.CharField(max_length=50, blank=True)

    created_on = models.DateTimeField(auto_now_add=True)
    #Personal Info
    salutation = models.CharField(max_length=20, blank=True)
    first_name = models.CharField(max_length=100, db_index=True)
    last_name = models.CharField(max_length=100, blank=True, db_index=True)
    gender = models.CharField(choices=(('M','Male'),('F','Female')), max_length=10)
    dob = models.DateField(blank=True, null=True)
    marital_status = models.CharField(choices=(('Married','Married'),('Single','Single')), blank=True, max_length=10)
    nationality = models.CharField(choices=(('Indian','Indian'),('Not Indian','Not Indian')), blank=True, max_length=10)
    education = models.CharField(max_length=100, blank=True)
    occupation = models.CharField(max_length=100, blank=True)
    org_type = models.CharField(max_length=100, blank=True)
    designation = models.CharField(max_length=100, blank=True)
    annual_income = models.CharField(max_length=100, blank=True)

    birth_state = models.CharField(max_length=50, blank=True)
    birth_city = models.CharField(max_length=50, blank=True)
    employer_name = models.CharField(max_length=100, blank=True)
    duty_nature = models.CharField(max_length=100, blank=True)
    years_withemployer = models.CharField(max_length=50, blank=True)
    months_withemployer = models.CharField(max_length=50, blank=True)

    #Current Address
    flat = models.TextField(blank=True)
    building = models.TextField(blank=True)
    road = models.TextField(blank=True)
    area = models.TextField(blank=True)
    landmark = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    state = models.CharField(max_length=50, blank=True)
    country = models.CharField(max_length=50, blank=True)
    email = models.EmailField(max_length=50, blank=True, db_index=True)
    mobile = models.CharField(max_length=20, blank=True, db_index=True)
    stdcode = models.CharField(max_length=10, blank=True)
    landline = models.CharField(max_length=20, blank=True)

    father_name = models.CharField(max_length=100, blank=True)
    industry_type = models.CharField(max_length=100, blank=True)
    pancard_number = models.CharField(max_length=50, blank=True)
    uid_number = models.CharField(max_length=50, blank=True)

    #Permanent Address
    p_flat = models.TextField(blank=True)
    p_building = models.TextField(blank=True)
    p_road = models.TextField(blank=True)
    p_area = models.TextField(blank=True)
    p_landmark = models.CharField(max_length=100, blank=True)
    p_city = models.CharField(max_length=100, blank=True)
    p_pincode = models.CharField(max_length=10, blank=True)
    p_state = models.CharField(max_length=100, blank=True)
    p_country = models.CharField(max_length=100, blank=True)
    p_email = models.EmailField(max_length=255, blank=True)
    p_mobile = models.CharField(max_length=20, blank=True)
    p_stdcode = models.CharField(max_length=10, blank=True)
    p_landline = models.CharField(max_length=20, blank=True)

    #EIA INTERNAL
    eia_number = models.CharField(max_length=100, blank=True)
    ir_name = models.CharField(max_length=100, blank=True)
    ir_email = models.CharField(max_length=100, blank=True)

    politically_exposed = models.CharField(max_length=200, blank=True)
    politically_exposeddetails = models.CharField(max_length=200, blank=True)

    #Documents
    photo_id_proof = models.CharField(max_length=100, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    age_proof = models.CharField(max_length=100, choices=AGE_PROOF_CHOICES, blank=True)
    address_proof = models.CharField(max_length=100, choices=ADDRESS_PROOF_CHOICES, blank=True)
    income_proof = models.CharField(max_length=100, choices=INCOME_PROOF_CHOICES, blank=True)
    attested_photograph = models.BooleanField(default=False, verbose_name='Photograph')

    photo_id_proof_rcvd = models.CharField(max_length=200, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    age_proof_rcvd = models.CharField(max_length=200, choices=AGE_PROOF_CHOICES, blank=True)
    address_proof_rcvd = models.CharField(max_length=200, choices=ADDRESS_PROOF_CHOICES, blank=True)
    income_proof_rcvd = models.CharField(max_length=200, choices=INCOME_PROOF_CHOICES, blank=True)

    photo_id_proof_rcvd_date = models.CharField(max_length=50,null=True, blank=True)
    age_proof_rcvd_date = models.CharField(max_length=50,null=True, blank=True)
    address_proof_rcvd_date = models.CharField(max_length=50,null=True, blank=True)
    income_proof_rcvd_date = models.CharField(max_length=50,null=True, blank=True)

    #Payment
    sum_assured = models.CharField(max_length=20, blank=True)
    sum_assured_website = models.CharField(max_length=20, blank=True) # 5842-D
    annual_premium = models.CharField(max_length=20, blank=True)
#    premium = models.CharField(max_length=20, blank=True)
 #   premium_frequency=models.CharField(max_length=20, choices=PREMIUM_FREQUENCY,  blank=True)

    acc_death_benefit = models.CharField(max_length=50, blank=True)
    banner_id = models.CharField(max_length=50, blank=True)
    promo_id = models.CharField(max_length=50, blank=True)
    fsc_channel = models.CharField(max_length=50, blank=True)
    site_id = models.CharField(max_length=50, blank=True)

    page_name = models.CharField(max_length=255, blank=True)
    pay_amount = models.CharField(max_length=20, blank=True)
    pay_type = models.CharField(max_length=100, blank=True)
    payment_gateway = models.CharField(max_length=100, blank=True)
    transaction_id = models.CharField(max_length=100, blank=True)
    payment_status = models.CharField(max_length=100, blank=True)
    payment_bank = models.CharField(max_length=100, blank=True)
    product_code = models.CharField(max_length=100, blank=True)

    nominee_title = models.CharField(max_length=100, blank=True)
    nominee_first_name = models.CharField(max_length=100, blank=True)
    nominee_last_name = models.CharField(max_length=100, blank=True)
    nominee_dob = models.CharField(max_length=255, blank=True)
    nominee_relationship = models.CharField(max_length=255, blank=True)
    appointee_title = models.CharField(max_length=255, blank=True)
    appointee_first_name = models.CharField(max_length=200, blank=True)
    appointee_last_name = models.CharField(max_length=200, blank=True)
    appointee_dob = models.CharField(max_length=200, blank=True)
    appointee_relationship = models.CharField(max_length=255, blank=True)
    insurance_purpose = models.CharField(max_length=255, blank=True)

    transaction_start_time = models.DateTimeField(null=True, blank=True)
    transaction_end_time = models.DateTimeField(null=True, blank=True)

    # Fup Upload Fields
    fup_associated = models.ManyToManyField('FupAssociated', null=True, blank=True)
    uhci_update_flag = models.BooleanField(default=False) #If new fup gets associated this flag become true, once UHCI has downloaded this, it will become false after 4 hours of the fup update
    uhci_update_time = models.DateTimeField(null=True, blank=True)

    app_status = models.CharField(max_length=150, choices=APP_STATUS, blank=True)
    app_status_date = models.DateField(null=True, blank=True)
    app_status_reason = models.CharField(max_length=255, blank=True)
    app_status_reason_text = models.TextField(blank=True)
    app_uw_amount = models.CharField(max_length=255, blank=True)
    app_uw_reason = models.CharField(max_length=255, blank=True)
    app_uw_reason_text = models.TextField(blank=True)
    proposal_acceptance_date = models.DateField(null=True, blank=True)
    first_issuance_date = models.DateField(null=True, blank=True)
    agent_id =  models.CharField(max_length=100, blank=True)
    mail_date = models.DateField(null=True, blank=True)
    npw_due_date = models.DateField(null=True, blank=True)
    npw_status = models.CharField(max_length=100, blank=True)

    #Email sent status
    #Possible values : "", "-1", "1", "2", "3" number of times sent the mail
    #if "-1" send it in cron and change it to 1
    uw_extra_premium_mail = models.CharField(max_length=150, blank=True)
    fup_status_mail = models.CharField(max_length=150, blank=True)
    app_status_mail = models.CharField(max_length=150, blank=True)
    ad_hoc_mail = models.CharField(max_length=150, blank=True)
    extra = models.TextField(blank=True)

    policy_term = models.CharField(max_length=50, blank=True)
    policyterm_website = models.CharField(max_length=50, blank=True) # 5842-D
    sumassured_interval_website = models.CharField(max_length=50, blank=True) # 5842-D
    sum_assured_option_website = models.CharField(max_length=50, blank=True) # 5842-D 
    sum_assured_option = models.CharField(max_length=50, blank=True)
    sum_assured_interval = models.CharField(max_length=50, blank=True)
    suspense_amount = models.CharField(max_length=50, blank=True)
    premium_service_tax = models.CharField(max_length=50, blank=True)
    mortality_extra_premium = models.CharField(max_length=50, blank=True)
    flat_extra_premium = models.CharField(max_length=50, blank=True)

    #UHCI Data
    medicalappointment_city1 = models.CharField(max_length=100, blank=True)
    medicalappointment_center1 = models.CharField(max_length=100, blank=True)
    medicalappointment_time1 = models.CharField(max_length=100, blank=True)
    medicalappointment_location1 = models.CharField(max_length=100, blank=True)
    medicalappointment_date1 = models.CharField(max_length=100, blank=True)
    medicalappointment_center2 = models.CharField(max_length=100, blank=True)
    medicalappointment_city2 = models.CharField(max_length=100, blank=True)
    medicalappointment_location2 = models.CharField(max_length=100, blank=True)
    medicalappointment_time2 = models.CharField(max_length=100, blank=True)
    medicalappointment_date2 = models.CharField(max_length=100, blank=True)
#    uw_extra = models.BooleanField(default=False)
    online_created_date = models.DateTimeField(null=True, blank=True) # created on 12 may15 
    policy_number = models.CharField(max_length=50, blank=True) #6109                    
    client_id = models.CharField(max_length=50, blank=True)  #6109
#### riders website ###
    accidentaldeath = models.CharField(max_length=100, blank=True)
    criticalillness = models.CharField(max_length=100, blank=True)
    hospitalcareillness = models.CharField(max_length=100, blank=True)
    surgicalcare = models.CharField(max_length=100, blank=True)
    accidentaldeathpre = models.CharField(max_length=100, blank=True)
    criticalillnesspre = models.CharField(max_length=100, blank=True)
    hospitalcareillnesspre = models.CharField(max_length=100, blank=True)
    surgicalcarepre = models.CharField(max_length=100, blank=True)
    riderdisc = models.CharField(max_length=150, blank=True)
#### riders ingenium ###
     
    accidental_uw_amount = models.CharField(max_length=50, blank=True)
    accidental_uw_reason = models.CharField(max_length=50, blank=True)
    accidental_uw_reason_text = models.TextField(blank=True)
    accidental_sum_assured = models.CharField(max_length=50, blank=True)
    accidental_flat_extra_premium = models.CharField(max_length=50, blank=True)
    accidental_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    accidental_premium_service_tax = models.CharField(max_length=50, blank=True)    
    accidental_policyterm = models.CharField(max_length=20,blank=True) ##### new add 21 march   
    accidental_policystatus = models.CharField(max_length=20, blank=True)    ##### new add 21 march   

    critical_uw_amount = models.CharField(max_length=50, blank=True)
    critical_uw_reason = models.CharField(max_length=50, blank=True)
    critical_uw_reason_text = models.TextField(blank=True)
    critical_sum_assured = models.CharField(max_length=50, blank=True)
    critical_flat_extra_premium = models.CharField(max_length=50, blank=True)
    critical_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    critical_premium_service_tax = models.CharField(max_length=50, blank=True)
    critical_policyterm = models.CharField(max_length=20, blank=True) ##### new add 21 march   
    critical_policystatus = models.CharField(max_length=20, blank=True) ##### new add 21 march   

    hospital_uw_amount = models.CharField(max_length=50, blank=True)
    hospital_uw_reason = models.CharField(max_length=50, blank=True)
    hospital_uw_reason_text = models.TextField(blank=True)
    hospital_sum_assured = models.CharField(max_length=50, blank=True)
    hospital_flat_extra_premium = models.CharField(max_length=50, blank=True)
    hospital_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    hospital_premium_service_tax = models.CharField(max_length=50, blank=True)
    hospital_policyterm = models.CharField(max_length=20, blank=True) ##### new add 21 march   
    hospital_policystatus = models.CharField(max_length=20, blank=True) ##### new add 21 march   

    surgical_uw_amount = models.CharField(max_length=50, blank=True)
    surgical_uw_reason = models.CharField(max_length=50, blank=True)
    surgical_uw_reason_text = models.TextField(blank=True)
    surgical_sum_assured = models.CharField(max_length=50, blank=True)
    surgical_flat_extra_premium = models.CharField(max_length=50, blank=True)
    surgical_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    surgical_premium_service_tax = models.CharField(max_length=50, blank=True)
    surgical_policyterm = models.CharField(max_length=20, blank=True) ##### new add 21 march   
    surgical_policystatus = models.CharField(max_length=20, blank=True) ##### new add 21 march   
    rider_reject_reason_text = models.CharField(max_length=100, blank=True) #5842-D
 
   # new rider ADB
    accidentaldeathbenefit_uw_amount = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_uw_reason = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_uw_reason_text = models.TextField(blank=True)
    accidentaldeathbenefit_sum_assured = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_flat_extra_premium = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_premium_service_tax = models.CharField(max_length=50, blank=True)
    accidentaldeathbenefit_policyterm = models.CharField(max_length=20, blank=True)
    accidentaldeathbenefit_policystatus = models.CharField(max_length=20, blank=True) 
    
    #new rider added
    base_plan_id = models.CharField(max_length=100 ,blank =True)
    accidentalDeathAndBenefitPlus = models.CharField(max_length=100 , blank=True)
    accidentalDeathAndBenefitPlusPre = models.CharField(max_length=100, blank=True)
    

    # new product name  1 feb 2017
    product_name = models.CharField(max_length=100 ,blank =True) #6733
    # added insurer data - 3 feb 2016
    insurer_data = models.TextField(blank =True) #6733 optional
    
    smoker_non_smoker = models.CharField(max_length=100, blank=True)  # smoker non smoker columns UW req new  6733
    reqt_reason = models.CharField(max_length=100, blank=True)  # reuest reason  columns UW req new  6733



    surgical_smoker_non_smoker = models.CharField(max_length=100, blank=True)  # 6733
    surgical_req_reason = models.CharField(max_length=100, blank=True)  # 6733

    accidental_smoker_non_smoker = models.CharField(max_length=100, blank=True)  # 6733
    accidental_req_reason = models.CharField(max_length=100, blank=True)  # 6733

    hospital_smoker_non_smoker = models.CharField(max_length=100, blank=True)  # 6733
    hospital_reqt_reason = models.CharField(max_length=100, blank=True)  # 6733

    critical_smoker_non_smoker = models.CharField(max_length=100, blank=True)  # 6733
    critical_reqt_reason = models.CharField(max_length=100, blank=True)  # 6733

    accidentaldeathbenefit_smoker_non_smoker = models.CharField(max_length=100, blank=True)  # 6733
    accidentaldeathbenefit_reqt_reason = models.CharField(max_length=100, blank=True)  # 6733

    # 6733 new rider wop 
    waiverofPremium = models.CharField(max_length=100, blank=True) # 6733
    waiverofPremiumpre = models.CharField(max_length=100, blank=True) # 6733

    # 6733 WOP Rider
    waiverofPremium_uw_amount = models.CharField(max_length=50, blank=True)
    waiverofPremium_uw_reason = models.CharField(max_length=50, blank=True)
    waiverofPremium_uw_reason_text = models.TextField(blank=True)
    waiverofPremium_sum_assured = models.CharField(max_length=50, blank=True)
    waiverofPremium_flat_extra_premium = models.CharField(max_length=50, blank=True)
    waiverofPremium_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    waiverofPremium_premium_service_tax = models.CharField(max_length=50, blank=True)
    waiverofPremium_policyterm = models.CharField(max_length=20, blank=True)
    waiverofPremium_policystatus = models.CharField(max_length=20, blank=True)
    waiverofPremium_uw_reason = models.CharField(max_length=50, blank=True)
    waiverofPremium_uw_reason_text = models.TextField(blank=True)
    waiverofPremium_sum_assured = models.CharField(max_length=50, blank=True)
    waiverofPremium_smoker_non_smoker = models.CharField(max_length=100, blank=True)
    waiverofPremium_reqt_reason = models.CharField(max_length=100, blank=True)


    def __str__(self):
        return str(self.app_id)
        
    def sms_history(self):
        return self.actionhistory_set.filter(action_type="sms")
        
    def email_history(self):
        return self.actionhistory_set.filter(action_type="email")

class UploadFile(models.Model):
    upload_file = models.FileField(upload_to=get_image_path)
    user = models.ForeignKey(User, null=True, blank=True)
    output = models.TextField(blank=True)
    is_processed = models.BooleanField(default=False)
    created_on = models.DateTimeField(auto_now_add=True)

class UHCData(models.Model):
    application = models.ForeignKey('Application')
    medicalappointment_location1 = models.CharField(max_length=255, blank=True)
    medicalappointment_city1 = models.CharField(max_length=255, blank=True)
    medicalappointment_center1 = models.CharField(max_length=255, blank=True)
    medicalappointment_date1 = models.CharField(max_length=255, blank=True)
    medicalappointment_time1 = models.CharField(max_length=255, blank=True)

    medicalappointment_location2 = models.CharField(max_length=255, blank=True)
    medicalappointment_city2 = models.CharField(max_length=255, blank=True)
    medicalappointment_center2 = models.CharField(max_length=255, blank=True)
    medicalappointment_time2 = models.CharField(max_length=255, blank=True)
    medicalappointment_date2 = models.CharField(max_length=255, blank=True)

    dc_code = models.CharField(max_length=255, blank=True)
    dc_name = models.CharField(max_length=255, blank=True)
    dc_address = models.TextField(blank=True)
    doctor_name = models.CharField(max_length=255, blank=True)
    doctor_contact_number = models.CharField(max_length=255, blank=True)
    contact_details = models.TextField(blank=True)
    ta_code = models.CharField(max_length=255, blank=True)
    remarks = models.TextField(blank=True)
    tests = models.TextField(blank=True)

    status = models.TextField(blank=True)
    provider_code = models.CharField(max_length=255, blank=True)
    provider=models.CharField(max_length=255, blank=True)
    provider_state=models.CharField(max_length=255, blank=True)
    provider_city=models.CharField(max_length=255, blank=True)
    appointment_time=models.CharField(max_length=100, blank=True)
    appt_date=models.CharField(max_length=100, blank=True)
    

    medicalappointment_date3 = models.CharField(max_length=255, blank=True) #new_fields_added_uhci 13 feb
    confirm_sms_date = models.CharField(max_length=255, blank=True)
    confirm_email_date = models.CharField(max_length=255, blank=True)
    med_done_date = models.CharField(max_length=255, blank=True)
    uhci_scheduled_date=models.DateTimeField(blank=True, null=True)#new_fields_added_uhci 20 feb
    bsli_reports_sent_date=models.DateTimeField(blank=True, null=True)#new_fields_added_uhci 20 feb
    uhci_file_received_date=models.DateTimeField(blank=True, null=True)#new_fields_added_uhci 20 feb
    created_on = models.DateTimeField(auto_now_add=True, blank=True, null=True) # new_fields_end

class CourierData(models.Model):
    application = models.OneToOneField('Application')
    remarks = models.TextField(blank=True)
    call_category = models.CharField(max_length=150)
    call_id1 = models.IntegerField(blank=True, null=True)
    call_id2 = models.IntegerField(blank=True, null=True)
    call_id3 = models.IntegerField(blank=True, null=True)

class ActionHistory(models.Model):
    ACTION_TYPE = (
        ('email', 'email'),
        ('sms', 'sms'),
    )
    application = models.ForeignKey('Application')
    meta = models.TextField(blank=True)
    to = models.CharField(max_length=100)
    message = models.TextField(blank=True)
    created_on = models.DateTimeField(auto_now_add=True)
    subject =models.CharField(max_length=255, blank=True)
    action_type = models.CharField(max_length=5, choices=ACTION_TYPE, blank=True)

#6109
class UserSession(models.Model):
    user = models.OneToOneField(User)
    session = models.ForeignKey(Session)

class UhcDownload (models.Model):
    application = models.ForeignKey('Application')
    tests = models.TextField(blank=True)
    created_on = models.DateTimeField(null=True,blank=True)


uhc_field_map = {
    'app_id' : 0,
    'first_call_on' : 1,
    'remarks1' : 2,
    'second_call_on' : 3,
    'remarks2' : 4,
    'third_call_on' : 5,
    'remarks3' : 6,
    'path_appt_date' : 7,
    'path_appt_time' : 8,
    'path_test_name' : 9,
    'path_dc_name' : 10,
    'tmt_appt_date' : 11,
    'tmt_appt_time' : 12,
    'tmt_test_name' : 13,
    'tmt_dc_name' : 14,
    'last_call_status' : 15,
    'final_status' : 16,
}

uhc_field_reverse_map = dict([(v,k) for k,v in uhc_field_map.items()])

fup_field_map1 = {
    'agent_id' : 0,
    'app_id' : 1,
    'fsc_bank_name' : 2,
    'fsc_branch_name' : 3,
    'fsc_source_code' : 4,
    'fup_code' : 5,
    'jet_decision' : 6,
    'trigger_date' : 10,
    'closure_date' : 11,
    'product_code' : 7,
}

fup_field_reverse_map1 = dict([(v,k) for k,v in fup_field_map1.items()])

fup_field_map2 = {
    'app_id' : 0,
    'contract_id' : 1,
    'first_issuance_date': 2,
    'app_status' : 3,
    'proposal_acceptance_date': 4,
    'ape_amount' : 5,
}

fup_field_reverse_map2 = dict([(v,k) for k,v in fup_field_map2.items()])

model_field_map = {
    'app_id' :  0,
    'iad_app_datetime' :  4,
    'iad_product_code' :  10,
    'product_code' :  11,
    'icb_id' :  12,
    'payment_bank' :  17,
    'web_transaction_id' :  26,
    'pay_type' :  29,
    'payment_status' :  32,
    'payment_gateway' :  33,
    'iad_source' :  38,
    'pay_amount' :  40,
    'transaction_id' :  41,
    'transaction_end_time' :  42,
    'transaction_start_time' :  43,
    'advisor_code' :  65,
    'advisor_contact_no' :  66,
    'iad_fsc_channel' :  67,
    'fsc_code' :  68,
    'fsc_name' :  69,
    'iad_site_id' :  69,
    'branch_name' :  70,
    'iad_banner_id' :  70,
    'iad_promo_id' :  71,
    'first_name' :  85,
    'last_name' :  87,
    'landline' :  88,
    'mobile' :  89,
    'email' :  90,
    'dob' :  91,
    'marital_status' :  92,
    'gender' :  93,
    'p_country' :  98,
    'nationality' :  100,
    'address1' :  133,
    'address2' :  134,
    'city' :  135,
    'landmark' :  135,
    'state' :  137,
    'pincode' :  138,
    'country' :  139,
    'p_email' :  145,
    'p_mobile' :  146,
    'p_landline' :  147,
    'education' :  150,
    'annual_income' :  157,
    'designation' :  169,
    'occupation' :  177,
    'org_type' :  179,
    'sum_assured' :  185,
    'annual_premium' :  186,
#    'app_number' :  X,
#    'address_proof' :  X,
#    'age_proof' :  X,
#    'photo_id_proof' :  X,
#    'p_stdcode' :  X,
#    'fsc_contact_no' :  X,
#    'stdcode' :  X,
#    'p_city' :  X,
#    'p_address2' :  X,
#    'advisor_name' :  X,
#    'p_pincode' :  X,
#    'iad_finops_status' :  X,
#    'income_proof' :  X,
#    'iad_cops_status' :  X,
#    'p_landmark' :  X,
#    'p_address1' :  X,
#    'p_state' :  X
}


old_model_field_map = {
    'app_number' : 0,
    'app_id' : 1,
    'icb_id' : 2,

    #Personal Info
    'first_name' : 3,
    'last_name' : 4,
    'gender' : 5,
    'dob' : 6,
    'marital_status' : 9,
    'nationality' : 10,
    'education' : 11,
    'occupation' : 12,
    'org_type' : 13,
    'designation' : 14,
    'annual_income' : 15,
    #'pan' : 16,

    #Current Address
    'address1' : 17,
    'address2' : 18,
    'landmark' : 19,
    'city' : 20,
    'pincode' : 21,
    'state' : 22,
    'country' : 23,
    'email' : 24,
    'mobile' : 25,
    'stdcode' : 26,
    'landline' : 27,

    #Permanent Address
    'p_address1' : 28,
    'p_address2' : 29,
    'p_landmark' : 30,
    'p_city' : 31,
    'p_pincode' : 32,
    'p_state' : 33,
    'p_country' : 34,
    'p_email' : 35,
    'p_mobile' : 36,
    'p_stdcode' : 37,
    'p_landline' : 38,

    #Documents
    'address_proof' : 39,
    'age_proof' : 40,
    'photo_id_proof' : 42,
    'income_proof' : 66,

    #Internal Process
    'iad_app_datetime' : 93,
    'iad_cops_status' : 94,
    'iad_finops_status' : 95,
    'iad_product_code' : 96,
    'iad_source' : 97,

    #Payment
    'sum_assured' : 103,
    'annual_premium' : 104,

    'iad_banner_id' : 106,
    'iad_promo_id' : 107,
    'iad_fsc_channel' : 108,
    'iad_site_id' : 109,

    'pay_amount' : 113,
    'pay_type' : 114,
    'payment_gateway' : 115,
    'transaction_id' : 116,
    'transaction_start_time' : 118,
    'transaction_end_time' : 119,
    'payment_status' : 120,
    'web_transaction_id' : 123,
    'payment_bank' : 124,
    'product_code' : 128,
    'advisor_code' : 129,
    'advisor_contact_no' : 130,
    'advisor_name' : 131,
    'fsc_code' : 132,
    'fsc_contact_no' : 133,
    'fsc_name' : 134,
    'branch_name' : 135,
}

model_field_reverse_map = dict([(v,k) for k,v in model_field_map.items()])


# new table to stored insurer and secondary insurer data  and mapping with core_application table 6733
# 6733
# date 1 feb 2017  

class InsurerApplication(models.Model):
    ins_application = models.OneToOneField('Application')

    ins_app_id = models.CharField(max_length=50, unique=True)
    ins_contract_id = models.TextField(blank=True)
    ins_app_number = models.CharField(max_length=100, blank=True)
    ins_tracker_id = models.CharField(max_length=50, blank=True)
    ins_tracker_details = models.TextField(blank=True)

    ins_bill_date = models.CharField(max_length=50, blank=True)
    ins_deliveryDate = models.CharField(max_length=50, blank=True)
    ins_courier_name = models.CharField(max_length=50, blank=True)
    ins_deliveryStatus = models.CharField(max_length=50, blank=True)

    ins_created_on = models.DateTimeField(auto_now_add=True)
    # Personal Info
    ins_salutation = models.CharField(max_length=20, blank=True)
    ins_first_name = models.CharField(max_length=100, db_index=True)
    ins_last_name = models.CharField(max_length=100, blank=True, db_index=True)
    ins_gender = models.CharField(choices=(('M', 'Male'), ('F', 'Female')), max_length=10)
    ins_dob = models.DateField(blank=True, null=True)
    ins_marital_status = models.CharField(choices=(('Married', 'Married'), ('Single', 'Single')), blank=True,
                                          max_length=10)
    ins_nationality = models.CharField(choices=(('Indian', 'Indian'), ('Not Indian', 'Not Indian')), blank=True,
                                       max_length=10)
    ins_education = models.CharField(max_length=100, blank=True)
    ins_occupation = models.CharField(max_length=100, blank=True)
    ins_org_type = models.CharField(max_length=100, blank=True)
    ins_designation = models.CharField(max_length=100, blank=True)
    ins_annual_income = models.CharField(max_length=100, blank=True)

    ins_birth_state = models.CharField(max_length=50, blank=True)
    ins_birth_city = models.CharField(max_length=50, blank=True)
    ins_employer_name = models.CharField(max_length=100, blank=True)
    ins_duty_nature = models.CharField(max_length=100, blank=True)
    ins_years_withemployer = models.CharField(max_length=50, blank=True)
    ins_months_withemployer = models.CharField(max_length=50, blank=True)

    # Current Address
    ins_flat = models.TextField(blank=True)
    ins_building = models.TextField(blank=True)
    ins_road = models.TextField(blank=True)
    ins_area = models.TextField(blank=True)
    ins_landmark = models.CharField(max_length=200, blank=True)
    ins_city = models.CharField(max_length=100, blank=True)
    ins_pincode = models.CharField(max_length=10, blank=True)
    ins_state = models.CharField(max_length=50, blank=True)
    ins_country = models.CharField(max_length=50, blank=True)
    ins_email = models.EmailField(max_length=50, blank=True, db_index=True)
    ins_mobile = models.CharField(max_length=20, blank=True, db_index=True)
    ins_stdcode = models.CharField(max_length=10, blank=True)
    ins_landline = models.CharField(max_length=20, blank=True)

    ins_father_name = models.CharField(max_length=100, blank=True)
    ins_industry_type = models.CharField(max_length=100, blank=True)
    ins_pancard_number = models.CharField(max_length=50, blank=True)
    ins_uid_number = models.CharField(max_length=50, blank=True)

    # Permanent Address
    ins_p_flat = models.TextField(blank=True)
    ins_p_building = models.TextField(blank=True)
    ins_p_road = models.TextField(blank=True)
    ins_p_area = models.TextField(blank=True)
    ins_p_landmark = models.CharField(max_length=100, blank=True)
    ins_p_city = models.CharField(max_length=100, blank=True)
    ins_p_pincode = models.CharField(max_length=10, blank=True)
    ins_p_state = models.CharField(max_length=100, blank=True)
    ins_p_country = models.CharField(max_length=100, blank=True)
    ins_p_email = models.EmailField(max_length=255, blank=True)
    ins_p_mobile = models.CharField(max_length=20, blank=True)
    ins_p_stdcode = models.CharField(max_length=10, blank=True)
    ins_p_landline = models.CharField(max_length=20, blank=True)

    # EIA INTERNAL
    ins_eia_number = models.CharField(max_length=100, blank=True)
    ins_ir_name = models.CharField(max_length=100, blank=True)
    ins_ir_email = models.CharField(max_length=100, blank=True)

    ins_politically_exposed = models.CharField(max_length=200, blank=True)
    ins_politically_exposeddetails = models.CharField(max_length=200, blank=True)

    # Documents
    ins_photo_id_proof = models.CharField(max_length=100, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    ins_age_proof = models.CharField(max_length=100, choices=AGE_PROOF_CHOICES, blank=True)
    ins_address_proof = models.CharField(max_length=100, choices=ADDRESS_PROOF_CHOICES, blank=True)
    ins_income_proof = models.CharField(max_length=100, choices=INCOME_PROOF_CHOICES, blank=True)
    ins_attested_photograph = models.BooleanField(default=False, verbose_name='Photograph')

    ins_photo_id_proof_rcvd = models.CharField(max_length=200, choices=PHOTO_ID_PROOF_CHOICES, blank=True)
    ins_age_proof_rcvd = models.CharField(max_length=200, choices=AGE_PROOF_CHOICES, blank=True)
    ins_address_proof_rcvd = models.CharField(max_length=200, choices=ADDRESS_PROOF_CHOICES, blank=True)
    ins_income_proof_rcvd = models.CharField(max_length=200, choices=INCOME_PROOF_CHOICES, blank=True)

    ins_photo_id_proof_rcvd_date = models.CharField(max_length=50, null=True, blank=True)
    ins_age_proof_rcvd_date = models.CharField(max_length=50, null=True, blank=True)
    ins_address_proof_rcvd_date = models.CharField(max_length=50, null=True, blank=True)
    ins_income_proof_rcvd_date = models.CharField(max_length=50, null=True, blank=True)

    # Payment
    ins_sum_assured = models.CharField(max_length=20, blank=True)
    ins_sum_assured_website = models.CharField(max_length=20, blank=True)  # 5842-D
    ins_annual_premium = models.CharField(max_length=20, blank=True)
    #    premium = models.CharField(max_length=20, blank=True)
    #   premium_frequency=models.CharField(max_length=20, choices=PREMIUM_FREQUENCY,  blank=True)

    ins_acc_death_benefit = models.CharField(max_length=50, blank=True)
    ins_banner_id = models.CharField(max_length=50, blank=True)
    ins_promo_id = models.CharField(max_length=50, blank=True)
    ins_fsc_channel = models.CharField(max_length=50, blank=True)
    ins_site_id = models.CharField(max_length=50, blank=True)

    ins_page_name = models.CharField(max_length=255, blank=True)
    ins_pay_amount = models.CharField(max_length=20, blank=True)
    ins_pay_type = models.CharField(max_length=100, blank=True)
    ins_payment_gateway = models.CharField(max_length=100, blank=True)
    ins_transaction_id = models.CharField(max_length=100, blank=True)
    ins_payment_status = models.CharField(max_length=100, blank=True)
    ins_payment_bank = models.CharField(max_length=100, blank=True)
    ins_product_code = models.CharField(max_length=100, blank=True)

    ins_nominee_title = models.CharField(max_length=100, blank=True)
    ins_nominee_first_name = models.CharField(max_length=100, blank=True)
    ins_nominee_last_name = models.CharField(max_length=100, blank=True)
    ins_nominee_dob = models.CharField(max_length=255, blank=True)
    ins_nominee_relationship = models.CharField(max_length=255, blank=True)
    ins_appointee_title = models.CharField(max_length=255, blank=True)
    ins_appointee_first_name = models.CharField(max_length=200, blank=True)
    ins_appointee_last_name = models.CharField(max_length=200, blank=True)
    ins_appointee_dob = models.CharField(max_length=200, blank=True)
    ins_appointee_relationship = models.CharField(max_length=255, blank=True)
    ins_insurance_purpose = models.CharField(max_length=255, blank=True)

    ins_transaction_start_time = models.DateTimeField(null=True, blank=True)
    ins_transaction_end_time = models.DateTimeField(null=True, blank=True)

    # Fup Upload Fields
    ins_fup_associated = models.ManyToManyField('FupAssociated', null=True, blank=True)
    ins_uhci_update_flag = models.BooleanField(
        default=False)  # If new fup gets associated this flag become true, once UHCI has downloaded this, it will become false after 4 hours of the fup update
    ins_uhci_update_time = models.DateTimeField(null=True, blank=True)

    ins_app_status = models.CharField(max_length=150, choices=APP_STATUS, blank=True)
    ins_app_status_date = models.DateField(null=True, blank=True)
    ins_app_status_reason = models.CharField(max_length=255, blank=True)
    ins_app_status_reason_text = models.TextField(blank=True)
    ins_app_uw_amount = models.CharField(max_length=255, blank=True)
    ins_app_uw_reason = models.CharField(max_length=255, blank=True)
    ins_app_uw_reason_text = models.TextField(blank=True)
    ins_proposal_acceptance_date = models.DateField(null=True, blank=True)
    ins_first_issuance_date = models.DateField(null=True, blank=True)
    ins_agent_id = models.CharField(max_length=100, blank=True)
    ins_mail_date = models.DateField(null=True, blank=True)
    ins_npw_due_date = models.DateField(null=True, blank=True)
    ins_npw_status = models.CharField(max_length=100, blank=True)

    # Email sent status
    # Possible values : "", "-1", "1", "2", "3" number of times sent the mail
    # if "-1" send it in cron and change it to 1
    ins_uw_extra_premium_mail = models.CharField(max_length=150, blank=True)
    ins_fup_status_mail = models.CharField(max_length=150, blank=True)
    ins_app_status_mail = models.CharField(max_length=150, blank=True)
    ins_ad_hoc_mail = models.CharField(max_length=150, blank=True)
    ins_extra = models.TextField(blank=True)

    ins_policy_term = models.CharField(max_length=50, blank=True)
    ins_policyterm_website = models.CharField(max_length=50, blank=True)  # 5842-D
    ins_sumassured_interval_website = models.CharField(max_length=50, blank=True)  # 5842-D
    ins_sum_assured_option_website = models.CharField(max_length=50, blank=True)  # 5842-D
    ins_sum_assured_option = models.CharField(max_length=50, blank=True)
    ins_sum_assured_interval = models.CharField(max_length=50, blank=True)
    ins_suspense_amount = models.CharField(max_length=50, blank=True)
    ins_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_flat_extra_premium = models.CharField(max_length=50, blank=True)

    # UHCI Data
    ins_medicalappointment_city1 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_center1 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_time1 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_location1 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_date1 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_center2 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_city2 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_location2 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_time2 = models.CharField(max_length=100, blank=True)
    ins_medicalappointment_date2 = models.CharField(max_length=100, blank=True)
    #    uw_extra = models.BooleanField(default=False)
    ins_online_created_date = models.DateTimeField(null=True, blank=True)  # created on 12 may15
    ins_policy_number = models.CharField(max_length=50, blank=True)  # 6109
    ins_client_id = models.CharField(max_length=50, blank=True)  # 6109
    #### riders website ###
    ins_accidentaldeath = models.CharField(max_length=100, blank=True)
    ins_criticalillness = models.CharField(max_length=100, blank=True)
    ins_hospitalcareillness = models.CharField(max_length=100, blank=True)
    ins_surgicalcare = models.CharField(max_length=100, blank=True)
    ins_accidentaldeathpre = models.CharField(max_length=100, blank=True)
    ins_criticalillnesspre = models.CharField(max_length=100, blank=True)
    ins_hospitalcareillnesspre = models.CharField(max_length=100, blank=True)
    ins_surgicalcarepre = models.CharField(max_length=100, blank=True)
    ins_riderdisc = models.CharField(max_length=150, blank=True)
    #### riders ingenium ###

    ins_accidental_uw_amount = models.CharField(max_length=50, blank=True)
    ins_accidental_uw_reason = models.CharField(max_length=50, blank=True)
    ins_accidental_uw_reason_text = models.TextField(blank=True)
    ins_accidental_sum_assured = models.CharField(max_length=50, blank=True)
    ins_accidental_flat_extra_premium = models.CharField(max_length=50, blank=True)
    ins_accidental_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_accidental_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_accidental_policyterm = models.CharField(max_length=20, blank=True)  ##### new add 21 march
    ins_accidental_policystatus = models.CharField(max_length=20, blank=True)  ##### new add 21 march

    ins_critical_uw_amount = models.CharField(max_length=50, blank=True)
    ins_critical_uw_reason = models.CharField(max_length=50, blank=True)
    ins_critical_uw_reason_text = models.TextField(blank=True)
    ins_critical_sum_assured = models.CharField(max_length=50, blank=True)
    ins_critical_flat_extra_premium = models.CharField(max_length=50, blank=True)
    ins_critical_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_critical_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_critical_policyterm = models.CharField(max_length=20, blank=True)  ##### new add 21 march
    ins_critical_policystatus = models.CharField(max_length=20, blank=True)  ##### new add 21 march

    ins_hospital_uw_amount = models.CharField(max_length=50, blank=True)
    ins_hospital_uw_reason = models.CharField(max_length=50, blank=True)
    ins_hospital_uw_reason_text = models.TextField(blank=True)
    ins_hospital_sum_assured = models.CharField(max_length=50, blank=True)
    ins_hospital_flat_extra_premium = models.CharField(max_length=50, blank=True)
    ins_hospital_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_hospital_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_hospital_policyterm = models.CharField(max_length=20, blank=True)  ##### new add 21 march
    ins_hospital_policystatus = models.CharField(max_length=20, blank=True)  ##### new add 21 march

    ins_surgical_uw_amount = models.CharField(max_length=50, blank=True)
    ins_surgical_uw_reason = models.CharField(max_length=50, blank=True)
    ins_surgical_uw_reason_text = models.TextField(blank=True)
    ins_surgical_sum_assured = models.CharField(max_length=50, blank=True)
    ins_surgical_flat_extra_premium = models.CharField(max_length=50, blank=True)
    ins_surgical_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_surgical_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_surgical_policyterm = models.CharField(max_length=20, blank=True)  ##### new add 21 march
    ins_surgical_policystatus = models.CharField(max_length=20, blank=True)  ##### new add 21 march
    ins_rider_reject_reason_text = models.CharField(max_length=100, blank=True)  # 5842-D

    # new rider ADB
    ins_accidentaldeathbenefit_uw_amount = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_uw_reason = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_uw_reason_text = models.TextField(blank=True)
    ins_accidentaldeathbenefit_sum_assured = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_flat_extra_premium = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_mortality_extra_premium = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_premium_service_tax = models.CharField(max_length=50, blank=True)
    ins_accidentaldeathbenefit_policyterm = models.CharField(max_length=20, blank=True)
    ins_accidentaldeathbenefit_policystatus = models.CharField(max_length=20, blank=True)

    # new rider added
    ins_base_plan_id = models.CharField(max_length=100, blank=True)
    ins_accidentalDeathAndBenefitPlus = models.CharField(max_length=100, blank=True)
    ins_accidentalDeathAndBenefitPlusPre = models.CharField(max_length=100, blank=True)


    ins_req_reason =  models.CharField(max_length=100, blank=True) # 6733 UW
    ins_smoker_non_smoker =  models.CharField(max_length=100, blank=True) # 6733 UW
 

    def __str__(self):
        return str(self.app_id)

    def sms_history(self):
        return self.actionhistory_set.filter(action_type="sms")

    def email_history(self):
        return self.actionhistory_set.filter(action_type="email")
