from django.contrib import admin
from core.models import *

"""
class ModelNameAdmin(admin.ModelAdmin):
    pass
admin.site.register(ModelName, ModelNameAdmin)
"""

admin.site.register(UserProfile)
admin.site.register(CallHistory)
admin.site.register(ApplicationCallAttribute)
admin.site.register(AppStatus)
admin.site.register(FupAssociated)

class FUPAdmin(admin.ModelAdmin):
    list_display = ('name','description','is_medical')
    list_filter = ('is_medical',) 
    search_fields = ['name', 'description']
admin.site.register(FUP, FUPAdmin)

admin.site.register(Application)
admin.site.register(CallPriority)
admin.site.register(Plan)
