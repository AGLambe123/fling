from django.conf.urls import patterns, url, include
from django.views.generic.base import TemplateView

TemplateView.as_view(template_name='about.html')

urlpatterns = patterns('core.views',
    url(r'^$', 'index'),
    url(r'^create-application/$', 'create_application'),
                    
    url(r'^create-pbz-application/$', 'create_policy_bazaar_application'),

    url(r'^update-application/$', 'update_application'),

    url(r'^callcenter/send-mail/$', 'callcenter_send_mail'),
    url(r'^get-user-details/$', 'get_user_details'),
    #Urls for Testing
    #url(r'^html/(?P<filename>[\w-]+).html$', 'show_html'),

    url(r'^send-sms/(?P<app_id>\w+)/(?P<message_code>\w+)/$', 'send_sms_view'),

    url(r'^upload/app-data/$', 'upload_app_data'),
    url(r'^upload/fup-data/$', 'upload_fup_data'),
    url(r'^upload/proposal-data/$', 'upload_proposal_data'),

    url(r'^affiliate/upload/$', 'upload_affiliate_data'),
    url(r'^affiliate/dashboard/$', TemplateView.as_view(template_name='core/affiliate_dashboard.html')),
    url(r'^affiliate/upload-history/$', 'affiliate_upload_list'),
    url(r'^affiliate/upload/(?P<upid>\w+)/history/$', 'affiliate_upload_history'),
    url(r'^affiliate/report/$', 'affiliate_report'),

    url(r'^affiliate-admin/dashboard/$', TemplateView.as_view(template_name='core/affiliate_admin_dashboard.html')),
    url(r'^affiliate-admin/report/$', 'affiliate_admin_report'),
    url(r'^affiliate-admin/manage-affiliate/$', 'affiliate_manage'),
    url(r'^affiliate-admin/affiliate/add/$', 'affiliate_add'),
    url(r'^affiliate-admin/affiliate/edit/(?P<uid>\w+)/$', 'affiliate_edit'),
    url(r'^affiliate-admin/affiliate/disable/(?P<uid>\w+)/$', 'affiliate_disable'),
    url(r'^affiliate-admin/affiliate/enable/(?P<uid>\w+)/$', 'affiliate_enable'),

    url(r'^callcenter/dashboard/$', 'callcenter_dashboard', {'cid':None}),
    url(r'^callcenter/dashboard/(?P<cid>\w+)/$', 'callcenter_dashboard'),
    url(r'^search-call/(?P<app_id>\w+)/$', 'search_and_call'),
    url(r'^callcenter/take-call/(?P<cid>\w+)/$', 'take_call'),
    url(r'^ajax/application/(?P<app_id>\w+)/add/mecode/(?P<mecode>\w+)/$', 'add_mecode'),
    url(r'^ajax/application/(?P<app_id>\w+)/remove/mecode/(?P<mecode>\w+)/$', 'remove_mecode'),
    url(r'^clean-dirty/$', 'clean_dirty_application'),
    url(r'^ajax/check-courier/(?P<pin>\w+)/$', 'check_courier'),

    url(r'^manager/call-priority/edit/$', 'manager_call_priority_edit'),
    url(r'^manager/user/manage/$', 'user_manage'),
    url(r'^manager/reassign-calls/$', 'reassign_calls'),
    url(r'^manager/user-session/$', 'user_sessions'),
    url(r'^manager/user/add/$', 'user_add'),
    url(r'^manager/user/edit/(?P<uid>\w+)/$', 'user_edit'),
    url(r'^manager/user/enable/(?P<uid>\w+)/$', 'user_enable'),
    url(r'^manager/user/disable/(?P<uid>\w+)/$', 'user_disable'),

    url(r'^manager/reports/$', 'manager_reports'),
    url(r'^manager/uploads/$', 'manager_uploads'),
    url(r'^manager/downloads/$', 'manager_downloads'),

    url(r'^manager/navigate/$', TemplateView.as_view(template_name='core/navigation.html')),
    url(r'^manager/dashboard/$', TemplateView.as_view(template_name='core/dashboard.html')),
    url(r'^upload/dashboard/$', TemplateView.as_view(template_name='core/uploads.html')),
    url(r'^report/dashboard/$', TemplateView.as_view(template_name='core/reports.html')),
    url(r'^courier/dashboard/$', TemplateView.as_view(template_name='home.html')),
    url(r'^new-telecaller/dashboard/$', TemplateView.as_view(template_name='core/dashboard.html')),

    url(r'^manager/status-ageing-report/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'status_ageing_report'),
    url(r'^manager/app-status-report/$', 'app_status_report'),
    url(r'^manager/app-disposition-report/$', 'app_disposition_report'),
    #url(r'^manager/app-exception-report/$', 'app_exception_report'),
    url(r'^manager/app-exception-report/$', 'app_exception_report'),
    url(r'^manager/downloads/document-data-select-daterange/$', 'document_data_select_daterange'),
    url(r'^manager/downloads/call-status-select-daterange/$', 'call_status_select_daterange'),
    url(r'^manager/downloads/app-movement-report/$', 'application_movement_report'),
    url(r'^manager/downloads/telecaller-sms-dump/$', 'telecaller_sms_dump'),
    url(r'^manager/downloads/courier-sms-dump/$', 'courier_sms_dump'),
    url(r'^manager/downloads/document-data-report/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'document_data_report'),
    url(r'^manager/downloads/call-status-report/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'callstatus_report'),
    url(r'^manager/downloads/call_reports/$', 'call_time_report'),                                                                                       url(r'^manager/downloads/communicate_report/$', 'communicate_report'),
 

    url(r'^manager/reconcile-psm/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'reconcile_psm'),
    url(r'^manager/reconcile-psm/select-daterange/$', 'reconcile_psm_daterange'),

    url(r'^manager/app-transaction-report/$', 'app_transaction_report'),
    url(r'^manager/app-barred-transaction-report/$', 'app_barred_transaction_report'),
    url(r'^manager/app-transaction-report/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'app_transaction_data'),
    url(r'^manager/telecaller-productivty-report/$', 'telecaller_productivity_report'),
    url(r'^manager/telecaller-productivity-data/from/(?P<from_time>[\d-]+)/to/(?P<to_time>[\d-]+)/$', 'telecaller_productivity_data'),
    url(r'^search/$', 'search'),
    url(r'^doc-status/(?P<app_id>\w+)/$', 'doc_status'),
    url(r'^single-screen/(?P<app_id>\w+)/$', 'single_screen'),
    url(r'^courier-status/(?P<app_id>\w+)/$', 'courier_status'),

    url(r'^application-tracker/$', 'application_tracker'),
    url(r'^write-to-excel/$', 'write_to_excel'),
    url(r'^emerge/dashboard/$', TemplateView.as_view(template_name='core/data_upload.html')), #17th may 2016
    url(r'^emerge-upload/$', 'emerge_upload'), #17th may 2016

    url(r'^uhc-download/$', 'uhc_download'),
    url(r'^uhc/dashboard/$', TemplateView.as_view(template_name='core/uhc_dashboard.html')),
    url(r'^uhc-upload/$', 'uhc_upload'),
    url(r'^uhc-validation/$', 'uhc_validation'),
    url(r'^manager/downloads/uhc_download/$','uhc_download_report'),
    url(r'^make-call/(?P<mobile>[\d-]+)/(?P<application>[\w-]+)/(?P<cid>[\d-]+)', 'make_call'),
    url(r'^manager/downloads/requirement_list/$','requirement_list_report'),

                       
)

