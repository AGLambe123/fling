from django import template
from django.template.defaultfilters import stringfilter

import time
import os
from django.db.models import Q

register = template.Library()
from core.models import *
import iutils

@register.filter
@stringfilter
def get_photo(value,arg):
    v = os.path.splitext(value)
    newname = "%s%s%s" % (v[0],arg,v[1])
    return newname

@register.filter
@stringfilter
def split_str(value,arg):
    return value[:arg]

@register.filter
@stringfilter
def get_plan(value):
    return iutils.get_plan(value)

@register.filter
def lookup(value, arg):
    return value.get(arg)

@register.filter
def make_dict(value):
    return value.split(",")

@register.filter
def get_smses_by_callhistory(app_smses, callhistory_id):
    smses = []
    for s in app_smses:
        if str(s.source_id) == str(callhistory_id):
            smses.append(s)
    return smses

@register.filter
@stringfilter
def sanitize_fup(value):
    v = value.split("-")
    if len(v) > 1:
        v = "-".join(v[1:])
    else:
        v = v[0]
    v = v.upper().replace('KYC',"").replace("IUW","Internal").replace("-"," ").title()
    return v  

