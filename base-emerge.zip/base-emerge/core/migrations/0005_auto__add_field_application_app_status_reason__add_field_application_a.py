# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding field 'Application.app_status_reason'
        db.add_column(u'core_application', 'app_status_reason',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.app_uw_amount'
        db.add_column(u'core_application', 'app_uw_amount',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.app_uw_reason'
        db.add_column(u'core_application', 'app_uw_reason',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'ApplicationCallAttribute.app_status_reason'
        db.add_column(u'core_applicationcallattribute', 'app_status_reason',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'ApplicationCallAttribute.app_uw_amount'
        db.add_column(u'core_applicationcallattribute', 'app_uw_amount',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'ApplicationCallAttribute.app_uw_reason'
        db.add_column(u'core_applicationcallattribute', 'app_uw_reason',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)


    def backwards(self, orm):
        # Deleting field 'Application.app_status_reason'
        db.delete_column(u'core_application', 'app_status_reason')

        # Deleting field 'Application.app_uw_amount'
        db.delete_column(u'core_application', 'app_uw_amount')

        # Deleting field 'Application.app_uw_reason'
        db.delete_column(u'core_application', 'app_uw_reason')

        # Deleting field 'ApplicationCallAttribute.app_status_reason'
        db.delete_column(u'core_applicationcallattribute', 'app_status_reason')

        # Deleting field 'ApplicationCallAttribute.app_uw_amount'
        db.delete_column(u'core_applicationcallattribute', 'app_uw_amount')

        # Deleting field 'ApplicationCallAttribute.app_uw_reason'
        db.delete_column(u'core_applicationcallattribute', 'app_uw_reason')


    models = {
        u'auth.group': {
            'Meta': {'object_name': 'Group'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        u'auth.permission': {
            'Meta': {'ordering': "(u'content_type__app_label', u'content_type__model', u'codename')", 'unique_together': "((u'content_type', u'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['contenttypes.ContentType']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        u'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        u'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.application': {
            'Meta': {'object_name': 'Application'},
            'acc_death_benefit': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'agent_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'annual_income': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'annual_premium': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'app_id': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'app_number': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'app_status_reason': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'app_uw_amount': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'app_uw_reason': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_dob': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_first_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_relationship': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'area': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'banner_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'birth_city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'birth_state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'building': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'designation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'dob': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'duty_nature': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'education': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'eia_number': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'employer_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'first_issuance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'db_index': 'True'}),
            'flat': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'fsc_channel': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'fup_associated': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.FupAssociated']", 'null': 'True', 'blank': 'True'}),
            'gender': ('django.db.models.fields.CharField', [], {'max_length': '10'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'industry_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'insurance_purpose': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'ir_email': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'ir_name': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'last_name': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'marital_status': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '20', 'blank': 'True'}),
            'months_withemployer': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'nationality': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'nominee_dob': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_first_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_relationship': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'occupation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'org_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_area': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_building': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'p_flat': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_mobile': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'p_road': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'pancard_number': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pay_amount': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'pay_type': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_bank': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_gateway': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'politically_exposed': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'politically_exposeddetails': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'product_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'promo_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'proposal_acceptance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'road': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'site_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'sum_assured': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'tracker_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'transaction_end_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'transaction_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'transaction_start_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'uid_number': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'years_withemployer': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'})
        },
        u'core.applicationcallattribute': {
            'Meta': {'object_name': 'ApplicationCallAttribute'},
            'address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'airway_bill_no': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'app_status_reason': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'app_uw_amount': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'app_uw_reason': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'call_barred': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'courier_company_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'courier_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'courier_time': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'document_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'document_delivery_method': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_delivery_method_used': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'fup_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'if_courier_servicable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'is_ats_uploaded': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_fup_closed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_taken': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'last_fup_received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'mecode': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Mecode']", 'null': 'True', 'blank': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'p_address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.appstatus': {
            'Meta': {'object_name': 'AppStatus'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '10'})
        },
        u'core.callhistory': {
            'Meta': {'object_name': 'CallHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'call_type': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_success': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'predefined_remark': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'priority': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.callpriority': {
            'Meta': {'object_name': 'CallPriority'},
            'call_later': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'fresh': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reminder': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'thankinprogress': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome_and_verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.courierdata': {
            'Meta': {'object_name': 'CourierData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'call_category': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'call_id1': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id2': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id3': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.fup': {
            'Meta': {'object_name': 'FUP'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_medical': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.fupassociated': {
            'Meta': {'object_name': 'FupAssociated'},
            'code': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.FUP']"}),
            'generated_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'jet_decision': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.mecode': {
            'Meta': {'object_name': 'Mecode'},
            'account': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address1': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'address2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address3': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address4': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'bank_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'contact_person': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'emailid': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'me_code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'me_name': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'mobileno': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mode_of_payment': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'ownership': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pan': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'payor_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone1': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'rating': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.plan': {
            'Meta': {'object_name': 'Plan'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.saleclaim': {
            'Meta': {'object_name': 'SaleClaim'},
            'app_id': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'associated_applications': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Application']", 'null': 'True', 'blank': 'True'}),
            'campaign_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'debug_log': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'first_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'match_status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'premium': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'sem': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']"})
        },
        u'core.servicablecourierpincode': {
            'Meta': {'object_name': 'ServicableCourierPincode'},
            'description': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'pin': ('django.db.models.fields.IntegerField', [], {'primary_key': 'True'})
        },
        u'core.smshistory': {
            'Meta': {'object_name': 'SmsHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'message': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'message_category': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'mobile_to': ('django.db.models.fields.CharField', [], {'max_length': '20'}),
            'source': ('django.db.models.fields.CharField', [], {'max_length': '250'}),
            'source_id': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'})
        },
        u'core.uhcdata': {
            'Meta': {'object_name': 'UHCData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'final_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'first_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'path_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks2': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks3': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'second_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'third_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.uploadfile': {
            'Meta': {'object_name': 'UploadFile'},
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_processed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'output': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'upload_file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'})
        },
        u'core.userprofile': {
            'Meta': {'object_name': 'UserProfile'},
            'activation_key': ('django.db.models.fields.CharField', [], {'max_length': '40', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'job_title': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'network_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['auth.User']", 'unique': 'True'})
        }
    }

    complete_apps = ['core']