# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Deleting field 'Application.fsc_bank_name'
        db.delete_column(u'core_application', 'fsc_bank_name')

        # Deleting field 'Application.iad_product_code'
        db.delete_column(u'core_application', 'iad_product_code')

        # Deleting field 'Application.advisor_name'
        db.delete_column(u'core_application', 'advisor_name')

        # Deleting field 'Application.web_transaction_id'
        db.delete_column(u'core_application', 'web_transaction_id')

        # Deleting field 'Application.address1'
        db.delete_column(u'core_application', 'address1')

        # Deleting field 'Application.address2'
        db.delete_column(u'core_application', 'address2')

        # Deleting field 'Application.ipd_pancard_number'
        db.delete_column(u'core_application', 'ipd_pancard_number')

        # Deleting field 'Application.ipd_fsc_code'
        db.delete_column(u'core_application', 'ipd_fsc_code')

        # Deleting field 'Application.iad_site_id'
        db.delete_column(u'core_application', 'iad_site_id')

        # Deleting field 'Application.ipd_agent_code'
        db.delete_column(u'core_application', 'ipd_agent_code')

        # Deleting field 'Application.iad_promo_id'
        db.delete_column(u'core_application', 'iad_promo_id')

        # Deleting field 'Application.advisor_code'
        db.delete_column(u'core_application', 'advisor_code')

        # Deleting field 'Application.ipd_father_name'
        db.delete_column(u'core_application', 'ipd_father_name')

        # Deleting field 'Application.icb_id'
        db.delete_column(u'core_application', 'icb_id')

        # Deleting field 'Application.ipd_industry_type'
        db.delete_column(u'core_application', 'ipd_industry_type')

        # Deleting field 'Application.iad_finops_status'
        db.delete_column(u'core_application', 'iad_finops_status')

        # Deleting field 'Application.advisor_contact_no'
        db.delete_column(u'core_application', 'advisor_contact_no')

        # Deleting field 'Application.iad_banner_id'
        db.delete_column(u'core_application', 'iad_banner_id')

        # Deleting field 'Application.fsc_name'
        db.delete_column(u'core_application', 'fsc_name')

        # Deleting field 'Application.iad_source'
        db.delete_column(u'core_application', 'iad_source')

        # Deleting field 'Application.fsc_code'
        db.delete_column(u'core_application', 'fsc_code')

        # Deleting field 'Application.fsc_branch_name'
        db.delete_column(u'core_application', 'fsc_branch_name')

        # Deleting field 'Application.branch_name'
        db.delete_column(u'core_application', 'branch_name')

        # Deleting field 'Application.ape_amount'
        db.delete_column(u'core_application', 'ape_amount')

        # Deleting field 'Application.p_address1'
        db.delete_column(u'core_application', 'p_address1')

        # Deleting field 'Application.p_address2'
        db.delete_column(u'core_application', 'p_address2')

        # Deleting field 'Application.fsc_contact_no'
        db.delete_column(u'core_application', 'fsc_contact_no')

        # Deleting field 'Application.iad_cops_status'
        db.delete_column(u'core_application', 'iad_cops_status')

        # Deleting field 'Application.iad_fsc_channel'
        db.delete_column(u'core_application', 'iad_fsc_channel')

        # Deleting field 'Application.iad_app_datetime'
        db.delete_column(u'core_application', 'iad_app_datetime')

        # Deleting field 'Application.fsc_source_code'
        db.delete_column(u'core_application', 'fsc_source_code')

        # Deleting field 'Application.iad_acc_death_benefit'
        db.delete_column(u'core_application', 'iad_acc_death_benefit')

        # Adding field 'Application.tracker_id'
        db.add_column(u'core_application', 'tracker_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.birth_state'
        db.add_column(u'core_application', 'birth_state',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.birth_city'
        db.add_column(u'core_application', 'birth_city',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.employer_name'
        db.add_column(u'core_application', 'employer_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.duty_nature'
        db.add_column(u'core_application', 'duty_nature',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.years_withemployer'
        db.add_column(u'core_application', 'years_withemployer',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.months_withemployer'
        db.add_column(u'core_application', 'months_withemployer',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.flat'
        db.add_column(u'core_application', 'flat',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.building'
        db.add_column(u'core_application', 'building',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.road'
        db.add_column(u'core_application', 'road',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.area'
        db.add_column(u'core_application', 'area',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.father_name'
        db.add_column(u'core_application', 'father_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.industry_type'
        db.add_column(u'core_application', 'industry_type',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.pancard_number'
        db.add_column(u'core_application', 'pancard_number',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.p_flat'
        db.add_column(u'core_application', 'p_flat',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.p_building'
        db.add_column(u'core_application', 'p_building',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.p_road'
        db.add_column(u'core_application', 'p_road',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.p_area'
        db.add_column(u'core_application', 'p_area',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.eia_number'
        db.add_column(u'core_application', 'eia_number',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=20, blank=True),
                      keep_default=False)

        # Adding field 'Application.ir_name'
        db.add_column(u'core_application', 'ir_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=20, blank=True),
                      keep_default=False)

        # Adding field 'Application.ir_email'
        db.add_column(u'core_application', 'ir_email',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=20, blank=True),
                      keep_default=False)

        # Adding field 'Application.acc_death_benefit'
        db.add_column(u'core_application', 'acc_death_benefit',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.banner_id'
        db.add_column(u'core_application', 'banner_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.promo_id'
        db.add_column(u'core_application', 'promo_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_channel'
        db.add_column(u'core_application', 'fsc_channel',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.site_id'
        db.add_column(u'core_application', 'site_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.nominee_title'
        db.add_column(u'core_application', 'nominee_title',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.nominee_first_name'
        db.add_column(u'core_application', 'nominee_first_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.nominee_last_name'
        db.add_column(u'core_application', 'nominee_last_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.nominee_dob'
        db.add_column(u'core_application', 'nominee_dob',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.nominee_relationship'
        db.add_column(u'core_application', 'nominee_relationship',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.appointee_title'
        db.add_column(u'core_application', 'appointee_title',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.appointee_first_name'
        db.add_column(u'core_application', 'appointee_first_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.appointee_last_name'
        db.add_column(u'core_application', 'appointee_last_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.appointee_dob'
        db.add_column(u'core_application', 'appointee_dob',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.appointee_relationship'
        db.add_column(u'core_application', 'appointee_relationship',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)

        # Adding field 'Application.insurance_purpose'
        db.add_column(u'core_application', 'insurance_purpose',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=255, blank=True),
                      keep_default=False)


    def backwards(self, orm):
        # Adding field 'Application.fsc_bank_name'
        db.add_column(u'core_application', 'fsc_bank_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_product_code'
        db.add_column(u'core_application', 'iad_product_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.advisor_name'
        db.add_column(u'core_application', 'advisor_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.web_transaction_id'
        db.add_column(u'core_application', 'web_transaction_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.address1'
        db.add_column(u'core_application', 'address1',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.address2'
        db.add_column(u'core_application', 'address2',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.ipd_pancard_number'
        db.add_column(u'core_application', 'ipd_pancard_number',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.ipd_fsc_code'
        db.add_column(u'core_application', 'ipd_fsc_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_site_id'
        db.add_column(u'core_application', 'iad_site_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.ipd_agent_code'
        db.add_column(u'core_application', 'ipd_agent_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_promo_id'
        db.add_column(u'core_application', 'iad_promo_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.advisor_code'
        db.add_column(u'core_application', 'advisor_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.ipd_father_name'
        db.add_column(u'core_application', 'ipd_father_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)


        # User chose to not deal with backwards NULL issues for 'Application.icb_id'
        raise RuntimeError("Cannot reverse this migration. 'Application.icb_id' and its values cannot be restored.")
        
        # The following code is provided here to aid in writing a correct migration        # Adding field 'Application.icb_id'
        db.add_column(u'core_application', 'icb_id',
                      self.gf('django.db.models.fields.CharField')(max_length=100),
                      keep_default=False)

        # Adding field 'Application.ipd_industry_type'
        db.add_column(u'core_application', 'ipd_industry_type',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_finops_status'
        db.add_column(u'core_application', 'iad_finops_status',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.advisor_contact_no'
        db.add_column(u'core_application', 'advisor_contact_no',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_banner_id'
        db.add_column(u'core_application', 'iad_banner_id',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_name'
        db.add_column(u'core_application', 'fsc_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_source'
        db.add_column(u'core_application', 'iad_source',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_code'
        db.add_column(u'core_application', 'fsc_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_branch_name'
        db.add_column(u'core_application', 'fsc_branch_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.branch_name'
        db.add_column(u'core_application', 'branch_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.ape_amount'
        db.add_column(u'core_application', 'ape_amount',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.p_address1'
        db.add_column(u'core_application', 'p_address1',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.p_address2'
        db.add_column(u'core_application', 'p_address2',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_contact_no'
        db.add_column(u'core_application', 'fsc_contact_no',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=200, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_cops_status'
        db.add_column(u'core_application', 'iad_cops_status',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_fsc_channel'
        db.add_column(u'core_application', 'iad_fsc_channel',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_app_datetime'
        db.add_column(u'core_application', 'iad_app_datetime',
                      self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'Application.fsc_source_code'
        db.add_column(u'core_application', 'fsc_source_code',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=100, blank=True),
                      keep_default=False)

        # Adding field 'Application.iad_acc_death_benefit'
        db.add_column(u'core_application', 'iad_acc_death_benefit',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=50, blank=True),
                      keep_default=False)

        # Deleting field 'Application.tracker_id'
        db.delete_column(u'core_application', 'tracker_id')

        # Deleting field 'Application.birth_state'
        db.delete_column(u'core_application', 'birth_state')

        # Deleting field 'Application.birth_city'
        db.delete_column(u'core_application', 'birth_city')

        # Deleting field 'Application.employer_name'
        db.delete_column(u'core_application', 'employer_name')

        # Deleting field 'Application.duty_nature'
        db.delete_column(u'core_application', 'duty_nature')

        # Deleting field 'Application.years_withemployer'
        db.delete_column(u'core_application', 'years_withemployer')

        # Deleting field 'Application.months_withemployer'
        db.delete_column(u'core_application', 'months_withemployer')

        # Deleting field 'Application.flat'
        db.delete_column(u'core_application', 'flat')

        # Deleting field 'Application.building'
        db.delete_column(u'core_application', 'building')

        # Deleting field 'Application.road'
        db.delete_column(u'core_application', 'road')

        # Deleting field 'Application.area'
        db.delete_column(u'core_application', 'area')

        # Deleting field 'Application.father_name'
        db.delete_column(u'core_application', 'father_name')

        # Deleting field 'Application.industry_type'
        db.delete_column(u'core_application', 'industry_type')

        # Deleting field 'Application.pancard_number'
        db.delete_column(u'core_application', 'pancard_number')

        # Deleting field 'Application.p_flat'
        db.delete_column(u'core_application', 'p_flat')

        # Deleting field 'Application.p_building'
        db.delete_column(u'core_application', 'p_building')

        # Deleting field 'Application.p_road'
        db.delete_column(u'core_application', 'p_road')

        # Deleting field 'Application.p_area'
        db.delete_column(u'core_application', 'p_area')

        # Deleting field 'Application.eia_number'
        db.delete_column(u'core_application', 'eia_number')

        # Deleting field 'Application.ir_name'
        db.delete_column(u'core_application', 'ir_name')

        # Deleting field 'Application.ir_email'
        db.delete_column(u'core_application', 'ir_email')

        # Deleting field 'Application.acc_death_benefit'
        db.delete_column(u'core_application', 'acc_death_benefit')

        # Deleting field 'Application.banner_id'
        db.delete_column(u'core_application', 'banner_id')

        # Deleting field 'Application.promo_id'
        db.delete_column(u'core_application', 'promo_id')

        # Deleting field 'Application.fsc_channel'
        db.delete_column(u'core_application', 'fsc_channel')

        # Deleting field 'Application.site_id'
        db.delete_column(u'core_application', 'site_id')

        # Deleting field 'Application.nominee_title'
        db.delete_column(u'core_application', 'nominee_title')

        # Deleting field 'Application.nominee_first_name'
        db.delete_column(u'core_application', 'nominee_first_name')

        # Deleting field 'Application.nominee_last_name'
        db.delete_column(u'core_application', 'nominee_last_name')

        # Deleting field 'Application.nominee_dob'
        db.delete_column(u'core_application', 'nominee_dob')

        # Deleting field 'Application.nominee_relationship'
        db.delete_column(u'core_application', 'nominee_relationship')

        # Deleting field 'Application.appointee_title'
        db.delete_column(u'core_application', 'appointee_title')

        # Deleting field 'Application.appointee_first_name'
        db.delete_column(u'core_application', 'appointee_first_name')

        # Deleting field 'Application.appointee_last_name'
        db.delete_column(u'core_application', 'appointee_last_name')

        # Deleting field 'Application.appointee_dob'
        db.delete_column(u'core_application', 'appointee_dob')

        # Deleting field 'Application.appointee_relationship'
        db.delete_column(u'core_application', 'appointee_relationship')

        # Deleting field 'Application.insurance_purpose'
        db.delete_column(u'core_application', 'insurance_purpose')


    models = {
        u'auth.group': {
            'Meta': {'object_name': 'Group'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        u'auth.permission': {
            'Meta': {'ordering': "(u'content_type__app_label', u'content_type__model', u'codename')", 'unique_together': "((u'content_type', u'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['contenttypes.ContentType']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        u'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        u'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.application': {
            'Meta': {'object_name': 'Application'},
            'acc_death_benefit': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'agent_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'annual_income': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'annual_premium': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'app_id': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'app_number': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'appointee_dob': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_first_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_relationship': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'appointee_title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'area': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'banner_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'birth_city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'birth_state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'building': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'designation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'dob': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'duty_nature': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'education': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'eia_number': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'employer_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'first_issuance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'db_index': 'True'}),
            'flat': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'fsc_channel': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'fup_associated': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.FupAssociated']", 'null': 'True', 'blank': 'True'}),
            'gender': ('django.db.models.fields.CharField', [], {'max_length': '10'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'industry_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'insurance_purpose': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'ir_email': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'ir_name': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'last_name': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'marital_status': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '20', 'blank': 'True'}),
            'months_withemployer': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'nationality': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'nominee_dob': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_first_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_relationship': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'nominee_title': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'occupation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'org_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_area': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_building': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'p_flat': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_mobile': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'p_road': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'pancard_number': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pay_amount': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'pay_type': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_bank': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_gateway': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'product_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'promo_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'proposal_acceptance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'road': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'site_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'sum_assured': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'tracker_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'transaction_end_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'transaction_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'transaction_start_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'years_withemployer': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'})
        },
        u'core.applicationcallattribute': {
            'Meta': {'object_name': 'ApplicationCallAttribute'},
            'address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'airway_bill_no': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'call_barred': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'courier_company_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'courier_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'courier_time': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'document_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'document_delivery_method': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_delivery_method_used': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'fup_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'if_courier_servicable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'is_ats_uploaded': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_fup_closed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_taken': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'last_fup_received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'mecode': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Mecode']", 'null': 'True', 'blank': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'p_address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.appstatus': {
            'Meta': {'object_name': 'AppStatus'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '10'})
        },
        u'core.callhistory': {
            'Meta': {'object_name': 'CallHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'call_type': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_success': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'predefined_remark': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'priority': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.callpriority': {
            'Meta': {'object_name': 'CallPriority'},
            'call_later': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'fresh': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reminder': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'thankinprogress': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome_and_verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.courierdata': {
            'Meta': {'object_name': 'CourierData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'call_category': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'call_id1': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id2': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id3': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.fup': {
            'Meta': {'object_name': 'FUP'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_medical': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.fupassociated': {
            'Meta': {'object_name': 'FupAssociated'},
            'code': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.FUP']"}),
            'generated_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'jet_decision': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.mecode': {
            'Meta': {'object_name': 'Mecode'},
            'account': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address1': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'address2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address3': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address4': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'bank_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'contact_person': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'emailid': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'me_code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'me_name': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'mobileno': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mode_of_payment': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'ownership': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pan': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'payor_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone1': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'rating': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.plan': {
            'Meta': {'object_name': 'Plan'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.saleclaim': {
            'Meta': {'object_name': 'SaleClaim'},
            'app_id': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'associated_applications': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Application']", 'null': 'True', 'blank': 'True'}),
            'campaign_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'debug_log': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'first_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'match_status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'premium': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'sem': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']"})
        },
        u'core.servicablecourierpincode': {
            'Meta': {'object_name': 'ServicableCourierPincode'},
            'description': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'pin': ('django.db.models.fields.IntegerField', [], {'primary_key': 'True'})
        },
        u'core.smshistory': {
            'Meta': {'object_name': 'SmsHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'message': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'message_category': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'mobile_to': ('django.db.models.fields.CharField', [], {'max_length': '20'}),
            'source': ('django.db.models.fields.CharField', [], {'max_length': '250'}),
            'source_id': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'})
        },
        u'core.uhcdata': {
            'Meta': {'object_name': 'UHCData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'final_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'first_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'path_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks2': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks3': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'second_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'third_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.uploadfile': {
            'Meta': {'object_name': 'UploadFile'},
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_processed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'output': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'upload_file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'})
        },
        u'core.userprofile': {
            'Meta': {'object_name': 'UserProfile'},
            'activation_key': ('django.db.models.fields.CharField', [], {'max_length': '40', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'job_title': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'network_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['auth.User']", 'unique': 'True'})
        }
    }

    complete_apps = ['core']