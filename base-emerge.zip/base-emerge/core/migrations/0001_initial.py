# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'ServicableCourierPincode'
        db.create_table(u'core_servicablecourierpincode', (
            ('pin', self.gf('django.db.models.fields.IntegerField')(primary_key=True)),
            ('description', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal(u'core', ['ServicableCourierPincode'])

        # Adding model 'Plan'
        db.create_table(u'core_plan', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('code', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=200)),
        ))
        db.send_create_signal(u'core', ['Plan'])

        # Adding model 'CallPriority'
        db.create_table(u'core_callpriority', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('call_later', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('fresh', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('welcome', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('welcome_and_verification', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('verification', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('reminder', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('thankinprogress', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal(u'core', ['CallPriority'])

        # Adding model 'Mecode'
        db.create_table(u'core_mecode', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('me_code', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('me_name', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('address1', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('address2', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address3', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address4', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('city', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('pincode', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('phone1', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('phone2', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('mobileno', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('emailid', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('contact_person', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('ownership', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('pan', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('mode_of_payment', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('account', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('bank_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('payor_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('rating', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('status', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
        ))
        db.send_create_signal(u'core', ['Mecode'])

        # Adding model 'UserProfile'
        db.create_table(u'core_userprofile', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['auth.User'], unique=True)),
            ('role', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('phone', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('organization', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('job_title', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('network_id', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('activation_key', self.gf('django.db.models.fields.CharField')(max_length=40, blank=True)),
        ))
        db.send_create_signal(u'core', ['UserProfile'])

        # Adding model 'CallHistory'
        db.create_table(u'core_callhistory', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('application', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.Application'])),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('disposition', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('call_type', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('is_success', self.gf('django.db.models.fields.BooleanField')(default=True)),
            ('next_calltime', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('priority', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('assigned_to', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'], null=True, blank=True)),
            ('remarks', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('predefined_remark', self.gf('django.db.models.fields.CharField')(max_length=150, blank=True)),
            ('is_call_later', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal(u'core', ['CallHistory'])

        # Adding model 'ApplicationCallAttribute'
        db.create_table(u'core_applicationcallattribute', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('application', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['core.Application'], unique=True)),
            ('contract_id', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('address1', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('p_address1', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('courier_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('courier_time', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('fup_commited_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('document_commited_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('photo_id_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('age_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('income_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('attested_photograph', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('photo_id_proof_rcvd', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('age_proof_rcvd', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address_proof_rcvd', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('income_proof_rcvd', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('attested_photograph_rcvd', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('document_delivery_method_used', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('document_remarks', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('photo_id_proof_rcvd_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('age_proof_rcvd_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('address_proof_rcvd_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('income_proof_rcvd_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('attested_photograph_rcvd_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('if_courier_servicable', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('document_delivery_method', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('is_fup_closed', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('last_fup_received_on', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('app_status', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('last_call_status', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('is_taken', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('assigned_to', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'], null=True, blank=True)),
            ('call_barred', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('next_calltime', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('is_call_later', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('is_ats_uploaded', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('airway_bill_no', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('courier_company_name', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
        ))
        db.send_create_signal(u'core', ['ApplicationCallAttribute'])

        # Adding M2M table for field mecode on 'ApplicationCallAttribute'
        m2m_table_name = db.shorten_name(u'core_applicationcallattribute_mecode')
        db.create_table(m2m_table_name, (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('applicationcallattribute', models.ForeignKey(orm[u'core.applicationcallattribute'], null=False)),
            ('mecode', models.ForeignKey(orm[u'core.mecode'], null=False))
        ))
        db.create_unique(m2m_table_name, ['applicationcallattribute_id', 'mecode_id'])

        # Adding model 'AppStatus'
        db.create_table(u'core_appstatus', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=10)),
            ('description', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal(u'core', ['AppStatus'])

        # Adding model 'FupAssociated'
        db.create_table(u'core_fupassociated', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('code', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.FUP'])),
            ('generated_on', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('received_on', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('jet_decision', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
        ))
        db.send_create_signal(u'core', ['FupAssociated'])

        # Adding model 'FUP'
        db.create_table(u'core_fup', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('description', self.gf('django.db.models.fields.TextField')()),
            ('is_medical', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal(u'core', ['FUP'])

        # Adding model 'SaleClaim'
        db.create_table(u'core_saleclaim', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('first_name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('last_name', self.gf('django.db.models.fields.CharField')(max_length=255, blank=True)),
            ('email', self.gf('django.db.models.fields.EmailField')(max_length=255, blank=True)),
            ('mobile', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('premium', self.gf('django.db.models.fields.CharField')(max_length=255, blank=True)),
            ('first_call_date', self.gf('django.db.models.fields.DateTimeField')()),
            ('last_call_date', self.gf('django.db.models.fields.DateTimeField')()),
            ('app_id', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=255, blank=True)),
            ('campaign_id', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('sem', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('debug_log', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('disposition', self.gf('django.db.models.fields.CharField')(max_length=255, blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('match_status', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('organization', self.gf('django.db.models.fields.CharField')(max_length=200)),
        ))
        db.send_create_signal(u'core', ['SaleClaim'])

        # Adding M2M table for field associated_applications on 'SaleClaim'
        m2m_table_name = db.shorten_name(u'core_saleclaim_associated_applications')
        db.create_table(m2m_table_name, (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('saleclaim', models.ForeignKey(orm[u'core.saleclaim'], null=False)),
            ('application', models.ForeignKey(orm[u'core.application'], null=False))
        ))
        db.create_unique(m2m_table_name, ['saleclaim_id', 'application_id'])

        # Adding model 'Application'
        db.create_table(u'core_application', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('app_id', self.gf('django.db.models.fields.CharField')(unique=True, max_length=100)),
            ('contract_id', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('app_number', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('icb_id', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('first_name', self.gf('django.db.models.fields.CharField')(max_length=200, db_index=True)),
            ('last_name', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=200, blank=True)),
            ('gender', self.gf('django.db.models.fields.CharField')(max_length=10)),
            ('dob', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('marital_status', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('nationality', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('education', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('occupation', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('org_type', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('designation', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('annual_income', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address1', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('address2', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('landmark', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('city', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('pincode', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('state', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('country', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('email', self.gf('django.db.models.fields.EmailField')(db_index=True, max_length=255, blank=True)),
            ('mobile', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=20, blank=True)),
            ('stdcode', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('landline', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('p_address1', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('p_address2', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('p_landmark', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('p_city', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('p_pincode', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('p_state', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('p_country', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('p_email', self.gf('django.db.models.fields.EmailField')(max_length=255, blank=True)),
            ('p_mobile', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('p_stdcode', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('p_landline', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('photo_id_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('age_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('address_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('income_proof', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('attested_photograph', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('ipd_agent_code', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('ipd_fsc_code', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('ipd_father_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('ipd_industry_type', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('ipd_pancard_number', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('iad_app_datetime', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('iad_cops_status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('iad_finops_status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('iad_product_code', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('iad_source', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('sum_assured', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('annual_premium', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('iad_acc_death_benefit', self.gf('django.db.models.fields.CharField')(max_length=50, blank=True)),
            ('iad_banner_id', self.gf('django.db.models.fields.CharField')(max_length=50, blank=True)),
            ('iad_promo_id', self.gf('django.db.models.fields.CharField')(max_length=50, blank=True)),
            ('iad_fsc_channel', self.gf('django.db.models.fields.CharField')(max_length=50, blank=True)),
            ('iad_site_id', self.gf('django.db.models.fields.CharField')(max_length=50, blank=True)),
            ('pay_amount', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('pay_type', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('payment_gateway', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('transaction_id', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('transaction_start_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('transaction_end_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('payment_status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('web_transaction_id', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('payment_bank', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('product_code', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('ape_amount', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('app_status', self.gf('django.db.models.fields.CharField')(max_length=150, blank=True)),
            ('proposal_acceptance_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('first_issuance_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('agent_id', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('fsc_bank_name', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('fsc_branch_name', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('fsc_source_code', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('advisor_code', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('advisor_contact_no', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('advisor_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('fsc_code', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('fsc_contact_no', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('fsc_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('branch_name', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
        ))
        db.send_create_signal(u'core', ['Application'])

        # Adding M2M table for field fup_associated on 'Application'
        m2m_table_name = db.shorten_name(u'core_application_fup_associated')
        db.create_table(m2m_table_name, (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('application', models.ForeignKey(orm[u'core.application'], null=False)),
            ('fupassociated', models.ForeignKey(orm[u'core.fupassociated'], null=False))
        ))
        db.create_unique(m2m_table_name, ['application_id', 'fupassociated_id'])

        # Adding model 'UploadFile'
        db.create_table(u'core_uploadfile', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('upload_file', self.gf('django.db.models.fields.files.FileField')(max_length=100)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'], null=True, blank=True)),
            ('output', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('is_processed', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal(u'core', ['UploadFile'])

        # Adding model 'UHCData'
        db.create_table(u'core_uhcdata', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('application', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['core.Application'], unique=True)),
            ('first_call_on', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('remarks1', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('second_call_on', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('remarks2', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('third_call_on', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('remarks3', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('path_appt_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('path_appt_time', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('path_test_name', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('path_dc_name', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('tmt_appt_date', self.gf('django.db.models.fields.DateField')(null=True, blank=True)),
            ('tmt_appt_time', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('tmt_test_name', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('tmt_dc_name', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('last_call_status', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('final_status', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
        ))
        db.send_create_signal(u'core', ['UHCData'])

        # Adding model 'CourierData'
        db.create_table(u'core_courierdata', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('application', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['core.Application'], unique=True)),
            ('remarks', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('call_category', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('call_id1', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('call_id2', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('call_id3', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal(u'core', ['CourierData'])

        # Adding model 'SmsHistory'
        db.create_table(u'core_smshistory', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('application', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.Application'])),
            ('source', self.gf('django.db.models.fields.CharField')(max_length=250)),
            ('source_id', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('message_category', self.gf('django.db.models.fields.CharField')(max_length=250, blank=True)),
            ('mobile_to', self.gf('django.db.models.fields.CharField')(max_length=20)),
            ('message', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal(u'core', ['SmsHistory'])


    def backwards(self, orm):
        # Deleting model 'ServicableCourierPincode'
        db.delete_table(u'core_servicablecourierpincode')

        # Deleting model 'Plan'
        db.delete_table(u'core_plan')

        # Deleting model 'CallPriority'
        db.delete_table(u'core_callpriority')

        # Deleting model 'Mecode'
        db.delete_table(u'core_mecode')

        # Deleting model 'UserProfile'
        db.delete_table(u'core_userprofile')

        # Deleting model 'CallHistory'
        db.delete_table(u'core_callhistory')

        # Deleting model 'ApplicationCallAttribute'
        db.delete_table(u'core_applicationcallattribute')

        # Removing M2M table for field mecode on 'ApplicationCallAttribute'
        db.delete_table(db.shorten_name(u'core_applicationcallattribute_mecode'))

        # Deleting model 'AppStatus'
        db.delete_table(u'core_appstatus')

        # Deleting model 'FupAssociated'
        db.delete_table(u'core_fupassociated')

        # Deleting model 'FUP'
        db.delete_table(u'core_fup')

        # Deleting model 'SaleClaim'
        db.delete_table(u'core_saleclaim')

        # Removing M2M table for field associated_applications on 'SaleClaim'
        db.delete_table(db.shorten_name(u'core_saleclaim_associated_applications'))

        # Deleting model 'Application'
        db.delete_table(u'core_application')

        # Removing M2M table for field fup_associated on 'Application'
        db.delete_table(db.shorten_name(u'core_application_fup_associated'))

        # Deleting model 'UploadFile'
        db.delete_table(u'core_uploadfile')

        # Deleting model 'UHCData'
        db.delete_table(u'core_uhcdata')

        # Deleting model 'CourierData'
        db.delete_table(u'core_courierdata')

        # Deleting model 'SmsHistory'
        db.delete_table(u'core_smshistory')


    models = {
        u'auth.group': {
            'Meta': {'object_name': 'Group'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        u'auth.permission': {
            'Meta': {'ordering': "(u'content_type__app_label', u'content_type__model', u'codename')", 'unique_together': "((u'content_type', u'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['contenttypes.ContentType']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        u'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        u'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.application': {
            'Meta': {'object_name': 'Application'},
            'address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'address2': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'advisor_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'advisor_contact_no': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'advisor_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'agent_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'annual_income': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'annual_premium': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'ape_amount': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'app_id': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'app_number': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'branch_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'designation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'dob': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'education': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'first_issuance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'db_index': 'True'}),
            'fsc_bank_name': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'fsc_branch_name': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'fsc_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'fsc_contact_no': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'fsc_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'fsc_source_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'fup_associated': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.FupAssociated']", 'null': 'True', 'blank': 'True'}),
            'gender': ('django.db.models.fields.CharField', [], {'max_length': '10'}),
            'iad_acc_death_benefit': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'iad_app_datetime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'iad_banner_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'iad_cops_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'iad_finops_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'iad_fsc_channel': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'iad_product_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'iad_promo_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'iad_site_id': ('django.db.models.fields.CharField', [], {'max_length': '50', 'blank': 'True'}),
            'iad_source': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'icb_id': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'ipd_agent_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'ipd_father_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'ipd_fsc_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'ipd_industry_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'ipd_pancard_number': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'last_name': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'marital_status': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '20', 'blank': 'True'}),
            'nationality': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'occupation': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'org_type': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_address2': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'p_city': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_country': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'p_landline': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_landmark': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_mobile': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'p_pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'p_state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'p_stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'pay_amount': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'pay_type': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_bank': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_gateway': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'payment_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'product_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'proposal_acceptance_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'stdcode': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'sum_assured': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'transaction_end_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'transaction_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'transaction_start_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'web_transaction_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'})
        },
        u'core.applicationcallattribute': {
            'Meta': {'object_name': 'ApplicationCallAttribute'},
            'address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'address_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'age_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'age_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'airway_bill_no': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'app_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'attested_photograph': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'attested_photograph_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'call_barred': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'contract_id': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'courier_company_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'courier_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'courier_time': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'document_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'document_delivery_method': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_delivery_method_used': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'document_remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'fup_commited_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'if_courier_servicable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'income_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'income_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'is_ats_uploaded': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_fup_closed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_taken': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'last_fup_received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'mecode': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Mecode']", 'null': 'True', 'blank': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'p_address1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'photo_id_proof': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'photo_id_proof_rcvd_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.appstatus': {
            'Meta': {'object_name': 'AppStatus'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '10'})
        },
        u'core.callhistory': {
            'Meta': {'object_name': 'CallHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'call_type': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_call_later': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_success': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'next_calltime': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'predefined_remark': ('django.db.models.fields.CharField', [], {'max_length': '150', 'blank': 'True'}),
            'priority': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.callpriority': {
            'Meta': {'object_name': 'CallPriority'},
            'call_later': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'fresh': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reminder': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'thankinprogress': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'welcome_and_verification': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.courierdata': {
            'Meta': {'object_name': 'CourierData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'call_category': ('django.db.models.fields.CharField', [], {'max_length': '150'}),
            'call_id1': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id2': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'call_id3': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'remarks': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.fup': {
            'Meta': {'object_name': 'FUP'},
            'description': ('django.db.models.fields.TextField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_medical': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        u'core.fupassociated': {
            'Meta': {'object_name': 'FupAssociated'},
            'code': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.FUP']"}),
            'generated_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'jet_decision': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'received_on': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'})
        },
        u'core.mecode': {
            'Meta': {'object_name': 'Mecode'},
            'account': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address1': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'address2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address3': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'address4': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'bank_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'city': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'contact_person': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'emailid': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'me_code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'me_name': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'mobileno': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mode_of_payment': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'ownership': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pan': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'payor_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone1': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'phone2': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'pincode': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'rating': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.plan': {
            'Meta': {'object_name': 'Plan'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '200'})
        },
        u'core.saleclaim': {
            'Meta': {'object_name': 'SaleClaim'},
            'app_id': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '255', 'blank': 'True'}),
            'associated_applications': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': u"orm['core.Application']", 'null': 'True', 'blank': 'True'}),
            'campaign_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'debug_log': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'disposition': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '255', 'blank': 'True'}),
            'first_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_date': ('django.db.models.fields.DateTimeField', [], {}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'match_status': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'premium': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'sem': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']"})
        },
        u'core.servicablecourierpincode': {
            'Meta': {'object_name': 'ServicableCourierPincode'},
            'description': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'pin': ('django.db.models.fields.IntegerField', [], {'primary_key': 'True'})
        },
        u'core.smshistory': {
            'Meta': {'object_name': 'SmsHistory'},
            'application': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['core.Application']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'message': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'message_category': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'mobile_to': ('django.db.models.fields.CharField', [], {'max_length': '20'}),
            'source': ('django.db.models.fields.CharField', [], {'max_length': '250'}),
            'source_id': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'})
        },
        u'core.uhcdata': {
            'Meta': {'object_name': 'UHCData'},
            'application': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['core.Application']", 'unique': 'True'}),
            'final_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'first_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_call_status': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'path_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'path_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks1': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks2': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'remarks3': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'second_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'third_call_on': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_date': ('django.db.models.fields.DateField', [], {'null': 'True', 'blank': 'True'}),
            'tmt_appt_time': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_dc_name': ('django.db.models.fields.CharField', [], {'max_length': '250', 'blank': 'True'}),
            'tmt_test_name': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        u'core.uploadfile': {
            'Meta': {'object_name': 'UploadFile'},
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_processed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'output': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'upload_file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['auth.User']", 'null': 'True', 'blank': 'True'})
        },
        u'core.userprofile': {
            'Meta': {'object_name': 'UserProfile'},
            'activation_key': ('django.db.models.fields.CharField', [], {'max_length': '40', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'job_title': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'network_id': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'organization': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['auth.User']", 'unique': 'True'})
        }
    }

    complete_apps = ['core']