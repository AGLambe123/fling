from django import forms
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib.auth import authenticate
from django.forms.extras.widgets import SelectDateWidget

import random
import datetime,time
import uuid
import re
import hashlib

from core.models import *

CALLCENTER_SMS_TEXT_CHOICES = (
    ('NONE', '---'),
    ('DocumentReminder', 'Document Reminder'),
    ('MedicalReminder', 'Medical Reminder'),
)

COURIER_SMS_TEXT_CHOICES = (
    ('NONE', '---'),
    ('CDR', 'Complete documents received'),
    ('IDR', 'Incomplete documents received'),
    ('UDR', 'Unclear documents received'),
)

CALL_CATEGORY_CHOICES = (
    ('', '---'),
    ('QUERY', 'Query'),
    ('REQUEST', 'Request'),
    ('ESCALATED_REQUEST', 'Escalated Request'),
)

PRIORITY_CHOICES = (
    (25, 'Very High Volume'),
    (15, 'High Call Volume'),
    (10, 'Normal Call Volume'),
    (5, 'Low Call Volume'),
    (2, 'Very Low Call Volume'),
    (0, 'No Calls'),
)

DOCUMENT_DELIVERY_CHOICES = (
    ('','----'),
    ('SELF_COURIER', 'Self Courier'),
    ('EMAIL', 'Email buyonline'),
    ('UPLOAD', 'upload on site'),
    ('SUBMIT_AT_BRANCH', 'Submit At Branch'),
)

PRE_DEFINED_NOTES = (
    ('','-------------'),
    ('DA_NOT_ASSIGNED','Doctor not assigned'),
    ('DA_CHANGE','Customer wants to change doctor'),
    ('THIRD_PARTY_DECLINE', 'Third Party Payment Decline'),
    ('POLICY_CHANGE','Customer wants to change policy'),
    ('MONEY_BACK','Customer wants his money back'),
    ('MAIL_DOCS','Customer will mail the documents'),
    ('SMS_TRIGGERED','SMS triggered call'),
    ('DOCS_SENT','Document sent and not received > 3 days'),
    ('MEDICALS_COMPLETED','Medicals completed and not received > 5 days'),
    ('DOCS_NOT_AVAILABLE', 'Not Interested - documents not available'),
    ('MEDICALS_NOT_WANTED', 'Not Interested - does not want to do the medicals'),
    ('UNHAPPY_XRT_COFF', 'Not Interested - unhappy with UW extra'),
    ('NOT_INTERESTED_OTHERS', 'Not Interested - Others'),
)

class CallCenterReassignmentForm(forms.Form):
    user = forms.ChoiceField(choices=[(u.id, "%s - %s" % (u.username, u.get_full_name())) for u in User.objects.filter(userprofile__role='CALLCENTER')], required=True)
    call_type = forms.ChoiceField(choices=CALL_TYPE, required=False)
    transfer = forms.IntegerField()

class UserForm(forms.Form):
    first_name = forms.CharField(max_length=30)
    last_name = forms.CharField(max_length=30, required=False)
    password1 = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput)
    aspect_username = forms.CharField(max_length=30, required=False)

    def __init__(self,uid=None, for_role=None, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        self.uid = uid
        self.for_role = for_role
        if not uid:
            self.fields['username'] = forms.CharField(max_length=30)

    def clean_first_name(self):
        d = self.cleaned_data.get
        first_name = d('first_name').strip()
        pattern = "^[a-zA-Z\s]+$"
        match = re.match(pattern, first_name)
        if not match:
            raise forms.ValidationError("Special characters not allowed in name.")
        return first_name

    def clean_last_name(self):
        d = self.cleaned_data.get
        last_name = d('last_name').strip()
        pattern = "^[a-zA-Z\s]+$"
        match = re.match(pattern, last_name)
        if not match:
            raise forms.ValidationError("Special characters not allowed in name.")
        return last_name

    def clean_password2(self):
        d = self.cleaned_data.get
        if d("password2") != d("password1"):
            raise forms.ValidationError("Passwords do not match.")
        return d("password2")

    def save(self):
        if self.uid:
            u = User.objects.get(id=self.uid)
            d = self.cleaned_data.get
            u.first_name = d('first_name')
            u.last_name = d('last_name')
            u.set_password(d('password1'))
            u.save()
            up = UserProfile.objects.get(user=u)
            up.aspect_username =d('aspect_username')
            up.save()

        else:
            d = self.cleaned_data.get
            u = User.objects.create_user(
                username = d('username'),
                password = '',
                email = '',
            )
            u.set_password(d('password1'))
            u.first_name = d('first_name')
            u.last_name = d('last_name')
            u.is_active = True
            u.save()
            up = UserProfile(user=u, role=self.for_role,aspect_username=d('aspect_username'))
            up.save()
        return u

class CallPriorityForm(forms.ModelForm):
    call_later = forms.ChoiceField(choices=PRIORITY_CHOICES)
    fresh = forms.ChoiceField(choices=PRIORITY_CHOICES)
    welcome = forms.ChoiceField(choices=PRIORITY_CHOICES)
    welcome_and_verification = forms.ChoiceField(choices=PRIORITY_CHOICES)
    verification = forms.ChoiceField(choices=PRIORITY_CHOICES)
    reminder = forms.ChoiceField(choices=PRIORITY_CHOICES)
    thankinprogress = forms.ChoiceField(choices=PRIORITY_CHOICES)

    class Meta:
        model = CallPriority

class UploadForm(forms.Form):
    upload_file = forms.FileField(max_length=255)

class CallForm(forms.Form):
    disposition = forms.ChoiceField(choices=DISPOSITIONS)
    later_time = forms.DateTimeField(required=False)
    courier_date = forms.DateField(required=False)
    fup_commited_date = forms.DateField(required=False)
    document_commited_date = forms.DateField(required=False)
    auto_notes = forms.ChoiceField(choices=PRE_DEFINED_NOTES, required=False)
    address1 = forms.CharField(widget=forms.Textarea, required=False)
    document_delivery_method = forms.ChoiceField(choices=DOCUMENT_DELIVERY_CHOICES, required=False)
    photo_id_proof = forms.ChoiceField(choices=PHOTO_ID_PROOF_CHOICES, required=False)
    age_proof = forms.ChoiceField(choices=AGE_PROOF_CHOICES, required=False)
    address_proof = forms.ChoiceField(choices=ADDRESS_PROOF_CHOICES, required=False)
    income_proof = forms.ChoiceField(choices=INCOME_PROOF_CHOICES, required=False)
    attested_photograph = forms.BooleanField(required=False)

class SMSForm(forms.Form):
    message_text = forms.ChoiceField(choices=CALLCENTER_SMS_TEXT_CHOICES)

class CourierSMSForm(forms.Form):
    message_text = forms.ChoiceField(choices=COURIER_SMS_TEXT_CHOICES)
    bool_photo_id_proof = forms.BooleanField(required=False)
    bool_age_proof = forms.BooleanField(required=False)
    bool_address_proof = forms.BooleanField(required=False)
    bool_income_proof = forms.BooleanField(required=False)
    bool_attested_photograph = forms.BooleanField(required=False)

class SearchForm(forms.Form):
    app_id = forms.CharField(max_length=150, label = "Application Id", help_text="Enter Application Id to get the application details.")

class DocsForm(forms.Form):
    document_delivery_method_used = forms.ChoiceField(choices=DOCUMENT_DELIVERY_CHOICES, required=False)
    photo_id_proof_rcvd = forms.ChoiceField(choices=PHOTO_ID_PROOF_CHOICES, required=False)
    age_proof_rcvd = forms.ChoiceField(choices=AGE_PROOF_CHOICES, required=False)
    address_proof_rcvd = forms.ChoiceField(choices=ADDRESS_PROOF_CHOICES, required=False)
    income_proof_rcvd = forms.ChoiceField(choices=INCOME_PROOF_CHOICES, required=False)
    attested_photograph_rcvd = forms.BooleanField(required=False, label="Photograph")
    airway_bill_no = forms.CharField(max_length=250, required=False)
    courier_company_name = forms.CharField(max_length=250, required=False)
    remarks = forms.CharField(widget=forms.Textarea(attrs={'cols':28,'rows':5}), required=False)
    #remarks = forms.CharField(required=False)
    call_category = forms.ChoiceField(choices=CALL_CATEGORY_CHOICES, required=False)
    call_id1 = forms.IntegerField(required=False)
    call_id2 = forms.IntegerField(required=False)
    call_id3 = forms.IntegerField(required=False)

    def clean_call_category(self):
        d = self.cleaned_data.get
        if d('document_delivery_method_used') =='EMAIL' and not d('call_category') :
            raise forms.ValidationError("This field is mandatory. Select a Call Category.")
        return d('call_category')
    def clean_call_id1(self):
        d = self.cleaned_data.get
        if d('document_delivery_method_used') =='EMAIL' and not d('call_id1') :
            raise forms.ValidationError("This field is mandatory. Enter a valid integer Call ID.")
        return d('call_id1')

    def save(self, ac):
        d = self.cleaned_data.get
        if d('photo_id_proof_rcvd'):
            ac.photo_id_proof_rcvd = d('photo_id_proof_rcvd')
            ac.photo_id_proof_rcvd_date = datetime.datetime.now()
        if d('age_proof_rcvd'):
            ac.age_proof_rcvd = d('age_proof_rcvd')
            ac.age_proof_rcvd_date = datetime.datetime.now()
        if d('address_proof_rcvd'):
            ac.address_proof_rcvd = d('address_proof_rcvd')
            ac.address_proof_rcvd_date = datetime.datetime.now()
        if d('income_proof_rcvd'):
            ac.income_proof_rcvd = d('income_proof_rcvd')
            ac.income_proof_rcvd_date = datetime.datetime.now()
        if d('attested_photograph_rcvd'):
            ac.attested_photograph_rcvd = d('attested_photograph_rcvd')
            ac.attested_photograph_rcvd_date = datetime.datetime.now()
        if d('document_delivery_method_used'):
            ac.document_delivery_method_used = d('document_delivery_method_used')
        if d('airway_bill_no'):
            ac.airway_bill_no = d('airway_bill_no')
        if d('courier_company_name'):
            ac.courier_company_name = d('courier_company_name')

        ac.save()
        cds = CourierData.objects.filter(application=ac.application)
        if cds:
            cd = cds[0]
            cd.remarks = d('remarks')
            cd.call_category = d('call_category')
            cd.call_id1 = d('call_id1')
            cd.call_id2 = d('call_id2')
            cd.call_id3 = d('call_id3')
            cd.save()
        else:
            cd = CourierData(application=ac.application, remarks=d('remarks'), call_category=d('call_category'),call_id1 = d('call_id1'),call_id2 = d('call_id2'),call_id3 = d('call_id3')).save()
        return ac, cd

class ReportFiltersForm(forms.Form):
    current_year = datetime.datetime.now().year + 1
    start_date = forms.DateField(widget=SelectDateWidget(years=range(2010,current_year)))
    end_date = forms.DateField(widget=SelectDateWidget(years=range(2010,current_year)))

    def clean_end_date(self):
        d = self.cleaned_data.get
        if d('start_date') > d('end_date'):
            raise forms.ValidationError("Please choose correct date range")
        return d('end_date')
