
import datetime
import hashlib
import logging
import sys, traceback
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.template import RequestContext

from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render_to_response, get_object_or_404
from django.db.models import Q
from django.db import connection
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from django.core import serializers
from django.forms.models import modelformset_factory
from django.forms.formsets import formset_factory
from django.contrib.auth import authenticate, login
from django.utils import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import IntegrityError
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings

import datetime
import time
from time import mktime
from core.forms import *
from core.models import *
import iutils
from customdb.customquery import sqltojson, sqltodict, executesql
import csv

from xl2python import Xl2Python
import utils
import string
from collections import OrderedDict
from django.views.decorators.cache import never_cache
import base64
import pyodbc
import requests
from django.contrib.auth.signals import user_logged_in  # 6109
from django.contrib import messages
from django.contrib.auth import logout  # 6109
import xlrd


# 6109
def delete_user_sessions(user):
    user_sessions = UserSession.objects.filter(user=user)
    for user_session in user_sessions:
        user_session.session.delete()


@login_required
@utils.profile_type_only("UHC")
def uhc_download(request):
    """ on click of application download if the uhci_update_flag is true prints all the data into the csv """
    data = []

    
    app_check = Application.objects.filter(app_status__in=['', 'PS'], uhci_update_flag=True,
                                           fup_associated__order_status__in=['ORD'],
                                           fup_associated__code__is_medical=True,
                                           fup_associated__med_indicator__in=['Y']).distinct()
    

    
    

    
    print app_check.query
    # app_check=Application.objects.filter(app_status__in=['', 'PS'], uhci_update_flag=True,fup_associated__code__is_medical=True,fup_associated__order_status__in=['ORD']).distinct()
    #    print "PS APPS>>", Application.objects.filter(app_status__in=['', 'PS'], uhci_update_flag=True)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="UHC_DOWNLOAD_%s.csv"' % (
    datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)
    

   
    if app_check:
        for i, app in enumerate(app_check):
            if app.uhcdata_set.all():
                uhc = app.uhcdata_set.get()
            else:
                continue
            tests = [f.code.description for f in app.fup_associated.all() if f.code.is_medical] 
            
            # 6733  Requirement comment TPA report 

            test1 = [a.reqt_desc_text for a in app.fup_associated.all() if a.code.is_medical]
            
            row = [
                ("Sr no", str(i + 1)),
                ("Name", "%s %s %s" % (app.salutation, app.first_name, app.last_name)),
                ("Download Date", datetime.datetime.today().strftime("%d/%m/%Y")),
                ("Application Date", app.created_on.strftime("%d/%m/%Y")),
                ("Insurer", 'BSLI'),
                ("Insurer Division", 'ECS'),
                ("Application ID", app.app_id),
                ("Gender", app.gender),
                ("Marital Status", app.marital_status),
                ("Phone", str(app.landline)),
                ("Mobile", app.mobile),
                ("Tests", " , ".join(tests)),
                # Priority
                ("DOB", app.dob.strftime("%d-%m-%Y")),
                ("Minor/ Adult", 'Adult'),
                ("Country", app.nationality),
                ("Email", app.email),
                ("Address", "%s, %s, %s, %s, %s, %s, %s, %s" % (
                app.flat, app.building, app.road, app.area, app.landmark, app.city, app.state, app.pincode)),
                ("State", app.state),
                ("Uhc location 1", "%s, %s, %s" % (
                app.medicalappointment_center1, app.medicalappointment_location1, app.medicalappointment_city1)),
                ("Appointment Date 1", app.medicalappointment_date1),
                ("Appointment Time 1", app.medicalappointment_time1),
                ("Uhc location 2", "%s, %s, %s" % (
                app.medicalappointment_center2, app.medicalappointment_location2, app.medicalappointment_city2)),
                # Provider Name
                ("Appointment Date 2", app.medicalappointment_date2),
                ("Appointment Time 2", app.medicalappointment_time2),
                ("status", uhc.status),
                ("Requirement comments", " , ".join(test1))   # 6733 TPA report requirement comment
            
                

            ]
            if i == 0:
                writer.writerow([k[0] for k in row])

            writer.writerow([k[1] for k in row])
            # update UHCI flag so that this application is not downloaded again, after 4 hours of application update
            Application.objects.filter(app_id=app).update(uhci_update_flag=False)

            #             Application.objects.filter(
            #                 app_id = app,
            # #               app_status__in=['', 'PS'],
            #                 #uhci_update_flag=True,
            # #                uhci_update_time__lte=dataetime.datetime.now()-datetime.timedelta(hours=1)
            #                 ).update(uhci_update_flag=False)
            uhci_download = UhcDownload(application=app, tests=" , ".join(tests), created_on=datetime.datetime.now())
            uhci_download.save()

        return response
    else:
        return response


@login_required
def callcenter_send_mail(request):
    mylist = ['1', '2', '3', '4', '5', '6']
    app = Application.objects.get(app_id=request.POST['app_id'])
    # Inject plan_name into app object. For now default is Protect@Ease. To be tested for all templates by Ankush.
    app.plan_name = "BSLI Protect@Ease"
    mtext = request.POST['mail_text']
    id_mail_type = request.POST['id_mail_type']
    mail_sent = False
    if id_mail_type == "0":
        mail_html = render_to_string('mailers/mail_ad_hoc.html',
                                     {'app': app, 'mtext': mtext, 'current_time': datetime.datetime.now()})
        mailer_header = render_to_string('mailers/mailer_header.html', {'site_url': settings.SITE_URL})
        mailer_footer = render_to_string('mailers/mailer_footer.html', {'site_url': settings.SITE_URL})
        mail_html = "%s%s%s" % (mailer_header, mail_html, mailer_footer)

        iutils.send_html_mail(app, 'Your application/proposal number %s - %s' % (
        app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html, [app.email], html_message=mail_html,
                              mail_type="Manual")
        return HttpResponse('OK')

    # 6733 insurer new d2c
    
    try:
        ins_data = InsurerApplication.objects.get(ins_application=app)
    except:
        ins_data = None
        print "insurer data not availble to send insurer email"


    if id_mail_type == "1":
        #        print" mail_html"
        if app.app_status in ['DC', 'PO', 'RJ']:
            print "App status mail"
            iutils.send_customer_mail(app, 'APP_STATUS', ins_data) #6733
            mail_sent = True
            return HttpResponse('OK')
        else:
            return HttpResponse('NOK')
    
    if id_mail_type == "2":
        
        if app.app_uw_amount or app.app_uw_reason == 'ESC':

            if app.app_uw_reason == 'HLT':

                print " Manual UW REASON HLT"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH', ins_data) #6733
                return HttpResponse('OK')

            if app.app_uw_reason == 'ESC':

                print "UW REASON ESC"
                iutils.send_customer_mail(app, 'UW_EXTRA_SA_RESTRICTION', ins_data)  #6733
                return HttpResponse('OK')

            if app.app_uw_reason == 'NSS':

                print "UW REASON NSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_NON_SMOKER_TO_SMOKER', ins_data)  #6733
                return HttpResponse('OK')


            if app.app_uw_reason == 'HLTNSS':

                print "UW REASON HLTNSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER', ins_data)  #6733
                return HttpResponse('OK')

            # 5842-D
            if app.app_uw_reason == 'HLTESC':

                print "UW REASON HLTESC"
                iutils.send_customer_mail(app, 'UW_HEALTH_SA_RESTRICTION', ins_data)  #6733
                return HttpResponse('OK')


            if app.app_uw_reason == 'HLTNSSESC':

                print "UW REASON HLTNSSESC"
                iutils.send_customer_mail(app, 'UW_HEALTH_SMOKER_SA_RESTRICTION', ins_data)   #6733
                return HttpResponse('OK')
                # 5842-D
        else:
            return HttpResponse('NOK')

    if id_mail_type == "3":

        apps = Application.objects.filter(
            Q(fup_associated__received_on__isnull=True, fup_associated__order_status__in=['ORD'],
              app_status__in=['', 'PS']), app_id=app).distinct()

        # Requirement reminder mailer
        print "Requirement status mail"
        if apps:
            print "Requirement status mail", app.app_id
            iutils.send_customer_mail(app, 'FUP_STATUS', ins_data)   #6733
            return HttpResponse('OK')
        else:
            return HttpResponse('NOK')
    if id_mail_type == "4":
        # print 'application no',app.app_id
        # print 'mobile',app.mobile
        # print 'email',app.email
        # print 'premiumAmount',app.pay_amount
        # print 'TransNo',app.transaction_id

        data = {'AppNo': app.app_id, 'Email': app.email, 'mobile': app.mobile, 'PremiumAmount': app.pay_amount,
                'TransNo': app.transaction_id}

        r = requests.get("http://10.155.6.16:8181/buy-term-insurance-online/Calculator/EmergeEmail", params=data)

        return HttpResponse(r.text)


@csrf_exempt
def get_user_details(request):
    """ First Name, Last Name, DOB, Mobile Number, Email, Payment Flag """
    app_id = request.GET.get('application')
    mobile = request.GET.get('mobile')

    if app_id:
        app = Application.objects.filter(app_id=app_id)
        if not app:
            raise Http404
        else:
            app = app[0]
        app_callattr = app.applicationcallattribute
        call_history_list = CallHistory.objects.filter(application__app_id=app_id).order_by('-created_on')
        nonmedical_fups = app.fup_associated.filter(code__is_medical=False).order_by('received_on')
        medical_fups = app.fup_associated.filter(code__is_medical=True).order_by('received_on')
        sms_history = ActionHistory.objects.filter(application=app, action_type='sms')
        email_history = ActionHistory.objects.filter(application=app, action_type='email')
        alluhc = UHCData.objects.filter(application=app)
        if alluhc:
            uhc = alluhc[0]
        else:
            uhc = ''
        verbose_status = iutils.get_verbose_status(app)
        photo_id_date = ''
        age_date = ''
        address_date = ''
        income_date = ''
        if app.photo_id_proof_rcvd_date:
            try:
                photo_id_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                photo_id_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
        if app.address_proof_rcvd_date:
            try:
                address_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                address_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
        if app.age_proof_rcvd_date:
            try:
                age_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                age_date = datetime.datetime.strftime(datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y'),
                                                      '%d/%m/%Y %H:%M:%S')
        if app.income_proof_rcvd_date:
            try:
                income_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                income_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
 
        # insurer added on manager single scrren 6733
        # 6733
        try:
            ins_single = InsurerApplication.objects.get(ins_application=app)
        except:
            ins_single = None
            print "insurer not found on single screen"# insurer added on manager single scrren 6733
       
        return render_to_response("core/single_screen.html",
                                  {
                                      'app_callattr': app_callattr,
                                      'app': app,
                                      'nonmedical_fups': nonmedical_fups,
                                      'medical_fups': medical_fups,
                                      'call_history_list': call_history_list,
                                      'sms_history': sms_history,
                                      'email_history': email_history,
                                      'uhc': uhc,
                                      'verbose_status': verbose_status,
                                      'alluhc': alluhc,
                                      'photo_id_date': photo_id_date,
                                      'age_date': age_date,
                                      'address_date': address_date,
                                      'income_date': income_date,
                                      'ins_call': ins_single,  # 6733 insurer details 15 feb
                                      'product_name': app.product_name,  # 6733 product  

                                  },
                                  context_instance=RequestContext(request)
                                  )

    if mobile:
        app_list = Application.objects.filter(mobile=mobile).order_by("-created_on")
        if not app_list:
            raise Http404
        app = app_list[0]
        app_callattr = app.applicationcallattribute
        call_history_list = CallHistory.objects.filter(application__app_id=app_id).order_by('-created_on')
        nonmedical_fups = app.fup_associated.filter(code__is_medical=False).order_by('received_on')
        medical_fups = app.fup_associated.filter(code__is_medical=True).order_by('received_on')
        sms_history = ActionHistory.objects.filter(application=app, action_type='sms')
        email_history = ActionHistory.objects.filter(application=app, action_type='email')
        alluhc = UHCData.objects.filter(application=app)
        if alluhc:
            uhc = alluhc[0]
        else:
            uhc = ''
        verbose_status = iutils.get_verbose_status(app)
        photo_id_date = ''
        age_date = ''
        address_date = ''
        income_date = ''

        if app.photo_id_proof_rcvd_date:
            try:
                photo_id_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                photo_id_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
        if app.address_proof_rcvd_date:
            try:
                address_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                address_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
        if app.age_proof_rcvd_date:
            try:
                age_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                age_date = datetime.datetime.strftime(datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y'),
                                                      '%d/%m/%Y %H:%M:%S')
        if app.income_proof_rcvd_date:
            try:
                income_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
            except:
                income_date = datetime.datetime.strftime(
                    datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')

        # insurer added on manager single scrren 6733
        # 6733
        try:
            ins_single = InsurerApplication.objects.get(ins_application =app)
        except:
            ins_single = None
            print "insurer not found on single screen"


        return render_to_response("core/single_screen.html",
                                  {
                                      'app_callattr': app_callattr,
                                      'app': app,
                                      'nonmedical_fups': nonmedical_fups,
                                      'medical_fups': medical_fups,
                                      'call_history_list': call_history_list,
                                      'sms_history': sms_history,
                                      'email_history': email_history,
                                      'uhc': uhc,
                                      'verbose_status': verbose_status,
                                      'alluhc': alluhc,
                                      'photo_id_date': photo_id_date,
                                      'age_date': age_date,
                                      'address_date': address_date,
                                      'income_date': income_date,
                                      'ins_call': ins_single,          # 6733 insurer details 15 feb
                                      'product_name': app.product_name # 6733 product category
                                  },
                                  context_instance=RequestContext(request)
                                  )


    else:
        return HttpResponse(simplejson.dumps({'error': "No applications for mobile %s found" % (mobile)}))
        # output.update({

        #     'first_name': app.first_name,
        #     'last_name': app.last_name,
        #     'dob' : app.dob.strftime("%d/%m/%Y"),
        #     'mobile' : app.mobile,
        #     'email' : app.email,
        #     'app_status' : app.app_status,
        #     'application_id' : app.app_id
        # })


        # response = HttpResponse()
        # response.write(latest_op.get('application_id'))
        # return response


#            w= HttpResponse(simplejson.dumps(output[-1]))

@csrf_exempt
def create_application_old_webservice(request):
    print "data ---", request.POST.get('data')
    if not request.POST.get('data'):
        return HttpResponse(simplejson.dumps({'success': False, 'error': "Payload missing"}))
    data = request.POST['data']
    try:
        null = ""
        rdata = eval(simplejson.loads(data)['data'])
    except:
        try:
            rdata = simplejson.loads(request.POST['data'])
        except:
            try:
                data = request.POST['data']
                rdata = simplejson.loads(data)
            except:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Incorrect serialization"}))

    if not rdata.get('app_id'):
        return HttpResponse(simplejson.dumps({'success': False, 'error': "Application ID is missing"}))
    """

    if not request.POST.get('data'):
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Payload missing"}))

    print "Create__________________________________________", datetime.datetime.now()
    print "data ---",request.POST.get('data')

    data = request.POST['data']
    try:
        null = "" #eval doesn't understand null values, need to assign null to ""
        rdata = eval(simplejson.loads(data)['data'])
        print "clean_data-------->",rdata
    except Exception as e:
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Incorrect serialization"}))

    if not rdata.get('app_id'):
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Application ID is missing"}))
    """
    try:
        data = iutils.format_application_form_data(rdata)
        print "datataaa", data
    except Exception as e:
        return HttpResponse(simplejson.dumps({'success': False, 'error': e}))

    app = Application.objects.filter(app_id=data['app_id'])
    print "asdasd:>", app
    # iutils.reconcile_with_lms(app)
    if app:
        app = app.update(**data)
        return HttpResponse(simplejson.dumps({'success': True, 'warning': 'Pre-existing application, updated'}))
    else:
        app = Application(**data)
        app.save()
        uhc = iutils.create_uhc_for_application(app)
        apca = ApplicationCallAttribute(application=app, last_call_status='F', is_taken=False,
                                        next_calltime=datetime.datetime.now())
        apca.save()
    return HttpResponse(simplejson.dumps({'success': True}))


@csrf_exempt
def update_application(request):
    """
    REQ_ID
    REQ_STATUS_ID
    REQ_DESC
    ORDERED_DATE // fup raised
    RECEIVED_DATE  // fup recvd
    REC_ACCEPTED_DATE  // fup accepted - closed
    CANCELLED_DATE  // fup cancelled
    REQ_CREATE_DATE  // same ordered_date
    MEDI_IND  // "Medical yes/no"
    REQT_DESC_TEXT
    
    data={"uwReason_text":"","FLAT_EXTRA_PREM":"0.00","uwReason":"","policy_reject_reason":"","policy_reject_reason_text":"","MISC_SUSPENSE_AMT":"0.00","MODAL_PREM_SERV_TAX":"33146.22","uwAmount":"","policy_status":"PCRU","uwStatus":"","saInterval":"","npwStatus":"N","npwDueDate":"","saOption":"","mailDate":"","deliveryDate":"","sum_assured":"55000000.00","fup":[["HDL","ORD","High Density Lipoprotein","","","","","2014-11-12","N",""],["IP","ORD","Income Proof required","","","","","2014-11-12","N",""],["REINR","SAA","REINSURER RGA","","","","","2014-11-12","N",""],["RQ004","SAA","Annual premium 1 Lakh and above","","","","","2014-11-12","N",""]],"application_id":"BA0000204","courier_name":"","MORTLTY_EXTRA_PREM":"0.00","bill_date":"","deliveryStatus":"","policy_issue_date":"2014-11-12"}"""
         
        
    print "Update_Application___________________________________", datetime.datetime.now()
    print "data__________", request.POST['data']
    print "---------------------------\n"
    errors = []
    data = simplejson.loads(request.POST['data'])
    

    for d in data:
        app_id = d['application_id']
        app = Application.objects.filter(app_id=app_id)
        print "APP >", app
        if not app:
            errors.append('Non-existent application_id : %s' % app_id)
            continue
        app = app[0]
        for fupdata in d['fup']:
            fname, order_status, _, ordered_date, recvd_date, accepted_date, cancelled_date, create_date, med_indicator, reqt_desc_text = fupdata

            recvd_date = iutils.format_date(recvd_date)
            ordered_date = iutils.format_date(ordered_date)
            accepted_date = iutils.format_date(accepted_date)
            cancelled_date = iutils.format_date(cancelled_date)
            create_date = iutils.format_date(create_date)

            try:
                code = FUP.objects.get(name=fname)
            except FUP.DoesNotExist:
                errors.append('Requirement Code - %s - %s NOT FOUND' % (app_id, fname))
                continue

            jet_decision = ''
            if recvd_date:
                jet_decision = 'RECVD'
            if accepted_date:
                jet_decision = 'APPROVED'
            if cancelled_date:
                jet_decision = 'CANCELLED'
            if order_status == 'WVD':
                jet_decision = 'WAVED OFF'
            if order_status == 'ORD':
                jet_decision = 'ORDERED'
            
            
            fup_associated = FupAssociated.objects.filter(code__name=fname.strip(), application=app)
            
            if fup_associated:
                fup_associated.update(**{
                    'generated_on': ordered_date or create_date,
                    'received_on': accepted_date or cancelled_date,
                    'jet_decision': jet_decision,
                    'reqt_desc_text': reqt_desc_text,
                    'order_status': order_status,
                    'med_indicator': med_indicator,
                })
                app.fup_status_mail = "2"
            else:
                fup_associated = FupAssociated(
                    code=FUP.objects.get(name=fname),
                    generated_on=create_date or ordered_date,
                    received_on=accepted_date or cancelled_date,
                    jet_decision=jet_decision,
                    reqt_desc_text=reqt_desc_text,
                    order_status=order_status,
                    med_indicator=med_indicator,
                )
                fup_associated.save()
                print fname
                print med_indicator
                if med_indicator == 'Y':  # changed on 7 may
                    app.uhci_update_flag = True
                    app.uhci_update_time = datetime.datetime.now()
                app.fup_associated.add(fup_associated)
                app.fup_status_mail = "1"
        print "\nDATA: ", d['application_id'], d['policy_status'], d['policy_reject_reason'], d['uwAmount'], d[
            'uwReason']
        POLICY_STATUS_MAPPING = {
            "": "PS",
            "1": "IF",
            "2": "IF",
            "3": "IF",
            "4": "IF",
            "A": "FL",
            "B": "LA",
            "C": "IF",
            "D": "XX",
            "E": "WD",
            "F": "XX",
            "H": "XX",
            "I": "XX",
            "K": "XX",
            "M": "XX",
            "N": "XX",
            "PCCU": "PS",
            "PCRC": "PS",
            "PCRU": "PS",
            "PECC": "PS",
            "PECU": "PS",
            "PERC": "PS",
            "PERU": "PS",
            "PCC": "PS",
            "PCR": "PS",
            "PEC": "PS",
            "PER": "PS",
            "PUC": "PS",
            "PUR": "PS",
            "Q": "XX",
            'R': 'RJ',  # If policy_status is "R", then check for policy_reject_reason
            "S ": "WD",
            "T": "XX",
            "W": "XX",
            "X": "XX",
        }
        try:
            app.app_status = POLICY_STATUS_MAPPING[d['policy_status']]
        except:
            errors.append('except')
        if app.app_status == 'R':
            # if True:
            app.app_status_reason = d['policy_reject_reason']
            if app.app_status_reason == 'DEC':
                app.app_status = 'DC'
            if app.app_status_reason == 'POS':
                app.app_status = 'PO'
            if app.app_status_reason == 'REJ':
                app.app_status = 'RJ'

        app.app_status_reason_text = d['policy_reject_reason_text']
        if app.app_status in ['DC', 'PO', 'RJ'] and app.app_status_mail == '':
            app.app_status_date = datetime.date.today()
            app.app_status_mail = "-1"

        print "APP: ", app.app_id, app.app_status, app.app_status_reason, app.app_status_date

        # UW Extra mail send logic, Cron to pick all those which have app.uw_extra_premium_mail=-1 and send mail
        # based on app.app_uw_reason (Health/Sum Assured Restriction/Non-smoker to smoker)
        # Also, create new FUP and generate it on extra uw amount, so that calls can be triggered automatically

        if app.app_uw_amount:
            if d['uwAmount'] and float(d['uwAmount']) != 0 and app.app_uw_amount != d['uwAmount']:
                app.uw_extra_premium_mail = "-1"
        else:
            if d['uwAmount'] and float(d['uwAmount']) != 0:
                app.uw_extra_premium_mail = "-1"

        if app.app_uw_reason:
            if app.app_uw_reason != d['uwReason'] and d['uwReason'] == 'ESC':
                app.uw_extra_premium_mail = "-1"
        else:
            if d['uwReason'] == 'ESC':
                app.uw_extra_premium_mail = "-1"

        app.app_uw_amount = d['uwAmount']
        app.app_uw_reason = d['uwReason']

        print "APP: ", app.app_id, app.app_uw_amount, app.app_uw_reason, app.uw_extra_premium_mail

        if d['email_id']:
            app.email = d['email_id']
        # 5842-D
        sr_uw_amount, sr_uw_reason, sr_uw_reason_text, sr_sum_assured, sr_flat_extra_prem, sr_mortality_extra_prem, sr_modal_prem_serv_tax, sr_term, sr_status, sr_req_reason, sr_smoker_non_smoker = d['s2rider']
        app.surgical_uw_amount = sr_uw_amount
        app.surgical_uw_reason = sr_uw_reason
        app.surgical_uw_reason_text = sr_uw_reason_text
        app.surgical_sum_assured = sr_sum_assured
        app.surgical_flat_extra_premium = sr_flat_extra_prem
        app.surgical_mortality_extra_premium = sr_mortality_extra_prem
        app.surgical_premium_service_tax = sr_modal_prem_serv_tax
        app.surgical_policyterm = sr_term
        app.surgical_policystatus = sr_status  # 5842-D

        app.surgical_req_reason = sr_req_reason.capitalize()  # 6733


        # 6733
        if sr_smoker_non_smoker == "S":
            sr_smoker_non_smoker = "Smoker"
        else: 
            sr_smoker_non_smoker = "Non Smoker"

        app.surgical_smoker_non_smoker = sr_smoker_non_smoker  # 6733

        if app.surgical_policystatus != "R" and sr_status:  # 5842-D
            app.app_status_mail = "-1"  # 5842-D
        

        # try:
        #     app.surgical_policystatus = POLICY_STATUS_MAPPING[sr_status]
        # except:
        #     app.surgical_policystatus=""
        #     print "Surgical rider exception",app.app_id
        # for ariderdata in d['a2rider']:
        ar_uw_amount, ar_uw_reason, ar_uw_reason_text, ar_sum_assured, ar_flat_extra_prem, ar_mortality_extra_prem, ar_modal_prem_serv_tax, ar_term, ar_status, ar_req_reason, ar_smoker_non_smoker = d['a2rider']
        app.accidental_uw_amount = ar_uw_amount
        app.accidental_uw_reason = ar_uw_reason
        app.accidental_uw_reason_text = ar_uw_reason_text
        app.accidental_sum_assured = ar_sum_assured
        app.accidental_flat_extra_premium = ar_flat_extra_prem
        app.accidental_mortality_extra_premium = ar_mortality_extra_prem
        app.accidental_premium_service_tax = ar_modal_prem_serv_tax
        app.accidental_policyterm = ar_term
        app.accidental_policystatus = ar_status  # 5842-D

        # 6733
        app.accidental_req_reason = ar_req_reason.capitalize()  # 6733

        if ar_smoker_non_smoker == "S":
            ar_smoker_non_smoker = "Smoker"
        else:
            ar_smoker_non_smoker = "Non Smoker"

        app.accidental_smoker_non_smoker = ar_smoker_non_smoker  # 6733


        if app.accidental_policystatus != "R" and ar_status:  # 5842-D
            app.app_status_mail = "-1"  # 5842-D
            # try:
            #     app.accidental_policystatus = POLICY_STATUS_MAPPING[ar_status]
            # except:
            #     app.accidental_policystatus = ""
            print "Accidental rider exception", app.app_id
        # for hriderdata in d['h2rider']:
        hr_uw_amount, hr_uw_reason, hr_uw_reason_text, hr_sum_assured, hr_flat_extra_prem, hr_mortality_extra_prem, hr_modal_prem_serv_tax, hr_term, hr_status, hr_req_reason, hr_smoker_non_smoker = d['h2rider']

        app.hospital_uw_amount = hr_uw_amount
        app.hospital_uw_reason = hr_uw_reason
        app.hospital_uw_reason_text = hr_uw_reason_text
        app.hospital_sum_assured = hr_sum_assured
        app.hospital_flat_extra_premium = hr_flat_extra_prem
        app.hospital_mortality_extra_premium = hr_mortality_extra_prem
        app.hospital_premium_service_tax = hr_modal_prem_serv_tax
        app.hospital_policyterm = hr_term
        app.hospital_policystatus = hr_status  # 5842-D

        
        # 6733
        app.hospital_reqt_reason = hr_req_reason.capitalize() # 6733
        
        # 6733
        if hr_smoker_non_smoker == "S":
            hr_smoker_non_smoker = "Smoker"
        else:
            hr_smoker_non_smoker = "Non Smoker"

        app.hospital_smoker_non_smoker = hr_smoker_non_smoker  #6733

        if app.hospital_policystatus != "R" and hr_status:  # 5842-D
            app.app_status_mail = "-1"  # 5842-D
        # try:
        #     app.hospital_policystatus = POLICY_STATUS_MAPPING[hr_status]
        # except:
        #     app.hospital_policystatus = ""
        #     print "Hospital rider exception",app.app_id
        # for criderdata in d['c2rider']:
        cr_uw_amount, cr_uw_reason, cr_uw_reason_text, cr_sum_assured, cr_flat_extra_prem, cr_mortality_extra_prem, cr_modal_prem_serv_tax, cr_term, cr_status, cr_req_reason, cr_smoker_non_smoker = d['c2rider']

        app.critical_uw_amount = cr_uw_amount
        app.critical_uw_reason = cr_uw_reason
        app.critical_uw_reason_text = cr_uw_reason_text
        app.critical_sum_assured = cr_sum_assured
        app.critical_flat_extra_premium = cr_flat_extra_prem
        app.critical_mortality_extra_premium = cr_mortality_extra_prem
        app.critical_premium_service_tax = cr_modal_prem_serv_tax
        app.critical_policyterm = cr_term
        app.critical_policystatus = cr_status  # 5842-D

        # 6733
        app.critical_reqt_reason = cr_req_reason.capitalize()  # 6733
        # 6733
        if cr_smoker_non_smoker == "S":
            cr_smoker_non_smoker = "Smoker"
        else:
            cr_smoker_non_smoker = "Non Smoker"

        app.critical_smoker_non_smoker = cr_smoker_non_smoker  # 6733

        if app.critical_policystatus != "R" and cr_status:  # 5842-D
            app.app_status_mail = "-1"  # 5842-D
        # try:
        #     app.critical_policystatus = POLICY_STATUS_MAPPING[cr_status]

        # except:
        #     app.critical_policystatus = ""
        #     print "Critical rider exception",app.app_id
        # 5820-F

        # new adb rider added 22 sept
        adb_uw_amount, adb_uw_reason, adb_uw_reason_text, adb_sum_assured, adb_flat_extra_prem, adb_mortality_extra_prem, adb_modal_prem_serv_tax, adb_term, adb_status, adb_req_reason, adb_smoker_non_smoker = d['adbrider']
        app.accidentaldeathbenefit_uw_amount = adb_uw_amount
        app.accidentaldeathbenefit_uw_reason = adb_uw_reason
        app.accidentaldeathbenefit_uw_reason_text = adb_uw_reason_text
        app.accidentaldeathbenefit_sum_assured = adb_sum_assured
        app.accidentaldeathbenefit_flat_extra_premium = adb_flat_extra_prem
        app.accidentaldeathbenefit_mortality_extra_premium = adb_mortality_extra_prem
        app.accidentaldeathbenefit_premium_service_tax = adb_modal_prem_serv_tax
        app.accidentaldeathbenefit_policyterm = adb_term
        app.accidentaldeathbenefit_policystatus = adb_status

        # 6733
        app.accidentaldeathbenefit_reqt_reason = adb_req_reason.capitalize()  # 6733
        # 6733
        if adb_smoker_non_smoker == "S":
            adb_smoker_non_smoker == "Smoker"
        else:
            adb_smoker_non_smoker = "Non Smoker"

        app.accidentaldeathbenefit_smoker_non_smoker = adb_smoker_non_smoker  # 6733


        if app.accidentaldeathbenefit_policystatus != "R" and adb_status:
            app.app_status_mail = "-1"

        # 6733 wop rider
        wop_uw_amount, wop_uw_reason, wop_uw_reason_text, wop_sum_assured, wop_flat_extra_prem, wop_mortality_extra_prem, wop_modal_prem_serv_tax, wop_term, wop_status, wop_req_reason, wop_smoker_non_smoker = d['woprider']
            
        app.waiverofPremium_uw_amount = wop_uw_amount
        app.waiverofPremium_uw_reason = wop_uw_reason
        app.waiverofPremium_uw_reason_text = wop_uw_reason_text
        app.waiverofPremium_sum_assured = wop_sum_assured
        app.waiverofPremium_flat_extra_premium = wop_flat_extra_prem
        app.waiverofPremium_mortality_extra_premium = wop_mortality_extra_prem
        app.waiverofPremium_premium_service_tax = wop_modal_prem_serv_tax
        app.waiverofPremium_policyterm = wop_term
        app.waiverofPremium_policystatus = wop_status
        
        #6733 
        app.waiverofPremium_reqt_reason = wop_req_reason.capitalize() # 6733
        # 6733
        if wop_smoker_non_smoker == "S":
            wop_smoker_non_smoker = "Smoker"
        else:
            wop_smoker_non_smoker = "Non Smoker"
        
        app.waiverofPremium_smoker_non_smoker = wop_smoker_non_smoker # 6733



        # 6733
        if app.surgical_uw_amount or app.accidental_uw_amount or app.hospital_uw_amount or app.critical_uw_amount or app.accidentaldeathbenefit_uw_amount or app.waiverofPremium_uw_amount:
            app.uw_extra_premium_mail = "-1"
        # 5842-D
        app.policy_term = d['policy_term']
        app.app_uw_reason_text = d['uwReason_text']
        app.sum_assured_option = d['saOption']
        app.sum_assured_interval = d['saInterval']
        app.sum_assured = d['sum_assured']  # 5842-D
        app.rider_reject_reason_text = d['rider_reject_reason_text']  # 5842-D
        app.suspense_amount = d['MISC_SUSPENSE_AMT']
        app.premium_service_tax = d["MODAL_PREM_SERV_TAX"]
        app.mortality_extra_premium = d["MORTLTY_EXTRA_PREM"]
        app.flat_extra_premium = d["FLAT_EXTRA_PREM"]

        app.proposal_acceptance_date = iutils.format_date(d['policy_issue_date'])
        app.mail_data = iutils.format_date(d['mailDate'])
        app.npw_due_date = iutils.format_date(d['npwDueDate'])
        app.npw_status = d['npwStatus']
        app.bill_date = d['bill_date']
        app.deliveryDate = d['deliveryDate']
        app.courier_name = d['courier_name']
        app.deliveryStatus = d['deliveryStatus']
        app.policy_number = d['policy_number']  # 6109
        app.client_id = d['client_id']  # 6109

        # new plan id added sept 2016
        app.base_plan_id = d['basePlanId']
        # new rider added adb but not used becse getting data from create app in emerge follow inginium adb rider
        # app.accidentalDeathAndBenefitPlus = d['accidentalDeathAndBenefitPlus']
        # app.accidentalDeathAndBenefitPlusPre = d['accidentalDeathAndBenefitPlusPre']
        

        # 6733
        app.reqt_reason = d['Reqt_Reason'].capitalize()  # 6733
        # 6733
        if d['Smoker_Non-Smoker'] == "S":
            d['Smoker_Non-Smoker'] = "Smoker"
        else:
            d['Smoker_Non-Smoker'] = "Non Smoker"
            
        app.smoker_non_smoker = d['Smoker_Non-Smoker']  # 6733
        
        app.save()

        apca = app.applicationcallattribute
        apca.app_status = POLICY_STATUS_MAPPING[d['policy_status']]
        apca.save()


        
        # 6733 secondary insurer data update
        try:
            insurer_update = InsurerApplication.objects.get(ins_application=app)
            
            second_uw_amount, second_uw_reason, second_uw_reason_text, second_sum_assured, second_flat_extra_prem, second_mortality_extra_prem, second_modal_prem_serv_tax, second_term, ar_status, second_req_reason, second_smoker_non_smoker, second_sum_assured_interval, second_sum_assured_option = d['sdlrider']
            
            insurer_update.ins_app_uw_amount = second_uw_amount
            insurer_update.ins_app_uw_reason = second_uw_reason
            insurer_update.ins_app_uw_reason_text = second_uw_reason_text
            insurer_update.ins_sum_assured = second_sum_assured
            insurer_update.ins_flat_extra_premium = second_flat_extra_prem
            insurer_update.ins_mortality_extra_premium = second_mortality_extra_prem
            insurer_update.ins_premium_service_tax = second_modal_prem_serv_tax
            insurer_update.ins_policy_term = second_term
            insurer_update.ins_app_status = ar_status
            insurer_update.ins_req_reason = second_req_reason.capitalize()
            
            insurer_update.ins_sum_assured_option = second_sum_assured_option
            insurer_update.ins_sum_assured_interval = second_sum_assured_interval
            
            if second_smoker_non_smoker == "S":
                second_smoker_non_smoker = "Smoker"
            else:
                second_smoker_non_smoker = "Non Smoker"
            
            insurer_update.ins_smoker_non_smoker = second_smoker_non_smoker

            insurer_update.save()

        except Exception as e:
            print ("Secondary Insurer Not Present")

    if errors:
        return HttpResponse(simplejson.dumps({'success': False, 'errors': errors}))
    else:
        return HttpResponse(simplejson.dumps({'success': True}))


# 5820-F
def add_revised_premium(request):
    apps = Application.objects.all()
    for app in apps:

        # insurer added for primium service tax calculation
        # 6733
        try:
            ins_tax = InsurerApplication.objects.get(ins_application=app)
        except:
            ins_tax = None
            print "error to calculate revised premium insurer joint life"# insurer added on manager single scrren 6733
        
        # 6733 added joint life premium service tax 
        if  app.product_name == "JointLife":

                revised_premium = float(
                    app.premium_service_tax + app.accidental_premium_service_tax + app.critical_premium_service_tax + app.surgical_premium_service_tax + app.hospital_premium_service_tax + app.accidentaldeathbenefit_premium_service_tax + app.waiverofPremium_premium_service_tax + ins_tax.ins_premium_service_tax )

                return render_to_response("mailer/latest_uw_mailer1.html", "mailer/latest_uw_mailer2.html",
                                          {"revised_premium": revised_premium,},
                                          context_instance=RequestContext(request))
  
        else:
            revised_premium = float(
                  app.premium_service_tax + app.accidental_premium_service_tax + app.critical_premium_service_tax + app.surgical_premium_service_tax + app.hospital_premium_service_tax + app.accidentaldeathbenefit_premium_service_tax + app.waiverofPremium_premium_service_tax )

            return render_to_response("mailer/latest_uw_mailer1.html", "mailer/latest_uw_mailer2.html",
                                        {"revised_premium": revised_premium,},
                                        context_instance=RequestContext(request))


@login_required
def index(request):
    if request.user.is_authenticated():
        # 6109
        print "id"
        userObj = UserSession.objects.filter(user=request.user.id).values_list('session_id')
     
        # i have commented for 6733
        
        #if userObj:
         #   if userObj[0][0] != request.session.session_key:
                #  delete_user_sessions(request.user.id)
                #  return HttpResponseRedirect('/accounts/logout')
          #      messages = str(request.user) + " " + "already logged in"
          #     logout(request)
          #      return render_to_response("registration/login.html", {"messages": messages},
          #                                context_instance=RequestContext(request))

        # end6109
        if request.user.is_superuser:
            return HttpResponseRedirect('/nimda/')
        try:
            user_profile = request.user.userprofile
        except:
            return HttpResponse("""Error ! There is some problem with your user account, contact support or mail us at support@gototest.com !<br/>
                click <a href="/accounts/logout/">here</a> to try again !
            """)

        user_urls = {
            "MANAGER": '/manager/navigate/',
            "UPLOAD": '/upload/dashboard/',
            "REPORT": '/report/dashboard/',
            "UHCREPORT": '/report/dashboard/',
            "CALLCENTER": '/callcenter/dashboard/',
            "COURIER": '/search/',
            "COURIER_REP": '/search/',
            "REVIEWER": '/search/',
            "UHC": '/uhc/dashboard/',
            "EMERGE": '/emerge/dashboard',  # newly added 17th may 2016
            "NEW_TELECALLER": '/new-telecaller/dashboard/',
            "AFFILIATE": '/affiliate/dashboard/',
            "AFFILIATE_ADMIN": '/affiliate-admin/dashboard/',
        }
        return HttpResponseRedirect(user_urls.get(user_profile.role, "/search/"))
    else:
        return HttpResponseRedirect("/accounts/login/")


@login_required
@utils.profile_type_only("CALLCENTER")
def take_call(request, cid):
    c = CallHistory.objects.get(id=cid)

    return render_to_response("core/take_call.html", {
        'call': c,
        'app': c.application,
    },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("CALLCENTER")
def search_and_call(request, app_id):
    app = Application.objects.get(app_id=app_id)
    apca = app.applicationcallattribute
    if apca.call_barred:
        return render_to_response("core/search.html",
                                  {
                                      'msg': 'Application cannot be called now, Its either barred or has moved from proposal status',
                                  },
                                  context_instance=RequestContext(request)
                                  )
    if apca.is_taken:
        return render_to_response("core/search.html",
                                  {
                                      'msg': 'Application is already taken by %s' % apca.assigned_to.get_full_name(),
                                  },
                                  context_instance=RequestContext(request)
                                  )
    else:
        c = iutils.get_call_record_for_application(request, apca)
        return HttpResponseRedirect("/callcenter/dashboard/%s/" % c.id)


@never_cache
@login_required
@utils.profile_type_only("CALLCENTER")
def callcenter_dashboard(request, cid):
    """ if there is a customer id(cid) in url then fetch his details from applicationcallattribute table and display and after the disposition status is submitted it calls the iutils.save_call_disposition function else if there is no cid then it calls get_call_records function where it looks for other calls, if no other call is found then calls are exhausted.  """

    if cid:
        
        # TODO: Handle double click or double post scenario!?
        c = CallHistory.objects.get(id=cid)
        if request.POST and 'submit' in request.POST:
            print request.POST
            call_form = CallForm(request.POST)
            if call_form.is_valid():
                iutils.save_call_disposition(c, call_form, request)
                return HttpResponseRedirect('/callcenter/take-call/%s/' % (cid))
            else:
                print call_form.errors
                return HttpResponse('ERROR IN CALLFORM ! Contact sysadmin asap.')

        else:
            apca = c.application.applicationcallattribute
            chs = CallHistory.objects.filter(application__id=c.application.id, id__lt=c.id).order_by('-id')
            if chs:
                preremark = chs[0].predefined_remark
            else:
                preremark = ''
            call_form = CallForm(initial={
                'courier_date': apca.courier_date,
                'fup_commited_date': apca.fup_commited_date,
                'document_commited_date': apca.document_commited_date,
                'photo_id_proof': apca.photo_id_proof,
                'age_proof': apca.age_proof,
                'address_proof': apca.address_proof,
                'income_proof': apca.income_proof,
                'attested_photograph': apca.attested_photograph,
                'address1': apca.address1,
                'document_delivery_method': apca.document_delivery_method,
                # 'auto_notes':preremark
            })
            sms_form = SMSForm()
            alluhc = UHCData.objects.filter(application=c.application)
            if alluhc:
                uhc = alluhc[0]
            else:
                uhc = None
            call_history_list = list(c.application.callhistory_set.order_by('-created_on'))[1:]
            nonmedical_fups = c.application.fup_associated.filter(code__is_medical=False).exclude(
                code__name__in=['CWA', 'RQ042']).order_by('received_on')
            medical_fups = c.application.fup_associated.filter(code__is_medical=True).order_by('received_on')
            tests = [f.code.description for f in c.application.fup_associated.all() if
                     f.code.is_medical and f.order_status == 'ORD']
            photo_id_date = ''
            age_date = ''
            address_date = ''
            income_date = ''

            if c.application.photo_id_proof_rcvd_date:
                try:
                    photo_id_date = datetime.datetime.strftime(
                        datetime.datetime.strptime(c.application.photo_id_proof_rcvd_date, '%m%d%Y %H:%M:%S'),
                        '%d/%m/%Y %H:%M:%S')
                except:

                    # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
                    try:
                        photo_id_date = datetime.datetime.strftime(
                            datetime.datetime.strptime(c.application.photo_id_proof_rcvd_date, '%m%d%Y'),
                            '%d/%m/%Y %H:%M:%S')
                    except:
                        photo_id_date = c.application.photo_id_proof_rcvd_date


            if c.application.address_proof_rcvd_date:
                try:
                    address_date = datetime.datetime.strftime(
                        datetime.datetime.strptime(c.application.address_proof_rcvd_date, '%m%d%Y %H:%M:%S'),
                        '%d/%m/%Y %H:%M:%S')
                except:
                    # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
                    try:
                        address_date = datetime.datetime.strftime(
                            datetime.datetime.strptime(c.application.address_proof_rcvd_date, '%m%d%Y'),
                            '%d/%m/%Y %H:%M:%S')
                    except:
                        address_date = c.application.address_proof_rcvd_date


                        
            if c.application.age_proof_rcvd_date:
                try:
                    age_date = datetime.datetime.strftime(
                        datetime.datetime.strptime(c.application.age_proof_rcvd_date, '%m%d%Y %H:%M:%S'),
                        '%d/%m/%Y %H:%M:%S')
                except:
                    # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
                    try:
                        age_date = datetime.datetime.strftime(
                            datetime.datetime.strptime(c.application.age_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
                    except:
                        
                        age_date =  c.application.age_proof_rcvd_date


            if c.application.income_proof_rcvd_date:
                try:
                    income_date = datetime.datetime.strftime(
                        datetime.datetime.strptime(c.application.income_proof_rcvd_date, '%m%d%Y %H:%M:%S'),
                        '%d/%m/%Y %H:%M:%S')
                except:
                    # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
                    try:
                        
                        income_date = datetime.datetime.strftime(
                            datetime.datetime.strptime(c.application.income_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
                    
                    except:
                        
                            income_date =  c.application.income_proof_rcvd_date


            print c.application.app_status_reason
            mob = c.application.mobile
            
            # added for joint life second screen 6733
            try:
                
                i_app = InsurerApplication.objects.get(ins_application=c.application_id)
                
            except:
                i_app = None
                print "Insurer application not present"
            # 6733 code to identify product name
            try:
                
                app_product = Application.objects.get(id= c.application_id)
                product_name = app_product.product_name 
            except:
                product_name = None
                print "Insurer application not present"
                
            return render_to_response("core/callcenter.html", {
                'call': c,
                'nonmedical_fups': nonmedical_fups,
                'medical_fups': medical_fups,
                'call_form': call_form,
                'uhc': uhc,
                'sms_form': sms_form,
                'call_history_list': call_history_list,
                'alluhc': alluhc,
                'tests': tests,
                'photo_id_date': photo_id_date,
                'age_date': age_date,
                'address_date': address_date,
                'income_date': income_date,
                'mob': mob,
                'ins_call': i_app,               # 6733
                'product_name': product_name     # 6733
            },
                                      context_instance=RequestContext(request)
                                      )
    else:
        c = iutils.get_call_record(request)
        if not c:
            return render_to_response("core/call_exhausted.html", {}, context_instance=RequestContext(request))
        return HttpResponseRedirect("/callcenter/dashboard/%s/" % c.id)


@login_required
@utils.profile_type_only("MANAGER")
def clean_dirty_application(request):
    i = 0
    for apca in ApplicationCallAttribute.objects.filter(is_taken=True):
        apca.is_taken = False
        apca.save()
        apca.application.callhistory_set.filter(disposition='').delete()
        i += 1
    return HttpResponse('Cleared %s applications from dirty mode' % str(i))


@login_required
@utils.profile_type_only("CALLCENTER")
def add_mecode(request, app_id, mecode):
    app = Application.objects.get(id=app_id)
    ap_callattr = app.applicationcallattribute
    try:
        mecode = Mecode.objects.get(me_code=mecode)
    except:
        return HttpResponse('ERROR')
    ap_callattr.mecode.add(mecode)
    mejson = serializers.serialize("json", [mecode])
    return HttpResponse(mejson)


@login_required
@utils.profile_type_only("CALLCENTER")
def remove_mecode(request, app_id, mecode):
    app = Application.objects.get(id=app_id)
    ap_callattr = app.applicationcallattribute
    mecode = Mecode.objects.get(me_code=mecode)
    ap_callattr.mecode.remove(mecode)
    return HttpResponse(mecode.me_code)


@login_required
@utils.profile_type_only("MANAGER", "UPLOAD")
def upload_app_data(request):
    if request.FILES and request.FILES.get('upload_file'):
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, user=request.user)
        upfile.save()
        upload_file = upfile.upload_file
        file_contents = upload_file.read()
        (objects_added, objects_updated, objects_not_changed, objects_error, error_dump) = iutils.save_app_data(
            file_contents)
        upfile.is_processed = True
        output_dict = {
            'objects_added': objects_added,
            'objects_updated': objects_updated,
            'objects_not_changed': objects_not_changed,
            'objects_error': objects_error,
            'error_dump': error_dump,
        }
        output = simplejson.dumps(output_dict)
        upfile.output = output
        upfile.save()
        return render_to_response("core/uploads.html",
                                  {
                                      'objects_added': objects_added,
                                      'objects_updated': objects_updated,
                                      'objects_not_changed': objects_not_changed,
                                      'objects_error': objects_error,
                                      'error_dump': error_dump,
                                  },
                                  context_instance=RequestContext(request)
                                  )
    else:
        upload_form = UploadForm()
    return HttpResponseRedirect('/manager/uploads/')


@login_required
@utils.profile_type_only("MANAGER", "UPLOAD")
def upload_fup_data(request):
    if request.POST or request.FILES:
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, user=request.user)
        upfile.save()
        upload_file = upfile.upload_file
        upload_file.open()
        file_contents = upload_file.read()
        (fups_added, fups_updated, objects_error, error_dump) = iutils.save_fup_data(file_contents)
        upfile.is_processed = True
        output_dict = {
            'objects_added': fups_added,
            'objects_updated': fups_updated,
            'objects_error': objects_error,
            'error_dump': error_dump,
        }
        output = simplejson.dumps(output_dict)
        upfile.output = output
        upfile.save()
        return render_to_response("core/uploads.html",
                                  {
                                      'objects_added': fups_added,
                                      'objects_updated': fups_updated,
                                      'objects_error': objects_error,
                                      'error_dump': error_dump,
                                  },
                                  context_instance=RequestContext(request)
                                  )
    else:
        upload_form = UploadForm()
    return HttpResponseRedirect('/manager/uploads/')


@login_required
@utils.profile_type_only("MANAGER", "UPLOAD")
def upload_proposal_data(request):
    if request.POST or request.FILES:
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, user=request.user)
        upfile.save()
        upload_file = upfile.upload_file
        file_contents = upload_file.read()
        (objects_added, objects_updated, objects_error, error_dump) = iutils.save_proposal_data(file_contents)
        upfile.is_processed = True
        output_dict = {
            'objects_added': objects_added,
            'objects_updated': objects_updated,
            'objects_error': objects_error,
            'error_dump': error_dump,
        }
        output = simplejson.dumps(output_dict)
        upfile.output = output
        upfile.save()
        return render_to_response("core/uploads.html",
                                  {
                                      'objects_added': objects_added,
                                      'objects_updated': objects_updated,
                                      'objects_error': objects_error,
                                      'error_dump': error_dump,
                                  },
                                  context_instance=RequestContext(request)
                                  )
    else:
        upload_form = UploadForm()
    return HttpResponseRedirect('/manager/uploads/')


class UHCUpload(Xl2Python):
    def clean_app(self, val):
        return Application.objects.get(app_id=val)


@login_required
@utils.profile_type_only("UHC")
def uhc_upload(request):
    """
    Application No, Medical Schedule Date, Time, DC Code, DC Name, DC Address, Doctor Name, Doctor Contact Number, Contact Details, TA Code, Status, Remarks

    <Status Options>
    Confirmed
    Report pending
    Partial show
    No show
    """
    if request.POST or request.FILES:
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, user=request.user)
        upfile.save()
        upload_file = upfile.upload_file
        xl_field_map = {
            '0': 'sr_no',
            '1': 'app',
            # '2': ('medicalappointment_date1', 'datetime','%d-%m-%Y'),
            # '3': ('medicalappointment_time1', 'time','%H:%M'),
            '2': 'uhci_file_received_date',

            '3': 'dc_code',
            '4': 'dc_name',
            '5': 'dc_address',
            '6': 'doctor_name',
            '7': 'doctor_contact_number',
            '8': 'ta_code',
            '9': 'medicalappointment_date1',
            '10': 'medicalappointment_date2',
            '11': 'medicalappointment_date3',
            '12': 'confirm_sms_date',
            '13': 'confirm_email_date',
            '14': 'uhci_scheduled_date',
            '15': 'med_done_date',
            '16': 'bsli_reports_sent_date',
            '17': 'status',
            '18': 'remarks'
        }
        error = None
        xlm = UHCUpload(xl_field_map, upload_file.read())
        if xlm.is_valid():
            upload_status = "Upload sucessful"
            print "DATA -->", xlm.cleaned_data
            if not xlm.cleaned_data:
                upload_status = "The first coloum should be filled"

            for d in xlm.cleaned_data:
                app = d['app']
                apca = app.applicationcallattribute
                uhc_data = UHCData.objects.filter(application=app)
                d.pop('sr_no')
                d.pop('app')

                if not d['uhci_file_received_date']:
                    d.pop('uhci_file_received_date')
                else:
                    d['uhci_file_received_date'] = datetime.datetime.strptime(
                        str(d['uhci_file_received_date'].replace("'", "")), '%Y-%m-%d %H:%M:%S')

                if d['medicalappointment_date1']:
                    d['medicalappointment_date1'] = datetime.datetime.strptime(
                        str(d['medicalappointment_date1'].replace("'", "")), '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('medicalappointment_date1')

                if d['medicalappointment_date2']:
                    d['medicalappointment_date2'] = datetime.datetime.strptime(
                        str(d['medicalappointment_date2'].replace("'", "")), '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('medicalappointment_date2')
                if d['medicalappointment_date3']:
                    d['medicalappointment_date3'] = datetime.datetime.strptime(
                        str(d['medicalappointment_date3'].replace("'", "")), '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('medicalappointment_date3')

                if d['confirm_sms_date']:
                    d['confirm_sms_date'] = datetime.datetime.strptime(str(d['confirm_sms_date'].replace("'", "")),
                                                                       '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('confirm_sms_date')

                if d['confirm_email_date']:
                    d['confirm_email_date'] = datetime.datetime.strptime(str(d['confirm_email_date'].replace("'", "")),
                                                                         '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('confirm_email_date')

                if d['uhci_scheduled_date']:
                    d['uhci_scheduled_date'] = datetime.datetime.strptime(
                        str(d['uhci_scheduled_date'].replace("'", "")), '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('uhci_scheduled_date')
                if d['med_done_date']:
                    d['med_done_date'] = datetime.datetime.strptime(str(d['med_done_date'].replace("'", "")),
                                                                    '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('med_done_date')
                if d['bsli_reports_sent_date']:
                    d['bsli_reports_sent_date'] = datetime.datetime.strptime(
                        str(d['bsli_reports_sent_date'].replace("'", "")), '%Y-%m-%d %H:%M:%S')
                else:
                    d.pop('bsli_reports_sent_date')

                if uhc_data:
                    d['status'] = "%s | %s" % (d['status'], uhc_data[0].status)
                    if d['status'].lower().count('no show') >= 2 or d['status'].lower().count('not interested') >= 1 or \
                                    d['status'].lower().count('max attempt') >= 1:
                        apca.next_calltime = datetime.datetime.now()
                        apca.is_uhc = True
                        apca.save()
                        print apca

                    else:
                        apca.is_uhc = False
                        apca.save()
                        uhc_data.update(**d)
                        uhc_data = uhc_data[0]
                else:
                    uhc_data = UHCData(**d)
                    uhc_data.application = app
                    uhc_data.save()

        else:
            upload_status = "Upload unsucessful"
            print "ERROR ---->", xlm.errors
            error = xlm.errors

        return render_to_response("core/uhc_validation.html", {
            'success': upload_status, 'time': datetime.datetime.now(), 'error': error,
        }, context_instance=RequestContext(request)
                                  )
    else:
        return HttpResponseRedirect('/uhc/dashboard/')


@login_required
@utils.profile_type_only("UHC")
def uhc_validation(request):
    app = Application.objects.get(app_id='BA0000204')
    mail_type = 'UW_EXTRA_HEALTH'
    return render_to_response("mailers/mail_requirements.html",
                              {'app': app,
                               'mail_type': mail_type
                               },
                              context_instance=RequestContext(request)
                              )


#    return render_to_response("core/uhc_validation.html",context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def manager_reports(request):
    return render_to_response("core/reports.html",
                              {
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "UPLOAD")
def manager_uploads(request):
    return render_to_response("core/uploads.html",
                              {
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def manager_downloads(request):
    return render_to_response("core/downloads.html",
                              {
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER")
def user_edit(request, uid):
    u = User.objects.get(id=uid)
    if request.POST:
        call_center_userform = UserForm(uid, "CALLCENTER", request.POST)
        if call_center_userform.is_valid():
            call_center_userform.save()
            return HttpResponseRedirect('/manager/user/manage/')
        else:
            print call_center_userform.errors
    else:
        call_center_userform = UserForm(uid, "CALLCENTER",
                                        initial={'first_name': u.first_name, 'last_name': u.last_name})
    return render_to_response("core/user-add.html",
                              {
                                  'ccuform': call_center_userform,
                                  'uid': uid,
                              },
                              context_instance=RequestContext(request)
                              )
    return render_to_response("core/user-add.html",
                              {
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER")
def user_add(request):
    if request.POST:
        call_center_userform = UserForm(None, "CALLCENTER", request.POST)
        if call_center_userform.is_valid():
            call_center_userform.save()
            return HttpResponseRedirect('/manager/user/manage/')
        else:
            print call_center_userform.errors
    else:
        call_center_userform = UserForm(None, "CALLCENTER")
    return render_to_response("core/user-add.html",
                              {
                                  'ccuform': call_center_userform,
                              },
                              context_instance=RequestContext(request)
                              )


@csrf_exempt
@never_cache
@login_required
@utils.profile_type_only("MANAGER")
def user_manage(request):
    if request.POST:
        username = request.POST['search']
        user_list = User.objects.filter(userprofile__role='CALLCENTER', username=username)
        return render_to_response("core/user-manage.html",
                                  {
                                      'user_list': user_list
                                  },
                                  context_instance=RequestContext(request)
                                  )

    else:
        user_list = User.objects.filter(userprofile__role='CALLCENTER')
        return render_to_response("core/user-manage.html",
                                  {
                                      'user_list': user_list
                                  },
                                  context_instance=RequestContext(request)
                                  )


@never_cache
@login_required
@utils.profile_type_only("MANAGER")
def manager_call_priority_edit(request):
    """ this view is used to display the call priority and edit it by the manager """
    response = HttpResponse()

    cp = CallPriority.objects.get()
    workload, vc, ti, w, wv, r, f = iutils.workload_calculator()
    print w
    if request.POST:
        cpf = CallPriorityForm(request.POST, instance=cp)
        if cpf.is_valid():
            cpf.save()
            cp = CallPriority.objects.get()
        else:
            print cpf.errors
    else:
        cpf = CallPriorityForm(instance=cp)
    return render_to_response("core/prioritize.html",
                              {
                                  'cp_form': cpf,
                                  'cp': cp,
                                  'priority_choice': dict(PRIORITY_CHOICES),
                                  'workload': workload,
                                  'vc': vc,
                                  'ti': ti,
                                  'w': w,
                                  'wv': wv,
                                  'r': r,
                                  'f': f,
                              },
                              context_instance=RequestContext(request)
                              )


# VIEW FOR PRAFULL TESTING PURPOSE
# def show_html(request, filename):
#    return render_to_response("core/%s.html" % (filename), { },
#        context_instance=RequestContext(request)
#    )

@never_cache
@login_required
@utils.profile_type_only("MANAGER")
def user_disable(request, uid):
    u = User.objects.get(id=uid)
    u.is_active = False
    u.save()
    return HttpResponseRedirect('/manager/user/manage/')


@never_cache
@login_required
@utils.profile_type_only("MANAGER")
def user_enable(request, uid):
    u = User.objects.get(id=uid)
    u.is_active = True
    u.save()
    return HttpResponseRedirect('/manager/user/manage/')


def check_courier(request, pin):
    try:
        pin = int(pin)
    except:
        pin = 0
    s = ServicableCourierPincode.objects.filter(pin=pin).count()
    if s > 0:
        return HttpResponse("Y")
    else:
        return HttpResponse("N")


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_status_report(request):
    response = HttpResponse()
    q = "select year(transaction_end_time) as year, month(transaction_end_time) as month, count(1) as count from core_application where transaction_end_time > ADDDATE(now(), INTERVAL -12 MONTH) group by year(transaction_end_time),month(transaction_end_time);"
    sourced = sqltodict(q, [])

    q = "select year(transaction_end_time) as year, month(transaction_end_time) as month, count(1) as count from core_application where transaction_end_time > ADDDATE(now(), INTERVAL -12 MONTH) and app_status = 'IF' group by year(transaction_end_time),month(transaction_end_time);"
    issued_dict = sqltodict(q, [])
    issued = dict([(i['month'], i) for i in issued_dict])

    q = "select year(transaction_end_time) as year, month(transaction_end_time) as month, count(1) as count from core_application where transaction_end_time > ADDDATE(now(), INTERVAL -12 MONTH) and app_status <> 'PS' group by year(transaction_end_time), month(transaction_end_time);"
    closed_dict = sqltodict(q, [])
    closed = dict([(c['month'], c) for c in closed_dict])

    q = "select year(transaction_end_time) as year, month(transaction_end_time) as month, count(1) as count from core_application where transaction_end_time > ADDDATE(now(), INTERVAL -12 MONTH) and app_status = 'PS' group by year(transaction_end_time), month(transaction_end_time);"
    otid = sqltodict(q, [])
    oti = dict([(o['month'], o) for o in otid])

    final_list = []
    month_dict = {1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June', 7: 'July', 8: 'August',
                  9: 'September', 10: 'October', 11: 'November', 12: 'December'}
    overall = {}
    overall['sourced'] = 0
    overall['issued'] = 0
    overall['closed'] = 0
    overall['oti'] = 0
    for j in range(0, len(sourced)):
        month_index = (sourced[j]['month'])
        monthly = {}
        monthly['month'] = month_dict[sourced[j]['month']]
        monthly['year'] = sourced[j]['year']
        monthly['sourced'] = float(sourced[j]['count'])
        overall['sourced'] += int(sourced[j]['count'])
        if month_index in issued:
            monthly['issued'] = float(issued[month_index]['count'])
            overall['issued'] = overall['issued'] + int(issued[month_index]['count'])
        else:
            monthly['issued'] = float(0)
        monthly['gross_issued'] = "%.2f" % (float(monthly['issued']) / float(monthly['sourced']) * 100)
        if month_index in closed:
            monthly['closed'] = float(closed[month_index]['count'])
            overall['closed'] = overall['closed'] + int(closed[month_index]['count'])
        else:
            monthly['closed'] = float(0)
        monthly['gross_closed'] = "%.2f" % (float(monthly['closed']) / float(monthly['sourced']) * 100)
        if month_index in oti:
            monthly['oti'] = float(oti[month_index]['count'])
            overall['oti'] = overall['oti'] + int(oti[month_index]['count'])
        else:
            monthly['oti'] = float(0)
        monthly['gross_oti'] = "%.2f" % (float(monthly['oti']) / float(monthly['sourced']) * 100)
        final_list.append(monthly.copy())
    overall['gross_issued'] = "%.2f" % (float(overall['issued']) / float(overall['sourced']) * 100)
    overall['gross_closed'] = "%.2f" % (float(overall['closed']) / float(overall['sourced']) * 100)
    overall['gross_oti'] = "%.2f" % (float(overall['oti']) / float(overall['sourced']) * 100)

    return render_to_response('core/report_app_status.html', {'final_list': final_list, 'overall': overall},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def application_movement_report(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            from_time = form.cleaned_data['start_date']
            to_time = form.cleaned_data['end_date'] + datetime.timedelta(days=1)
            data = []
            order = ['app_id', 'F', 'W', 'WV', 'V', '1R', 'R', 'TI', 'TF', 'TF-AUTO', 'FINAL', 'STATUS']
            for a in Application.objects.filter(transaction_end_time__gte=from_time, transaction_end_time__lt=to_time):
                app_chs = {'app_id': a.app_id, 'F': a.transaction_end_time, 'W': None, 'WV': None, 'V': None,
                           '1R': None, 'R': None, 'TI': None, 'TF': None, 'TF-AUTO': None, 'FINAL': None,
                           'STATUS': a.app_status}
                chs = a.callhistory_set.order_by('created_on')
                for ch in chs:
                    if ch.call_type == 'R':
                        if not app_chs.get('R'): app_chs['1R'] = ch.created_on
                    app_chs[ch.call_type] = ch.created_on
                if not a.app_status == "PS":
                    app_chs['FINAL'] = a.proposal_acceptance_date
                data.append([app_chs[o] for o in order])

            filename = "application_movement_report.xls"
            order = ['Application', 'Fresh Upload', 'Welcome Call', 'Welcome Verification Call', 'Verfication Call',
                     'First Reminder Call', 'Final Reminder Call', 'Thank you Interim Call', 'Thank you Final Call',
                     'Auto-Disposed Thank you', 'Issuance Date', 'Status']
            return utils.render_excel(filename, order, data)
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_disposition_report(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect("/manager/status-ageing-report/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def status_ageing_report(request, from_time, to_time):
    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d")))
    end_months = (to_time.year - from_time.year) * 12 + to_time.month + 1

    dates = ["%s-%s" % (yr, mn) for (yr, mn) in
             (((m - 1) / 12 + from_time.year, (m - 1) % 12 + 1) for m in range(from_time.month, end_months))]

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s group by month, year;"
    d = sqltodict(q, [from_time])
    base = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    base = iutils.sum_dict(base, {}, dates)
    print base

    base_per = iutils.per_dict(base, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application as a inner join core_applicationcallattribute as aca on a.id = aca.application_id  where transaction_end_time > %s and is_ats_uploaded = 0 group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    not_ats = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    not_ats = iutils.sum_dict(not_ats, {}, dates)
    print not_ats

    not_ats_per = iutils.per_dict(not_ats, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'PS' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    proposal = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    proposal = iutils.sum_dict(proposal, {}, dates)

    proposal_per = iutils.per_dict(proposal, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'PO' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    postpone = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    postpone = iutils.sum_dict(postpone, {}, dates)

    postpone_per = iutils.per_dict(postpone, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'DC' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    declined = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    declined = iutils.sum_dict(declined, {}, dates)

    declined_per = iutils.per_dict(declined, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'WD' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    withdrawn = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    withdrawn = iutils.sum_dict(withdrawn, {}, dates)

    withdrawn_per = iutils.per_dict(withdrawn, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'FL' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    freelook = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    freelook = iutils.sum_dict(freelook, {}, dates)

    freelook_per = iutils.per_dict(freelook, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'CFI' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    cfi = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    cfi = iutils.sum_dict(cfi, {}, dates)

    cfi_per = iutils.per_dict(cfi, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'IF' group by month, year order by year, month;"
    d = sqltodict(q, [from_time])
    in_force = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    in_force = iutils.sum_dict(in_force, {}, dates)

    in_force_per = iutils.per_dict(in_force, base, dates)

    q = "select month(transaction_end_time) as month, year(transaction_end_time) as year, count(1) as count from core_application where transaction_end_time > %s and app_status = 'FL' group by month, year order by year,month;"
    d = sqltodict(q, [from_time])
    free_look = dict([("%s-%s" % (i['year'], i['month']), i['count']) for i in d])
    free_look = iutils.sum_dict(free_look, {}, dates)

    free_look_per = iutils.per_dict(free_look, base, dates)

    pending_total = iutils.sum_dict(not_ats, proposal, dates)
    pending_total_per = iutils.per_dict(pending_total, base, dates)

    pre_issuance_reject_total = iutils.sum_dict(cfi,
                                                iutils.sum_dict(withdrawn, iutils.sum_dict(postpone, declined, dates),
                                                                dates), dates)
    pre_issuance_reject_total_per = iutils.per_dict(pre_issuance_reject_total, base, dates)

    post_iss_cancelation_total = iutils.sum_dict(free_look, {}, dates)
    post_iss_cancelation_total_per = iutils.per_dict(post_iss_cancelation_total, base, dates)

    grand_total = {}
    grand_total['not_ats'] = sum([i for i in not_ats.values()])
    grand_total['proposal'] = sum([i for i in proposal.values()])
    grand_total['declined'] = sum([i for i in declined.values()])
    grand_total['postpone'] = sum([i for i in postpone.values()])
    grand_total['withdrawn'] = sum([i for i in withdrawn.values()])
    grand_total['freelook'] = sum([i for i in withdrawn.values()])
    grand_total['cfi'] = sum([i for i in cfi.values()])
    grand_total['in_force'] = sum([i for i in in_force.values()])
    grand_total['free_look'] = sum([i for i in free_look.values()])
    grand_total['pending_total'] = sum([i for i in pending_total.values()])
    grand_total['pre_issuance_reject_total'] = sum([i for i in pre_issuance_reject_total.values()])
    grand_total['post_iss_cancelation_total'] = sum([i for i in post_iss_cancelation_total.values()])
    gta = sum([i for i in grand_total.values()])
    grand_total['base'] = gta

    if gta != 0:
        grand_total['base_per'] = "%.2f" % ((float(gta / gta) * 100))
        grand_total['not_ats_per'] = "%.2f" % ((float(grand_total['not_ats']) / gta) * 100)
        grand_total['proposal_per'] = "%.2f" % ((float(grand_total['proposal']) / gta) * 100)
        grand_total['declined_per'] = "%.2f" % ((float(grand_total['declined']) / gta) * 100)
        grand_total['postpone_per'] = "%.2f" % ((float(grand_total['postpone']) / gta) * 100)
        grand_total['withdrawn_per'] = "%.2f" % ((float(grand_total['withdrawn']) / gta) * 100)
        grand_total['freelook_per'] = "%.2f" % ((float(grand_total['freelook']) / gta) * 100)
        grand_total['cfi_per'] = "%.2f" % ((float(grand_total['cfi']) / gta) * 100)
        grand_total['in_force_per'] = "%.2f" % ((float(grand_total['in_force']) / gta) * 100)
        grand_total['free_look_per'] = "%.2f" % ((float(grand_total['free_look']) / gta) * 100)
        grand_total['pending_total_per'] = "%.2f" % ((float(grand_total['pending_total']) / gta) * 100)
        grand_total['pre_issuance_reject_total_per'] = "%.2f" % (
        (float(grand_total['pre_issuance_reject_total']) / gta) * 100)
        grand_total['post_iss_cancelation_total_per'] = "%.2f" % (
        (float(grand_total['post_iss_cancelation_total']) / gta) * 100)
    return render_to_response('core/report_app_disposition.html',
                              {
                                  'dates': dates,
                                  'base': base,
                                  'base_per': base_per,
                                  'not_ats': not_ats,
                                  'not_ats_per': not_ats_per,
                                  'proposal': proposal,
                                  'proposal_per': proposal_per,
                                  'declined': declined,
                                  'declined_per': declined_per,
                                  'postpone': postpone,
                                  'postpone_per': postpone_per,
                                  'withdrawn': withdrawn,
                                  'withdrawn_per': withdrawn_per,
                                  'freelook': freelook,
                                  'freelook_per': freelook_per,
                                  'cfi': cfi,
                                  'cfi_per': cfi_per,
                                  'in_force': in_force,
                                  'in_force_per': in_force_per,
                                  'free_look': free_look,
                                  'free_look_per': free_look_per,
                                  'pending_total': pending_total,
                                  'pending_total_per': pending_total_per,
                                  'pre_issuance_reject_total': pre_issuance_reject_total,
                                  'pre_issuance_reject_total_per': pre_issuance_reject_total_per,
                                  'post_iss_cancelation_total': post_iss_cancelation_total,
                                  'post_iss_cancelation_total_per': post_iss_cancelation_total_per,
                                  'grand_total': grand_total,
                              }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_exception_report(request):
    download_id = int(request.GET.get('eid', 0))
    print download_id
    # For ex1: All app ids where FUPs are not opened within T+2 of payment date
    date_ylimit = datetime.datetime.now() - datetime.timedelta(days=2)
    appids1 = Application.objects.filter(applicationcallattribute__is_ats_uploaded=False,
                                         transaction_end_time__lt=date_ylimit).distinct()
    ex1 = appids1.count()

    # For ex2 : All app ids where document FUPs are not closed (no received date) within T+10 of FUP open date
    appids2 = Application.objects.filter(fup_associated__received_on__isnull=True,
                                         fup_associated__generated_on__lt=datetime.datetime.now() - datetime.timedelta(
                                             days=7), fup_associated__code__is_medical=False,
                                         applicationcallattribute__app_status='PS').distinct()
    ex2 = appids2.count()

    # For ex3 : All app ids where FUPs are not closed (no received date) within T+10 of FUP open date
    appids3 = Application.objects.filter(fup_associated__received_on__isnull=True,
                                         fup_associated__generated_on__lt=datetime.datetime.now() - datetime.timedelta(
                                             days=7), fup_associated__code__is_medical=True,
                                         applicationcallattribute__app_status='PS').distinct()
    ex3 = appids3.count()

    # For ex4: No movement cases : All Fup closed, app status = PS and more than three days since last fup received date
    date_considered = datetime.datetime.now() - datetime.timedelta(days=3)
    appids4 = Application.objects.filter(applicationcallattribute__is_fup_closed=True,
                                         applicationcallattribute__last_fup_received_on__lt=date_considered,
                                         applicationcallattribute__app_status='PS')
    ex4 = appids4.count()

    # For ex5: FUPs not raised within 48 hrs
    date_considered = datetime.datetime.now() - datetime.timedelta(days=2)
    appids5 = Application.objects.filter(fup_associated__isnull=True, created_on__lt=date_ylimit)
    ex5 = appids5.count()

    # For ex6: Barred Transaction Report
    # date_considered = datetime.datetime.now() - datetime.timedelta(days = 2)
    appids6 = Application.objects.filter(applicationcallattribute__call_barred=True)
    ex6 = appids6.count()

    # For ex7: FUP not created
    cur = connection.cursor()
    query2 = """select emerge.core_application.app_id,
    emerge.core_application.created_on
    from emerge.core_application where emerge.core_application.id not in
    (select emerge.core_application_fup_associated.application_id from emerge.core_application_fup_associated);
    """
    cur.execute(query2)
    appids7 = cur.fetchall()
    ex7 = cur.rowcount

    if download_id:
        data_row_list = []
        down_list = ''
        down_list1 = ''
        if download_id == 1:
            down_list = appids1
            filename = "ATS_not_created.xls"
        elif download_id == 2:
            down_list = appids2
            filename = "Document_beyond_TAT.xls"
        elif download_id == 3:
            down_list = appids3
            filename = "Medical_beyond_TAT.xls"
        elif download_id == 4:
            down_list = appids4
            filename = "No_movement_cases.xls"
        elif download_id == 5:
            down_list = appids5
            filename = "Underwriting_not_raised.xls"
        elif download_id == 6:
            down_list = appids6
            filename = "Barred_transaction_report.xls"
        elif download_id == 7:
            down_list1 = appids7
            for i in down_list1:
                data_row_list.append(i)
            order = ['Application ID', 'Emerge Created On']
            filename = "Underwriting_not_initiated.xls"
            return utils.render_excel(filename, order, data_row_list)
        else:
            HttpResponseRedirect("manager/app-exception-report/")
        # print len(down_list)
        # print len(down_list1)
        # print len(down_list2)

        for app in down_list:
            a = app.applicationcallattribute

            if User.objects.filter(id=a.assigned_to_id):
                assigned_to = User.objects.filter(id=a.assigned_to_id)[0].username
            else:
                assigned_to = ''
            ch = CallHistory.objects.filter(application=a.application).order_by('-created_on')
            if ch:
                disposition = ch[0].disposition
                remarks = ch[0].remarks
                predefined_remark = ch[0].predefined_remark
                created_on = ch[0].created_on
            else:
                disposition = ''
                remarks = ''
                predefined_remark = ''
                created_on = ''
            if a.call_barred == False:
                callbarred = 'False'
            else:
                callbarred = 'True'
            temp_tuple = (
            a.application.app_id, a.application.app_status, a.application.first_name, a.application.last_name,
            a.document_delivery_method, a.address1, a.courier_date, a.courier_time, a.fup_commited_date,
            a.document_commited_date, a.application.mobile, a.application.email, a.application.stdcode,
            a.application.landline, a.next_calltime.strftime("%D %H:%M"), a.last_call_status,
            a.application.fup_associated.all().count(), a.document_delivery_method, callbarred, assigned_to,
            disposition, remarks, predefined_remark, created_on)
            data_row_list.append(temp_tuple)

        order = ['app_id', 'app_status', 'first_name', 'last_name', 'document_delivery_method', 'address1',
                 'courier_date', 'courier_time', 'fup_commited_date', 'document_commited_date', 'mobile', 'email',
                 'stdcode', 'landline', 'next_calltime', 'last_call_status', 'fup_associated',
                 'document_delivery_method', 'call_barred', 'assigned_to', 'disposition', 'remarks',
                 'predefined_remark', 'created_on']
        # filename = "exception_report_%s.xls"%(download_id)
        # print filename
        return utils.render_excel(filename, order, data_row_list)

    return render_to_response('core/report_exception.html',
                              {
                                  'ex1': ex1,
                                  'ex2': ex2,
                                  'ex3': ex3,
                                  'ex4': ex4,
                                  'ex5': ex5,
                                  'ex6': ex6,
                                  'ex7': ex7,
                              }, context_instance=RequestContext(request))




@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def callstatus_report(request, from_time, to_time):


    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d"))) + datetime.timedelta(days = 1)

    data_row_list = []
    #for a in Application.objects.filter(online_created_date__gte=from_time, online_created_date__lt=to_time).order_by('applicationcallattribute__next_calltime'):
    for a in Application.objects.filter(online_created_date__gte=from_time, online_created_date__lt=to_time):    
        try:

            if User.objects.filter(id=a.applicationcallattribute.assigned_to_id):
                assigned_to = User.objects.filter(id=a.applicationcallattribute.assigned_to_id)[0].username
            else:
                assigned_to = ''
            ch = CallHistory.objects.filter(application=a).order_by('-created_on')[:4]
            callh = []
            if ch:
                for c in ch:
                    call_type = c.get_call_type_display()
                    assigned_by = c.assigned_to
                    call_made_on = c.created_on
                    disposition = c.disposition
                    remarks = c.remarks
                    predefined_remark = c.get_predefined_remark_display()
                    callh.extend([call_type, call_made_on, assigned_to, disposition, remarks, predefined_remark])
            else:
                call_made_on = ''
                disposition = ''

                remarks = ''
                predefined_remark = ''
            try:
                temp_tuple = [getattr(a, f.name) for f in a._meta.fields]
            except:

                temp_tuple = []

            try:
                temp_tuple.extend([
                        a.applicationcallattribute.photo_id_proof_rcvd,
                        a.applicationcallattribute.photo_id_proof_rcvd_date,
                        a.applicationcallattribute.age_proof_rcvd,
                        a.applicationcallattribute.age_proof_rcvd_date,
                        a.applicationcallattribute.address_proof_rcvd,
                        a.applicationcallattribute.address_proof_rcvd_date,
                        a.applicationcallattribute.income_proof_rcvd,
                        a.applicationcallattribute.income_proof_rcvd_date,
                        a.applicationcallattribute.attested_photograph_rcvd,
                        a.applicationcallattribute.attested_photograph_rcvd_date,
                        a.applicationcallattribute.document_delivery_method_used,
                        a.applicationcallattribute.next_calltime.strftime("%D %H:%M"),
                        a.applicationcallattribute.last_call_status,
                        a.fup_associated.all().count(),
                        a.applicationcallattribute.call_barred
                        ])
                temp_tuple.extend(callh)
                data_row_list.append(temp_tuple)
            except:
                print "Application call attr data not found"
             
        except:
            print "Not Assigned"

    try:
        order = [f.name for f in a._meta.fields]
    except:
        print "Application filter has no results.."

    order.extend([
            'photo_id_proof_received',
            'photo_id_proof_received_date',
            'age_proof_received',
            'age_proof_received_date',
            'address_proof_received',
            'address_proof_received_date',
            'income_proof_received',
            'income_proof_received_date',
            'attested_photograph_received',
            'attested_photograph_received_date',
            'document_delivery_method_used',
            'next_calltime',
            'last_call_status',
            'fup_associated',
            'call_barred',
            ])

    call_opts = ['call_type', 'call_made_on', 'assigned_to', 'disposition', 'remarks', 'predefined_remark']
    order.extend(["%s-%s" % (str(i), co) for i in range(1,4) for co in call_opts])
    #6733
    order = order[0:200] + order[233:]
    data_row_list_3 = []
    for data_row_list_1 in data_row_list:
        data_row_list_2 = data_row_list_1[0:200] + data_row_list_1[233:]
        data_row_list_3.append(data_row_list_2)
        #6733 end here
        filename = "callstatus_%s_to_%s.xls"%(from_time,to_time)
        #print filename
        return utils.render_excel(filename, order, data_row_list_3)


                

@login_required
@utils.profile_type_only("MANAGER", "REPORT", "UPLOAD")
def reconcile_psm(request, from_time, to_time):
    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d"))) + datetime.timedelta(days=1)
    apps = Application.objects.filter(transaction_end_time__gte=from_time, transaction_end_time__lt=to_time)
    iutils.reconcile_with_psm(apps)
    return HttpResponseRedirect('/')


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "UPLOAD")
def reconcile_psm_daterange(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect("/manager/reconcile-psm/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def document_data_select_daterange(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect(
                "/manager/downloads/document-data-report/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def call_status_select_daterange(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            return HttpResponseRedirect("/manager/downloads/call-status-report/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def telecaller_sms_dump(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            data = []
            for s in ActionHistory.objects.filter(source='CALLCENTER',
                                                  created_on__gte=form.cleaned_data['start_date'],
                                                  created_on__lte=form.cleaned_data['end_date']):
                ch = CallHistory.objects.get(id=s.source_id)
                data.append(
                    [ch.assigned_to.first_name, ch.application.app_id, s.mobile_to, s.created_on.strftime("%d-%m-%Y"),
                     s.message])
            resp = utils.render_excel("Telecaller_SMS_Report_%s_to_%s.xls" % (
            form.cleaned_data['start_date'].strftime("%d-%m-%Y"), form.cleaned_data['end_date'].strftime("%d-%m-%Y")),
                                      ['Agent Name', 'Application ID', 'Mobile To', 'Sent On', 'Message'], data)
            return resp
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html',
                              {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "COURIER", "COURIER_REP")
def courier_sms_dump(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            data = []
            for s in ActionHistory.objects.filter(source='COURIER',
                                                  created_on__gte=form.cleaned_data['start_date'],
                                                  created_on__lte=form.cleaned_data['end_date']):
                data.append([s.application.app_id, s.mobile_to, s.created_on.strftime("%d-%m-%Y"), s.message])
            resp = utils.render_excel("Telecaller_SMS_Report_%s_to_%s.xls" % (
            form.cleaned_data['start_date'].strftime("%d-%m-%Y"), form.cleaned_data['end_date'].strftime("%d-%m-%Y")),
                                      ['Application ID', 'Mobile To', 'Sent On', 'Message'], data)
            return resp
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html',
                              {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "COURIER", "COURIER_REP")
def document_data_report(request, from_time, to_time):
    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d"))) + datetime.timedelta(days=1)

    data_row_list = []
    for a in ApplicationCallAttribute.objects.filter(application__transaction_end_time__gte=from_time,
                                                     application__transaction_end_time__lt=to_time):
        cds = CourierData.objects.filter(application=a.application)
        if cds:
            cd = cds[0]
            call_id1 = cd.call_id1
            call_id2 = cd.call_id2
            call_id3 = cd.call_id3
            call_category = cd.call_category
            remark = cd.remarks
        else:
            call_id1 = ''
            call_id2 = ''
            call_id3 = ''
            call_category = ''
            remark = ''
        verbose_status = iutils.get_verbose_status(a.application)
        sms_history = ActionHistory.objects.filter(application=a.application, source='COURIER')
        if sms_history:
            sms = list(sms_history)[-1]
            disposition = sms.action_type
            sms_status = "Yes"
        else:
            disposition = ''
            sms_status = "No"
        l = []
        if a.photo_id_proof_rcvd_date: l.append(a.photo_id_proof_rcvd_date)
        if a.income_proof_rcvd_date: l.append(a.income_proof_rcvd_date)
        if a.age_proof_rcvd_date: l.append(a.age_proof_rcvd_date)
        if a.address_proof_rcvd_date: l.append(a.address_proof_rcvd_date)
        if a.attested_photograph_rcvd_date: l.append(a.attested_photograph_rcvd_date)
        if l:
            l.sort()
            date_of_received = l[-1]
        else:
            date_of_received = ''
        temp_tuple = (
        call_id1, call_id2, call_id3, a.document_delivery_method_used, call_category, a.application.app_id,
        a.application.mobile, a.application.app_status, a.get_photo_id_proof_rcvd_display(),
        a.get_age_proof_rcvd_display(), a.get_address_proof_rcvd_display(), a.get_income_proof_rcvd_display(),
        a.attested_photograph_rcvd, a.application.transaction_end_time, a.application.proposal_acceptance_date,
        date_of_received, remark, a.application.product_code, disposition, sms_status)
        data_row_list.append(temp_tuple)

    order = ['Call Id1', 'Call Id2', 'Call Id3', 'Document Delivery Method', 'Call Category', 'Application Number',
             'Mobile', 'Application Status', 'Photo Id Proof', 'Age Proof', 'Address Proof', 'Income Proof',
             'Attested Photograph', 'Payment Date', 'Proposal Acceptance Date', 'Date Of Received', 'Remark', 'Product',
             'Disposition', 'SMS Status']
    filename = "document_data_report.xls"
    # print filename
    return utils.render_excel(filename, order, data_row_list)


@login_required
@utils.profile_type_only("MANAGER", "CALLCENTER", "REVIEWER", "COURIER", "COURIER_REP")
def search(request):
    """ with the application number rerdirects to url according to the user profile """
    if request.POST:
        search_form = SearchForm(request.POST)
        if search_form.is_valid():
            app_id = search_form.cleaned_data.get('app_id')
            application = Application.objects.filter(app_id=app_id)
            if len(list(application)) == 1:
                if request.user.userprofile.role == 'COURIER':
                    return HttpResponseRedirect("/courier-status/%s" % (application[0].app_id))
                if request.user.userprofile.role == 'COURIER_REP':
                    return HttpResponseRedirect("/courier-status/%s" % (application[0].app_id))
                elif request.user.userprofile.role == 'REVIEWER' or request.user.userprofile.role == 'MANAGER':
                    return HttpResponseRedirect("/single-screen/%s" % (application[0].app_id))
                elif request.user.userprofile.role == 'NEW_TELECALLER':
                    return HttpResponseRedirect("/single-screen/%s" % (application[0].app_id))
                else:
                    return HttpResponseRedirect("/doc-status/%s" % (application[0].app_id))
            else:
                msg = 'There are no applications matching this code'
                return render_to_response("core/search.html",
                                          {
                                              'msg': msg,
                                              'search_form': search_form,
                                          },
                                          context_instance=RequestContext(request)
                                          )
        else:
            print search_form.errors
            msg = ''
    else:
        msg = ''
        search_form = SearchForm()

    return render_to_response("core/search.html",
                              {
                                  'msg': msg,
                                  'search_form': search_form,
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "COURIER", "COURIER_REP")
def courier_status(request, app_id):
    ac = ApplicationCallAttribute.objects.get(application__app_id=app_id)
    # TODO: Change this to one to one
    cds = CourierData.objects.filter(application=ac.application)
    if cds:
        cd = cds[0]
    else:
        cd = ''
    if request.POST:
        docs_form = DocsForm(request.POST)
        if docs_form.is_valid():
            update_ac, cd = docs_form.save(ac)
            return HttpResponseRedirect("/search/")
        else:
            error_msgs = docs_form.errors
            print docs_form.errors
    else:
        error_msgs = ''
        if cd:
            # docs_form = DocsForm(initial={'document_delivery_method_used':ac.document_delivery_method_used, 'photo_id_proof_rcvd':ac.photo_id_proof_rcvd, 'age_proof_rcvd':ac.age_proof_rcvd, 'address_proof_rcvd':ac.address_proof_rcvd, 'income_proof_rcvd':ac.income_proof_rcvd, 'attested_photograph_rcvd':ac.attested_photograph_rcvd, 'remarks':cd.remarks,'call_category':cd.call_category,'call_id1':cd.call_id1,'call_id2':cd.call_id2,'call_id3':cd.call_id3, 'airway_bill_no':ac.airway_bill_no, 'courier_company_name':ac.courier_company_name})
            docs_form = DocsForm(
                initial={'remarks': cd.remarks, 'call_category': cd.call_category, 'call_id1': cd.call_id1,
                         'call_id2': cd.call_id2, 'call_id3': cd.call_id3, 'airway_bill_no': ac.airway_bill_no,
                         'courier_company_name': ac.courier_company_name})
        else:
            docs_form = DocsForm()
    sms_form = CourierSMSForm()
    return render_to_response("core/courier_status.html",
                              {
                                  'ac': ac,
                                  'cd': cd,
                                  'docs_form': docs_form,
                                  'sms_form': sms_form,
                                  'error_msgs': error_msgs,
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "REVIEWER", "CALLCENTER")
def doc_status(request, app_id):
    app = Application.objects.get(app_id=app_id)
    app_callattr = app.applicationcallattribute
    call_history_list = CallHistory.objects.filter(application__app_id=app_id).order_by('-created_on')
    nonmedical_fups = app.fup_associated.filter(code__is_medical=False).exclude(
        code__name__in=['CWA', 'RQ042']).order_by('received_on')
    medical_fups = app.fup_associated.filter(code__is_medical=True).order_by('received_on')
    sms_history = ActionHistory.objects.filter(application=app, action_type='sms')
    email_history = ActionHistory.objects.filter(application=app, action_type='email')

    photo_date = ''
    age_date = ''
    address_date = ''
    income_date = ''
    if app.photo_id_proof_rcvd_date:
        try:
            photo_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
        except:
             # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
            
            try:
                photo_date = datetime.datetime.strftime(datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y'),
                                                        '%d/%m/%Y %H:%M:%S')
            except:
                photo_date = app.photo_id_proof_rcvd_date


    if app.address_proof_rcvd_date:
        try:
            address_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')

        # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
        except:
            try:
                
                address_date = datetime.datetime.strftime(datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y'),
                                                          '%d/%m/%Y %H:%M:%S')
            except:
                address_date = app.address_proof_rcvd_date

    if app.age_proof_rcvd_date:
        try:
            age_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
    
        # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
        except:
            try:
                age_date = datetime.datetime.strftime(datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y'),
                                                      '%d/%m/%Y %H:%M:%S')
            except:
                age_date =  app.age_proof_rcvd_date
    if app.income_proof_rcvd_date:
        try:
            income_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')

        # added in try catch block to remove date field error on front end - May 2017 - 179 pbz
        except:
            try:
                
                income_date = datetime.datetime.strftime(datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y'),'%d/%m/%Y %H:%M:%S')
            except:
                income_date = app.income_proof_rcvd_date
    # 6733 insurer data ondoc status page
    try:
        ins_doc = InsurerApplication.objects.get(ins_application =app)
    except:
        ins_doc = None
        print "insurer not found in doc status html page" 
    
    
    return render_to_response("core/doc_status.html",
                              {
                                  'app_callattr': app_callattr,
                                  'app': app,
                                  'nonmedical_fups': nonmedical_fups,
                                  'medical_fups': medical_fups,
                                  'call_history_list': call_history_list,
                                  'photo_date': photo_date,
                                  'age_date': age_date,
                                  'address_date': address_date,
                                  'income_date': income_date,
                                  'sms_history': sms_history,
                                  'email_history': email_history,
                                  'ins_call': ins_doc,           # 6733
                                  'product_name': app.product_name,
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT", "REVIEWER")
def single_screen(request, app_id):
    #    response = HttpResponse()
    app = Application.objects.get(app_id=app_id)
    app_callattr = app.applicationcallattribute
    call_history_list = CallHistory.objects.filter(application__app_id=app_id).order_by('-created_on')
    nonmedical_fups = app.fup_associated.filter(code__is_medical=False).exclude(
        code__name__in=['CWA', 'RQ042']).order_by('received_on')
    medical_fups = app.fup_associated.filter(code__is_medical=True).order_by('received_on')
    sms_history = ActionHistory.objects.filter(application=app, action_type='sms')
    email_history = ActionHistory.objects.filter(application=app, action_type='email')
    alluhc = UHCData.objects.filter(application=app)
    if alluhc:
        uhc = alluhc[0]
    else:
        uhc = ''
    verbose_status = iutils.get_verbose_status(app)
    photo_id_date = ''
    age_date = ''
    address_date = ''
    income_date = ''

    if app.photo_id_proof_rcvd_date:
        print "PHOTO DATE______________", app.photo_id_proof_rcvd_date
        try:
            photo_id_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
        except:
            photo_id_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.photo_id_proof_rcvd_date, '%m%d%Y'), '%d/%m/%Y %H:%M:%S')
    if app.address_proof_rcvd_date:
        try:
            address_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
        except:
            address_date = datetime.datetime.strftime(datetime.datetime.strptime(app.address_proof_rcvd_date, '%m%d%Y'),
                                                      '%d/%m/%Y %H:%M:%S')
    if app.age_proof_rcvd_date:
        try:
            age_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
        except:
            age_date = datetime.datetime.strftime(datetime.datetime.strptime(app.age_proof_rcvd_date, '%m%d%Y'),
                                                  '%d/%m/%Y %H:%M:%S')
    if app.income_proof_rcvd_date:
        try:
            income_date = datetime.datetime.strftime(
                datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y %H:%M:%S'), '%d/%m/%Y %H:%M:%S')
        except:
            income_date = datetime.datetime.strftime(datetime.datetime.strptime(app.income_proof_rcvd_date, '%m%d%Y'),
                                                     '%d/%m/%Y %H:%M:%S')
    
    # insurer added on manager single screen  6733
    #6733
    try:
        ins_single = InsurerApplication.objects.get(ins_application =app)
    except:
        ins_single = None
        print "insurer not found on single screen" 
    
    return render_to_response("core/single_screen.html",
                              {
                                  'app_callattr': app_callattr,
                                  'app': app,
                                  'nonmedical_fups': nonmedical_fups,
                                  'medical_fups': medical_fups,
                                  'call_history_list': call_history_list,
                                  'sms_history': sms_history,
                                  'email_history': email_history,
                                  'uhc': uhc,
                                  'verbose_status': verbose_status,
                                  'alluhc': alluhc,
                                  'photo_id_date': photo_id_date,
                                  'age_date': age_date,
                                  'address_date': address_date,
                                  'income_date': income_date,
                                  'ins_call': ins_single,          # 6733
                                  'product_name': app.product_name  #6733

                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_transaction_report(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect("/manager/app-transaction-report/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_barred_transaction_report(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect(
                "/manager/app-transaction-report/from/%s/to/%s/?showbarred=1" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def app_transaction_data(request, from_time, to_time):
    showbarred = int(request.GET.get('showbarred', 0))
    if showbarred == 1:
        title = "Barred Transaction Report"
    else:
        title = "Application Transaction Report"
    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d"))) + datetime.timedelta(days=1)

    apps = Application.objects.filter(online_created_date__gte=from_time, online_created_date__lt=to_time).order_by(
        'online_created_date')
    datewise = utils.group_by(apps, 'online_created_date', 'date')
    skey = []
    lcswise = {}
    lcstemp = {}
    app_call = {}
    if apps:
        for k, v in datewise.items():
            for app in v:
                if not app_call.get(k): app_call[k] = []
                if not showbarred:
                    if app.applicationcallattribute.call_barred == False:
                        app_call[k].append(app.applicationcallattribute)
                else:
                    if app.applicationcallattribute.call_barred == True:
                        app_call[k].append(app.applicationcallattribute)
            lcstemp[k] = utils.group_by(app_call[k], 'last_call_status')
            lcs = {}
            if lcstemp[k]:
                for kk, vv in lcstemp[k].items():
                    lcs[kk] = len(vv)
            lcswise[k] = lcs
    overall_total = {'F': 0, 'W': 0, 'WV': 0, 'V': 0, 'R': 0, 'TF': 0}
    call_barred = {}
    for key in sorted(lcswise.iterkeys()):
        skey.append(key)
        overall_total['F'] = overall_total['F'] + lcswise[key].get('F', 0)
        overall_total['W'] = overall_total['W'] + lcswise[key].get('W', 0)
        overall_total['WV'] = overall_total['WV'] + lcswise[key].get('WV', 0)
        overall_total['V'] = overall_total['V'] + lcswise[key].get('V', 0)
        overall_total['R'] = overall_total['R'] + lcswise[key].get('R', 0)
        overall_total['TF'] = overall_total['TF'] + lcswise[key].get('TF', 0)

    return render_to_response('core/report_app_transaction.html',
                              {
                                  'lcswise': lcswise,
                                  'skey': skey,
                                  'overall_total': overall_total,
                                  'title': title,
                              }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def telecaller_productivity_report(request):
    if request.method == 'POST':
        form = ReportFiltersForm(request.POST)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            start_date = sd.strftime("%Y-%m-%d")
            end_date = ed.strftime("%Y-%m-%d")
            print "start date: %s end date: %s" % (start_date, end_date)
            return HttpResponseRedirect("/manager/telecaller-productivity-data/from/%s/to/%s/" % (start_date, end_date))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form': form, 'error_msg': error_msg},
                              context_instance=RequestContext(request))


@login_required
@utils.profile_type_only("MANAGER", "REPORT")
def telecaller_productivity_data(request, from_time, to_time):
    from_time = datetime.datetime.fromtimestamp(mktime(time.strptime(from_time, "%Y-%m-%d")))
    to_time = datetime.datetime.fromtimestamp(mktime(time.strptime(to_time, "%Y-%m-%d"))) + datetime.timedelta(days=1)

    applications_for_the_day = ApplicationCallAttribute.objects.filter(
        next_calltime__lte=datetime.datetime.combine(datetime.date.today(), datetime.time.max), call_barred=False)
    calls_made = CallHistory.objects.filter(created_on__gte=from_time, created_on__lt=to_time)
    bucket = {}
    disp_list = ['SUCCESS', 'CALLBACK', 'RINGING', 'BUSY', 'CALL_DROPPED', 'UNREACHABLE', 'DO_NOT_CALL']
    for cm in calls_made:
        # if cm.disposition:
        #   if cm.disposition not in disp_list: disp_list.append(cm.disposition)
        at = cm.assigned_to
        disposition = cm.disposition
        if at in bucket.keys():
            if disposition != '':
                bucket[at]['total'] += 1
                if disposition in bucket[at].keys():
                    bucket[at][disposition] += 1
                else:
                    bucket[at][disposition] = 1
        else:
            bucket[at] = {disposition: 0, 'total': 0}
    for d in disp_list:
        for k, v in bucket.items():
            if d not in v.keys():
                v[d] = 0
    return render_to_response('core/report_telecaller_productivity.html',
                              {
                                  'disp_list': disp_list,
                                  'bucket': bucket,
                              }, context_instance=RequestContext(request)
                              )


def application_tracker(request):
    delcookie = request.GET.get('delcookie', 0)
    if delcookie:
        response = HttpResponseRedirect("/application-tracker/")
        response.delete_cookie("application_id")
        return response

    application_exists_flag = True
    if "application_id" not in request.COOKIES:
        application_exists_flag = False
        app = []
        medical_fups = []
        document_fups = []
        fups = []
        verbose_status = None
        if request.POST:
            search_form = SearchForm(request.POST)
            if search_form.is_valid():
                app_id = search_form.cleaned_data.get('app_id')
                application = Application.objects.filter(app_id=app_id)
                if len(list(application)) == 1:
                    response = HttpResponseRedirect("/application-tracker/")
                    response.set_cookie("application_id", app_id, max_age=365 * 24 * 60 * 60,
                                        expires=365 * 24 * 60 * 60)
                    return response
                else:
                    msg = 'There are no applications matching this code'
            else:
                print search_form.errors
                msg = ''
        else:
            msg = ''
            search_form = SearchForm()
    else:
        msg = ''
        search_form = SearchForm()
        app_id = request.COOKIES["application_id"]
        app = Application.objects.get(app_id=app_id)
        if app.app_status in ['PO', 'WD', 'FL', 'DC', 'IF', 'XX', 'RJ'] and (
            datetime.date.today() - app.proposal_acceptance_date).days > 4:
            return render_to_response("core/application-tracker-expired.html",
                                      {
                                      },
                                      context_instance=RequestContext(request)
                                      )

        verbose_status = iutils.get_verbose_status(app)
        fups = app.fup_associated.all()
        if fups:
            medical_fups = [f for f in fups if f.code.is_medical]
            document_fups = [f for f in fups if not f.code.is_medical and f.code.name not in INTERNAL_FUP_LIST]
        else:
            medical_fups = []
            document_fups = []
    return render_to_response("core/application-tracker.html",
                              {
                                  'msg': msg,
                                  'search_form': search_form,
                                  'app': app,
                                  'medical_fups': medical_fups,
                                  'document_fups': document_fups,
                                  'fups': fups,
                                  'application_exists_flag': application_exists_flag,
                                  'verbose_status': verbose_status,
                              },
                              context_instance=RequestContext(request)
                              )


@csrf_exempt
def write_to_excel(request):
    jdict = simplejson.loads(request.POST['data'])
    print "write to excel"
    # data = simplejson.loads('[["Month","Sourced","Issued","Gross Issued%","Closed","Closed%","OTI","OTI%"],["August, 2010","222.0 ","1016.0 ","457.66 ","1396.0 ","628.83 ","58.0 ","26.13 "],["September, 2010","1078.0 ","969.0 ","89.89 ","1276.0 ","118.37 ","236.0 ","21.89 "],["October, 2010","1068.0 ","818.0 ","76.59 ","1023.0 ","95.79 ","707.0 ","66.20 "],["November, 2010","966.0 ","84.0 ","8.70 ","142.0 ","14.70 ","663.0 ","68.63 "],["December, 2010","18.0 ","121.0 ","672.22 ","222.0 ","1233.33 ","1.0 ","5.56 "],["February, 2011","1454.0 ","590.0 ","40.58 ","1078.0 ","74.14 ","1.0 ","0.07 "],["March, 2011","1512.0 ","675.0 ","44.64 ","1067.0 ","70.57 ","0.0 ","0.00 "],["April, 2011","1730.0 ","616.0 ","35.61 ","965.0 ","55.78 ","0.0 ","0.00 "],["May, 2011","805.0 ","10.0 ","1.24 ","18.0 ","2.24 ","0.0 ","0.00 "],["Overall","8853","4899","55.34","7187","81.18","1666","18.82"]]')
    filename = "report.xls"
    # col_title_list = data[0]
    # render_excel_to_file(filename,col_title_list , data[1:])
    response = utils.render_custom_excel_to_file(filename, jdict)
    return response


@csrf_exempt
def send_sms_view(request, app_id, message_code):
    if request.POST:
        data = simplejson.loads(request.POST['data'])
    else:
        data = None
    try:
        resp = iutils.send_customer_sms(app_id, message_code, data)
    except Exception, e:
        resp = str(e)
        return HttpResponse("error:" + resp)
    return HttpResponse("OK")


# 6109
@never_cache
@login_required
@csrf_exempt
@utils.profile_type_only("MANAGER")
def user_sessions(request):
    cur = connection.cursor()
    uname = User.objects.filter(userprofile__role__in=('CALLCENTER', 'UHC', 'UHCREPORT', 'MANAGER'), is_active=True)
    # uname = User.objects.filter(is_active=True)

    form = request.POST

    if request.method == 'POST':
        try:
            username = get_object_or_404(User, pk=request.POST.get('username'))
            u_name = username.username
            query1 = "select emerge.auth_user.id from emerge.auth_user where emerge.auth_user.username = '%s';" % (
            u_name)
            cur.execute(query1)
            query1_result = cur.fetchall()
            for i in query1_result:
                query = "delete from emerge.core_usersession where emerge.core_usersession.user_id = %s;" % (i)
                cur.execute(query)
                msg = "Selected user " + u_name + "'s session has been deleted"
                return render_to_response("core/user_session.html",
                                          {
                                              'user_names': uname,
                                              'success': msg,
                                          }, context_instance=RequestContext(request))
        except:
            return HttpResponseRedirect("/manager/user-session/")
    return render_to_response("core/user_session.html",
                              {
                                  'user_names': uname,
                              }, context_instance=RequestContext(request))


@never_cache
@login_required
@utils.profile_type_only("MANAGER")
def reassign_calls(request):
    #    response=HttpResponse()

    user_list = User.objects.filter(userprofile__role='CALLCENTER')
    if request.POST:
        ccrform = CallCenterReassignmentForm(request.POST)
        if ccrform.is_valid():
            if request.POST['original_user'] == "NONE":
                original_user = None
            else:
                original_user = User.objects.get(id=request.POST['original_user'])
            reassign_to = User.objects.get(id=ccrform.cleaned_data['user'])
            transfer = int(ccrform.cleaned_data.get('transfer', '100'))

            if original_user:
                call_type = ccrform.cleaned_data.get('call_type')
            else:
                call_type = 'F'
            if call_type:
                update_ids = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=original_user,
                                                                     last_call_status=call_type).values_list('id',
                                                                                                             flat=True)[
                             :transfer]
                update_count = ApplicationCallAttribute.objects.filter(id__in=list(update_ids)).update(
                    assigned_to=reassign_to)
            else:
                ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=original_user,
                                                        last_call_status=call_type).update(assigned_to=reassign_to)
            return HttpResponseRedirect('/manager/reassign-calls/')
        else:
            print ccrform.errors
    else:
        ccrform = CallCenterReassignmentForm()
    user_apca_count = {}
    user_apca_count_today = {}
    for u in user_list:
        udata = []
        udatatoday = []
        apca_count = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u,
                                                             next_calltime__lte=datetime.datetime.combine(
                                                                 datetime.date.today(), datetime.time.max)).count()
        # apca_count_today = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u,).count()
        udata.append(['Total', apca_count])

        apca_count_today = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u,
                                                                   next_calltime__gte=datetime.datetime.combine(
                                                                       datetime.date.today(), datetime.time.min),
                                                                   next_calltime__lte=datetime.datetime.combine(
                                                                       datetime.date.today(),
                                                                       datetime.time.max)).count()
        udatatoday.append(['Total', apca_count_today])
        for ct in CALL_TYPE:
            ct_count = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u,
                                                               last_call_status=ct[0]).count()
            ct_count_today = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u,
                                                                     last_call_status=ct[0], is_taken=False,
                                                                     next_calltime__gte=datetime.datetime.combine(
                                                                         datetime.date.today(), datetime.time.min),
                                                                     next_calltime__lte=datetime.datetime.combine(
                                                                         datetime.date.today(),
                                                                         datetime.time.max)).count()
            udata.append([ct[1], ct_count])
            udatatoday.append([ct[1], ct_count_today])
        user_apca_count[u] = udata
        user_apca_count_today[u] = udatatoday
    # for u in user_list:
    #     udata = []
    #     udata_today = []
    #     apca_count = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u).count()
    #     apca_count_today = ApplicationCallAttribute.objects.filter(call_barred=False,next_calltime__gte=datetime.datetime.combine(datetime.date.today(), datetime.time.min),next_calltime__lte=datetime.datetime.combine(datetime.date.today(), datetime.time.max),assigned_to=u).count()

    #     udata_today.append(['Total',apca_count_today])
    #     udata.append(['Total',apca_count])
    #     for ct in CALL_TYPE:
    #         ct_count = ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to=u ,last_call_status=ct[0]).count()
    #         ct_count_today = ApplicationCallAttribute.objects.filter(call_barred=False,next_calltime__gte=datetime.datetime.combine(datetime.date.today(), datetime.time.min),next_calltime__lte=datetime.datetime.combine(datetime.date.today(), datetime.time.max), assigned_to=u ,last_call_status=ct[0]).count()
    #         udata.append([ct[1],ct_count])
    #         udata_today.append([ct[1],ct_count])
    #     user_apca_count[u] = udata
    #     user_apca_count_today[u] = udata_today


    user_apca_count['NONE'] = [['UNASSIGNED FRESH',
                                ApplicationCallAttribute.objects.filter(call_barred=False, assigned_to__isnull=True,
                                                                        last_call_status='F').count()]]
    return render_to_response("core/reassign_calls.html",
                              {
                                  'user_apca_count': user_apca_count,
                                  'user_apca_count_today': user_apca_count_today,
                                  'ccrform': ccrform,
                              },
                              context_instance=RequestContext(request)
                              )


class EmergeUpload(Xl2Python):
    def clean_app(self, val):
        return Application.objects.get(app_id=val)


# @never_cache
# @login_required
# @utils.profile_type_only("EMERGE")
# def emerge_upload(request):
#      #model_save_errors = []
#      #saved = 0
#      if request.POST or request.FILES:
#         upload_file = request.FILES['upload_file']
#         upfile = UploadFile(upload_file=upload_file,user=request.user)
#         upfile.save()
#      else:
#         upload_status = "Upload unsucessful"
#         print "ERROR ---->", xlm.errors
#         error = xlm.errors
#      return render_to_response("core/data_upload.html", {
#         'success': 'upload_status', 'time':datetime.datetime.now(),'error':'xyz',
#          }, context_instance=RequestContext(request)
#      )

@never_cache
@login_required
@utils.profile_type_only("EMERGE")
def emerge_upload(request):
    """
    "product","app id","created on","first name","last name","gender","dob","sum assured","annual premium","tracker id","phone number","amount received","payment/transaction date","email","policy status","transaction id"

    SNoApplicationNumberApplicationDateLeadIdProposalNoNameContactNoPageUpdatedDateSAPremiumPlanNameChannelUTMSourceUTMCampaign$$hashKey



    <Status Options>
    Confirmed
    Report pending
    Partial show
    No show
    """
    parse_errors = []
    upload_status = " "
    if request.POST or request.FILES:
        try:
            upload_file = request.FILES['upload_file']
            upfile = UploadFile(upload_file=upload_file, user=request.user)

            upload_file = upfile.upload_file
            print upload_file
            saved = 0
            xl_field_map = {
                '0': 'product',
                '1': 'app_id',
                # '2': ('medicalappointment_date1', 'datetime','%d-%m-%Y'),
                # '3': ('medicalappointment_time1', 'time','%H:%M'),
                '2': 'created_on',
                '3': 'first_name',
                '4': 'last_name',
                '5': 'gender',
                '6': 'dob',
                '7': 'sum_assured',
                '8': 'annual_premium',
                '9': 'tracker_id',
                '10': 'phone_number',
                '11': 'amount_received',
                '12': 'payment_transaction_date',
                '13': 'email',
                '14': 'policy_status',
                '15': 'transaction_id',
                '16': 'occupation',
                '17': 'org_type',
                '18': 'designation',
                '19': 'annual_income',
                '20': 'flat',
                '21': 'building',
                '22': 'road',
                '23': 'city',
                '24': 'pincode',
                '25': 'state',
                '26': 'country'

            }
            '''xl_field_map = {
                '0':'SNo',
                '1':'ApplicationNumber',
                '2':'ApplicationDate',
                '3':'LeadId',
                '4':'ProposalNo',
                '5':'Name',
                '6':'ContactNo',
                '7':'Page',
                '8':'UpdatedDate',
                '9':'SA',
                '10':'Premium',
                '11':'PlanName',
                '12':'Channel',
                '13':'UTMSource',
                '14':'UTMCampaign',
                '15':'$$hashKey'
                }'''

            error = None
            xlm = EmergeUpload(xl_field_map, upload_file.read())
            if xlm.is_valid():
                upload_status = "Upload sucessful"

                # print "DATA -->", xlm.cleaned_data
                if not xlm.cleaned_data:
                    upload_status = "The first column should be filled"
                i = 0

                for d in xlm.cleaned_data:
                    try:
                        i += 1

                        app_id = d['app_id']
                        print "Incoming Application ID:", app_id
                        app = "'" + app_id + "'"
                        app_data, created = Application.objects.get_or_create(app_id=app_id)
                        # print app_data
                        app_data.app_id = d['app_id']
                        if d['created_on']:
                            time_tuple = xlrd.xldate_as_tuple(d['created_on'], 0)
                            d['created_on'] = datetime.datetime(*time_tuple)
                        app_data.created_on = d['created_on']
                        print "created_on:", app_data.created_on
                        app_data.first_name = d['first_name']
                        app_data.last_name = d['last_name']
                        app_data.gender = d['gender']
                        if d['dob']:
                            time_tuple1 = xlrd.xldate_as_tuple(d['dob'], 0)
                            d['dob'] = datetime.datetime(*time_tuple1)

                        app_data.dob = d['dob']
                        app_data.sum_assured = d['sum_assured']
                        app_data.annual_premium = d['annual_premium']
                        app_data.tracker_id = d['tracker_id']
                        app_data.mobile = d['phone_number']
                        app_data.pay_amount = d['amount_received']
                        if d['payment_transaction_date']:
                            time_tuple2 = xlrd.xldate_as_tuple(d['payment_transaction_date'], 0)
                            d['payment_transaction_date'] = datetime.datetime(*time_tuple2)
                        app_data.payment_transaction_date = d['payment_transaction_date']
                        app_data.email = d['email']
                        app_data.policy_status = d['policy_status']
                        app_data.transaction_id = d['transaction_id']
                        print "app_data>>>>>>>>", app_data
                        # added extra field in manaul script for fortune elite plan 12 jan
                        app_data.occupation = d['occupation']
                        app_data.org_type = d['org_type']
                        app_data.designation = d['designation']
                        app_data.annual_income = d['annual_income']
                        app_data.flat = d['flat']
                        app_data.building = d['building']
                        app_data.road = d['road']
                        app_data.city = d['city']
                        app_data.pincode = d['pincode']
                        app_data.state = d['state']
                        app_data.country = d['country']



                        # app_data.product_name = d['product']
                    except Exception as e:
                        print sys.exc_info()
                        print traceback.format_exc()
                        parse_errors.append({'error': sys.exc_info(), 'traceback': traceback.format_exc()})
                    try:
                        # ap = Application(**d)
                        ap = app_data
                        app_data.save()
                        print "Application ID:: ", app_data.id
                        apca, created = ApplicationCallAttribute.objects.get_or_create(application=app_data)
                        if created:
                            apca.last_call_status = 'F'
                            apca.is_taken = False
                        apca.next_calltime = datetime.datetime.now()
                        apca.save()
                        print "App Call ID::", apca.id, " New:: ", created

                        saved += 1
                    except Exception, e:
                        # model_save_errors.append((i,str(e)))
                        print sys.exc_info()
                        print traceback.format_exc()
                        parse_errors.append({'error': sys.exc_info(), 'traceback': traceback.format_exc()})

                print "Items saved:: ", saved
                upload_status = "Uploaded sucessfully!"
            else:
                upload_status = "Upload unsucessful!"
                print "ERROR ---->", xlm.errors
                error = xlm.errors
        except Exception as e:
            print sys.exc_info()
            print traceback.format_exc()
            parse_errors.append({'error': sys.exc_info(), 'traceback': traceback.format_exc()})

        # return render_to_response("core/data_upload.html", {
        # 'success': 'upload_status', 'time':datetime.datetime.now(),'error':'xyz',
        # }, context_instance=RequestContext(request)
        # upload_status = "Uploaded!"
        print "__________ERRORS: ", parse_errors, error
        return render_to_response("core/data_upload.html", {
            'success': upload_status, 'time': datetime.datetime.now(), 'error': error, 'parse_errors': parse_errors
        }, context_instance=RequestContext(request)
                                  )
    else:
        return HttpResponseRedirect('/emerge/dashboard/')


class AffiliateUpload(Xl2Python):
    pass

    def clean_first_call_date(self, val):
        if val:
            return datetime.datetime.combine(val, datetime.time.min)
        return None

    def clean_last_call_date(self, val):
        if val:
            return datetime.datetime.combine(val, datetime.time.min)
        return None


@login_required
@utils.profile_type_only("AFFILIATE")
def upload_affiliate_data(request):
    xlm_errors = None
    model_save_errors = []
    saved = 0
    if request.FILES and request.FILES.get('upload_file'):
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, user=request.user)
        upfile.save()
        file_contents = upfile.upload_file.read()
        xlm = AffiliateUpload(sales_claim_map, file_contents)
        if xlm.is_valid():
            print xlm.cleaned_data
            i = 0
            for data in xlm.cleaned_data:
                i += 1
                data['match_status'] = 'FREE_CLAIM'
                data['user'] = request.user
                data['organization'] = request.user.userprofile.organization
                try:
                    sc = SaleClaim(**data)
                    sc.save()
                    saved += 1
                except Exception, e:
                    model_save_errors.append((i, str(e)))
        else:
            xlm_errors = xlm.errors
            print xlm.cleaned_data
            print xlm.errors
        upfile.output = simplejson.dumps({'file': xlm.errors, 'model': model_save_errors, 'saved': saved})
        upfile.is_processed = True
        upfile.save()
    else:
        upload_form = UploadForm()

    print "OVER IT IS "
    iutils.reconcile_sales_claim()
    return render_to_response("core/affiliate_uploads.html", {
        'xlm_errors': xlm_errors,
        'model_save_errors': model_save_errors,
        'saved': saved,
    }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE")
def affiliate_upload_list(request):
    uploads = UploadFile.objects.filter(user=request.user)
    return render_to_response("core/affiliate_uploads_list.html", {
        'uploads': uploads,
    }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE")
def affiliate_upload_history(request, upid):
    up = UploadFile.objects.get(id=upid, user=request.user)
    obj = simplejson.loads(up.output)
    return render_to_response("core/affiliate_uploads_history.html", {
        'up': up,
        'xlm_errors': obj.get('file'),
        'model_save_errors': obj.get('model'),
        'saved': obj.get('saved'),
    }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE")
def affiliate_report(request):
    scs = []
    if request.GET:
        form = ReportFiltersForm(request.GET)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            scs = SaleClaim.objects.filter(
                user=request.user,
                created_on__gte=datetime.datetime.combine(sd, datetime.time.min),
                created_on__lte=datetime.datetime.combine(ed, datetime.time.max),
            )
    else:
        form = ReportFiltersForm()
    return render_to_response("core/affiliate_report.html", {
        'scs': scs,
        'form': form,
    }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_admin_report(request):
    scs = []
    if request.GET:
        form = ReportFiltersForm(request.GET)
        if form.is_valid():
            sd = form.cleaned_data['start_date']
            ed = form.cleaned_data['end_date']
            scs = SaleClaim.objects.filter(
                created_on__gte=datetime.datetime.combine(sd, datetime.time.min),
                created_on__lte=datetime.datetime.combine(ed, datetime.time.max),
            )
    else:
        form = ReportFiltersForm()
    return render_to_response("core/affiliate_admin_report.html", {
        'scs': scs,
        'form': form,
    }, context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_edit(request, uid):
    u = User.objects.get(id=uid)
    if request.POST:
        call_center_userform = UserForm(uid, "AFFILIATE", request.POST)
        if call_center_userform.is_valid():
            call_center_userform.save()
            return HttpResponseRedirect('/affiliate-admin/manage-affiliate/')
        else:
            print call_center_userform.errors
    else:
        call_center_userform = UserForm(uid, "AFFILIATE",
                                        initial={'first_name': u.first_name, 'last_name': u.last_name})
    return render_to_response("core/affiliate-add.html",
                              {
                                  'ccuform': call_center_userform,
                                  'uid': uid,
                              },
                              context_instance=RequestContext(request)
                              )
    return render_to_response("core/affiliate-add.html",
                              {
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_add(request):
    if request.POST:
        call_center_userform = UserForm(None, "AFFILIATE", request.POST)
        if call_center_userform.is_valid():
            call_center_userform.save()
            return HttpResponseRedirect('/affiliate-admin/manage-affiliate/')
        else:
            print call_center_userform.errors
    else:
        call_center_userform = UserForm(None, "AFFILIATE")
    return render_to_response("core/affiliate-add.html",
                              {
                                  'ccuform': call_center_userform,
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_manage(request):
    user_list = User.objects.filter(userprofile__role='AFFILIATE')
    return render_to_response("core/affiliate-manage.html",
                              {
                                  'user_list': user_list
                              },
                              context_instance=RequestContext(request)
                              )


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_disable(request, uid):
    u = User.objects.get(id=uid)
    u.is_active = False
    u.save()
    return HttpResponseRedirect('/affiliate-admin/manage-affiliate/')


@login_required
@utils.profile_type_only("AFFILIATE_ADMIN")
def affiliate_enable(request, uid):
    u = User.objects.get(id=uid)
    u.is_active = True
    u.save()
    return HttpResponseRedirect('/affiliate-admin/manage-affiliate/')


def call_time_report(request):
    #    response = HttpResponse()
    cur = connection.cursor()
    from_date = request.GET['from_date'] + " " + "00:00:00"
    to_date = request.GET['to_date'] + " " + "23:59:59"

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Emerge_Call_Report_%s.csv"' % (
    datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)

    report_query = "select distinct emerge.core_application.first_name,emerge.core_application.last_name,app_id,emerge.core_callhistory.disposition,call_type,next_calltime,emerge.core_callhistory.created_on,emerge.core_application.mobile,emerge.core_application.medicalappointment_center1,emerge.core_application.medicalappointment_location1,emerge.core_application.medicalappointment_city1,emerge.core_application.medicalappointment_center2,emerge.core_application.medicalappointment_location2,emerge.core_application.medicalappointment_city2,emerge.core_application.photo_id_proof_rcvd,emerge.core_application.address_proof_rcvd,emerge.core_application.age_proof_rcvd,emerge.core_application.income_proof_rcvd,emerge.core_application.photo_id_proof_rcvd_date,emerge.core_application.address_proof_rcvd_date,emerge.core_application.age_proof_rcvd_date,emerge.core_application.income_proof_rcvd_date,emerge.core_application.uhci_update_time,emerge.core_application.online_created_date, emerge.core_callhistory.aspectcall_start_date,emerge.core_callhistory.aspectcall_end_date,emerge.core_callhistory.aspectcall_duration,emerge.core_callhistory.aspectcall_dialflag,emerge.auth_user.username from emerge.core_application,emerge.core_callhistory,emerge.auth_user where emerge.core_application.id = emerge.core_callhistory.application_id and emerge.core_callhistory.assigned_to_id = emerge.auth_user.id and emerge.core_callhistory.created_on between '%s' and '%s'; " % (
    from_date, to_date)  # 6109

    cur.execute(report_query)
    query_result = cur.fetchall()
    row_count = cur.rowcount
    srno = 1
    if query_result:
        for i in query_result:
            '''emerge.core_application.photo_id_proof_rcvd_date,emerge.core_application.address_proof_rcvd_date,emerge.core_application.age_proof_rcvd_date,emerge.core_application.income_proof_rcvd_date
datetime.datetime.strptime(ndata['appointee_dob'], '%d%m%Y')'''
            id_date = ''
            address_date = ''
            age_date = ''
            income_date = ''

            if i[18]:
                try:
                    id_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[18]), '%m%d%Y %H:%M:%S'),
                                                         '%d/%m/%Y %H:%M:%S')
                except:
                    id_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[18]), '%m%d%Y'),
                                                         '%d/%m/%Y %H:%M:%S')
            if i[19]:
                try:
                    address_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[19]), '%m%d%Y %H:%M:%S'),
                                                              '%d/%m/%Y %H:%M:%S')
                except:
                    address_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[19]), '%m%d%Y'),
                                                              '%d/%m/%Y %H:%M:%S')
            if i[20]:
                try:
                    age_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[20]), '%m%d%Y %H:%M:%S'),
                                                          '%d/%m/%Y %H:%M:%S')
                except:
                    age_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[20]), '%m%d%Y'),
                                                          '%d/%m/%Y %H:%M:%S')
            if i[21]:
                try:
                    income_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[21]), '%m%d%Y %H:%M:%S'),
                                                             '%d/%m/%Y %H:%M:%S')
                except:
                    income_date = datetime.datetime.strftime(datetime.datetime.strptime(str(i[21]), '%m%d%Y'),
                                                             '%d/%m/%Y %H:%M:%S')
            row = [
                ("Sr no", srno),
                ("Agent name", str(i[28])),  # 6109
                ("Application ID", str(i[2])),
                ("Customer name", str(i[0]) + " " + str(i[1])),
                ("Mobile", str(i[7])),
                ("Created on", str(i[6])),
                ("Call type", str(i[4])),
                ("Next call time", str(i[5])),
                ("Disposition", str(i[3])),
                ("Medical Preference 1", str(i[8]) + ", " + str(i[9]) + ", " + str(i[10]) + "."),
                ("Medical Preference 2", str(i[11]) + ", " + str(i[12]) + ", " + str(i[13]) + "."),
                ("ID Proof", str(i[14])),
                ("ID Proof Date", id_date),
                ("Address Proof", str(i[15])),
                ("Address Proof Date", address_date),
                ("Age Proof", str(i[16])),
                ("Age Proof Date", age_date),
                ("Income Proof", str(i[17])),
                ("Income Proof Date", income_date),
                ("UHCI Download Date", str(i[22])),
                ("Online Created Date", str(i[23])),
                ("Aspectcall Start Time", str(i[24])),
                ("Aspectcall End Time", str(i[25])),
                ("Aspectcall Duration", str(i[26])),
                ("Aspectcall Dial Flag", str(i[27])),
            ]
            if srno == 1:
                writer.writerow([k[0] for k in row])

            writer.writerow([k[1] for k in row])
            srno = srno + 1
            # response.write(i[0])
        return response
    else:
        return response


def communicate_report(request):
    # response = HttpResponse()
    cur = connection.cursor()
    from_date = ""
    to_date = ""
    action_type = ""
    if request.GET['from_date1']:
        from_date = request.GET['from_date1'] + " " + "00:00:00"
    if request.GET['to_date1']:
        to_date = request.GET['to_date1'] + " " + "23:59:59"
    if request.GET['action_type'] != "Select":
        action_type = request.GET['action_type']
    application = request.GET['application']
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Communication_Report_%s.csv"' % (
    datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)

    report_query = "select core_application.app_id as ApplicationID,core_actionhistory.to,core_actionhistory.created_on,core_actionhistory.action_type,core_actionhistory.meta as Type,core_application.app_status from core_actionhistory,core_application where core_application.id=core_actionhistory.application_id "
    if from_date and to_date:
        report_query += " and core_actionhistory.created_on between '%s' and '%s'" % (from_date, to_date)
    if application:
        report_query += "and core_application.app_id = '%s'" % (application)
    if action_type:
        report_query += "and core_actionhistory.action_type='%s' " % (action_type)
    print report_query
    cur.execute(report_query)
    query_result = cur.fetchall()
    row_count = cur.rowcount
    srno = 1

    if query_result:
        for i in query_result:
            to = i[1]
            if i[3] == "email":
                to = to[3:-2]
            meta = i[4]
            if i[4] == "FUP_STATUS":
                meta = "Requirement Reminder"
            if i[4] == "APP_STATUS":
                meta = i[5]
                if i[5] == "DC":
                    meta = "DECLINED"
                elif i[5] == "RJ":
                    meta = "REJECTED"
                elif i[5] == "PO":
                    meta = "POSTPONED"

            row = [
                ("Sr no", srno),
                ("Application ID", str(i[0])),
                ("To", to),
                ("Created on", str(i[2])),
                ("Action Type", str(i[3])),
                ("Meta", meta),
            ]
            if srno == 1:
                writer.writerow([k[0] for k in row])

            writer.writerow([k[1] for k in row])
            srno = srno + 1
        return response
    else:
        return response


@csrf_exempt
@login_required
def make_call(request, mobile, application, cid):
    '''  SubANI Field1'''
    dsn = 'sqlserverdatasource'
    user = 'user_click;'
    password = 'pass@123;'
    database = 'ACR;'
    # print mobile
    # print "app_call:", application
    asp_name = request.user.userprofile.aspect_username
    now = datetime.datetime.strftime(datetime.datetime.now(), "%Y-%m-%d %H:%M:%S")
    now1 = datetime.datetime.strftime(datetime.datetime.now(), "%Y-%m-%d %H:10:10")

    con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)
    cnxn = pyodbc.connect(con_string)
    cur = cnxn.cursor()
    #    return HttpResponse('OK')
    try:
        # query="Insert into UAT_ClickToDial (SubANI,Field1,App_ID,App_Name,Field2) values('%s','%s','%s','%s','%s')" %(mobile,asp_name,application,"Emerge",cid)
        query = "Insert into UAT_ClickToDial (SubANI,Field1,App_ID,App_Name,Field2,Call_Duration_Seconds,CallStartDT,CallEndDT) values('%s','%s','%s','Emerge','%s','10','%s','%s')" % (
        mobile, asp_name, application, cid, now, now1)

        #  print query
        cur.execute(query)
        cnxn.commit()
        return HttpResponse('OK')
    except Exception as e:
        print "Exception in Click to dial", e
        return HttpResponse('NOK')


@csrf_exempt
@login_required
def uhc_download_report(request):
    cur = connection.cursor()
    from_date = request.GET['from_date2'] + " " + "00:00:00"
    to_date = request.GET['to_date2'] + " " + "23:59:59"
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="uhc_download_Report_%s.csv"' % (
    datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)

    uhc_query = "select distinct core_uhcdownload.application_id,core_uhcdownload.tests, salutation,first_name, last_name, emerge.core_application.created_on, app_id, gender,emerge.core_application.marital_status,landline,mobile,dob,nationality,concat(flat,', ', building,', ',road,', ',area,', ',landmark,', ',city,', ',state,', ',pincode) as address,State,concat(emerge.core_application.medicalappointment_center1,', ',emerge.core_application.medicalappointment_location1,', ',emerge.core_application.medicalappointment_city1) as uhc_location1, emerge.core_application.medicalappointment_date1,emerge.core_application.medicalappointment_time1,concat(emerge.core_application.medicalappointment_center2,', ',emerge.core_application.medicalappointment_location2,', ',emerge.core_application.medicalappointment_city2) as uhc_location2,emerge.core_application.medicalappointment_date2,emerge.core_application.medicalappointment_time2,emerge.core_uhcdata.status,core_uhcdownload.created_on,email from emerge.core_uhcdownload,emerge.core_application,emerge.core_uhcdata where emerge.core_uhcdownload.application_id = emerge.core_application.id and emerge.core_uhcdata.application_id = emerge.core_application.id and emerge.core_uhcdownload.created_on between '%s' and '%s' order by emerge.core_uhcdownload.created_on desc;" % (
    from_date, to_date)
    cur.execute(uhc_query)
    uhc = cur.fetchall()

    if uhc:
        srno = 1
        for i in uhc:
            print i[0]
            row = [
                ("Sr no", str(srno)),
                ("Name", "%s %s %s" % (i[2], i[3], i[4])),
                ("Download Date", i[22].strftime("%d/%m/%y")),
                ("Application Date", i[5].strftime("%d/%m/%Y")),
                ("Insurer", 'BSLI'),
                ("Insurer Division", 'ECS'),
                ("Application ID", i[6]),
                ("Gender", i[7]),
                ("Marital Status", i[8]),
                ("Phone", i[9]),
                ("Mobile", i[10]),
                ("Tests", i[1]),
                # Priority
                ("DOB", i[11].strftime("%d-%m-%Y")),
                ("Minor/ Adult", 'Adult'),
                ("Country", i[12]),
                ("Email", i[23]),
                ("Address", i[13]),
                ("State", i[14]),
                ("Uhc location 1", i[15]),
                ("Appointment Date 1", i[16]),
                ("Appointment Time 1", i[17]),
                ("Uhc location 2", i[18]),
                # Provider Name
                ("Appointment Date 2", i[19]),
                ("Appointment Time 2", i[20]),
                ("status", i[21]),

            ]
            if srno == 1:
                writer.writerow([k[0] for k in row])

            writer.writerow([k[1] for k in row])
            srno = srno + 1
        return response
    else:
        return response


@csrf_exempt
@login_required
def requirement_list_report(request):
    cur = connection.cursor()
    data_row_list = []
    from_date = request.GET['from_date3'] + " " + "00:00:00"
    to_date = request.GET['to_date3'] + " " + "23:59:59"

    req_query = """select distinct A.app_id, D.name, D.description,
    C.order_status, C.med_indicator,
    A.created_on as Application_creation_date,
    C.generated_on as Fup_generated_on,
    E.created_on as UHC_download_date,
    F.uhci_file_received_date as UHC_upload_date,
    C.received_on as Fup_received_on,
    F.uhci_scheduled_date as UHC_scheduled_date,
    F.bsli_reports_sent_date as Bsli_sent_date,
    F.status as UHC_status
    from emerge.core_application As A Left Outer Join
    emerge.core_application_fup_associated B on A.id = B.application_id Left Outer JOIN
    emerge.core_fupassociated As C On B.fupassociated_id = C.id Left Outer Join
    emerge.core_fup As D on C.code_id = D.id Left Outer Join
    emerge.core_uhcdata As F on A.id = F.application_id Left Outer Join
    emerge.core_uhcdownload As E On A.id = E.application_id
    where A.app_status="PS" and A.created_on between '%s' and '%s';""" % (from_date, to_date)
    cur.execute(req_query)
    req = cur.fetchall()
    for i in req:
        data_row_list.append(i)
        order = ['Application ID', 'Req. Name', 'Req. Description', 'Order Status',
                 'Medical Indicator', 'Application Created Date', 'Req. Generated Date',
                 'UHC Download Date', 'UHC File Received Date', 'UW Req. Received Date',
                 'UHC Scheduled Date', 'BSLI Sent Date', 'UHC status']
        # filename = "Requirement List_"+str(datetime.datetime.now())+".xls"
        filename = "Requirement_List_%s.xls" % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    return utils.render_excel(filename, order, data_row_list)



# new web service for policy and new d2c and joint life 6733
# 6733
# date 1 feb 2017 
@csrf_exempt
def create_application(request):
  
    print "data ---",request.POST.get('data')

    if not request.POST.get('data'):
       return  HttpResponse(simplejson.dumps({'success' : False, 'error' : "Payload missing"}))
        
          
    data = request.POST['data']
    try:
        null = ""
        rdata = eval(simplejson.loads(data)['data'])
    except:
        try:
            rdata = simplejson.loads(request.POST['data'])
        except:
            try:
                data = request.POST['data']
                rdata = simplejson.loads(data)
            except:
                return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Incorrect serialization"}))

    try:
        if rdata["Proposer"]:
            rdata = rdata
            is_insurer = "YES"
    except:
        rdata = rdata
        is_insurer = "NO"       

 
    if is_insurer == "YES":
        if rdata["Proposer"]["product_category"] == "SecureSelf" or rdata["Proposer"]["product_category"] == "SecureChild" or  rdata["Proposer"]["product_category"] == "SecureSpouse" or rdata["Proposer"]["product_category"] == "ProtectSelf" or rdata["Proposer"]["product_category"] == "JointLife" or rdata["Proposer"]["product_category"] == "VisionStar" or rdata["Proposer"]["product_category"] == "CancerShield" or rdata["Proposer"]["product_category"]== "WealthProtection" or rdata["Proposer"]["product_category"] == "VisionSelf" or rdata["Proposer"]["product_category"] == "VisionSpouse" or rdata["Proposer"]["product_category"] == "CancerSelf" or rdata["Proposer"]["product_category"] == "CancerSpouse" or rdata["Proposer"]["product_category"] == "WealthSelf" or rdata["Proposer"]["product_category"] == "WealthSpouse" or rdata["Proposer"]["product_category"] == "WealthChild":

            if not rdata["Proposer"]["app_id"]:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Application ID is missing"}))

            try:
                data = iutils.format_application_form_data(rdata["Proposer"])
                ins_data = iutils.format_application_form_data_1(rdata["Insurer"])
                
            except Exception as e:
                return HttpResponse(simplejson.dumps({'success': False, 'error': e}))
        
            try:
                if rdata["Proposer"]:
                    app = Application.objects.filter(app_id=data['app_id'])
                    ins_app = InsurerApplication.objects.filter(ins_app_id=ins_data['ins_app_id'])
            except:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Application not found"}))

            if app:
                if rdata["Proposer"]["product_category"] == "SecureSelf" or rdata["Proposer"]["product_category"] == "SecureChild" or  rdata["Proposer"]["product_category"] == "SecureSpouse" or rdata["Proposer"]["product_category"] == "ProtectSelf" or rdata["Proposer"]["product_category"] == "JointLife" or  rdata["Proposer"]["product_category"] == "VisionStar" or rdata["Proposer"]["product_category"] == "CancerShield" or rdata["Proposer"]["product_category"]== "WealthProtection" or rdata["Proposer"]["product_category"] == "VisionSpouse" or rdata["Proposer"]["product_category"] == "CancerSelf" or rdata["Proposer"]["product_category"] == "CancerSpouse" or rdata["Proposer"]["product_category"] == "WealthSelf" or rdata["Proposer"]["product_category"] == "WealthSpouse" or rdata["Proposer"]["product_category"] == "WealthChild" or rdata["Proposer"]["product_category"] == "VisionSelf":

                    app = app.update(**data)
                    return HttpResponse(simplejson.dumps({'success': True, 'warning': 'Pre-existing application, updated'}))

            else:
                if rdata["Proposer"]["product_category"] == "SecureSelf" or rdata["Proposer"]["product_category"] == "SecureChild" or  rdata["Proposer"]["product_category"] == "SecureSpouse" or rdata["Proposer"]["product_category"] == "ProtectSelf" or rdata["Proposer"]["product_category"] == "JointLife" or  rdata["Proposer"]["product_category"] == "VisionStar" or rdata["Proposer"]["product_category"] == "CancerShield" or rdata["Proposer"]["product_category"]== "WealthProtection" or rdata["Proposer"]["product_category"] == "VisionSpouse" or rdata["Proposer"]["product_category"] == "CancerSelf" or rdata["Proposer"]["product_category"] == "CancerSpouse" or rdata["Proposer"]["product_category"] == "WealthSelf" or rdata["Proposer"]["product_category"] == "WealthSpouse" or rdata["Proposer"]["product_category"] == "WealthChild" or rdata["Proposer"]["product_category"] == "VisionSelf":
                    
                    app = Application(**data)
                    app.save()
                    app.product_name = rdata["Proposer"]["product_category"]
                    app.save()
                    ins_app = InsurerApplication(**ins_data)
                    ins_app.save()
                    ins_app.ins_application = app
                    ins_app.save()

                    uhc = iutils.create_uhc_for_application(app)
                    apca = ApplicationCallAttribute(application=app, last_call_status='F', is_taken=False,
                                                    next_calltime=datetime.datetime.now())
                    apca.save()
            return HttpResponse(simplejson.dumps({'success': True}))
        
    else:

        if not rdata.get('app_id'):
            return HttpResponse(simplejson.dumps({'success': False, 'error': "Application ID is missing"}))

        try:
             data = iutils.format_application_form_data(rdata)
             print "datataaa", data
        except Exception as e:
             return HttpResponse(simplejson.dumps({'success': False, 'error': e}))

        app = Application.objects.filter(app_id=data['app_id'])
        print "asdasd:>", app
        # iutils.reconcile_with_lms(app)
        if app:
            app = app.update(**data)
            return HttpResponse(simplejson.dumps({'success': True, 'warning': 'Pre-existing application, updated'}))
        else:
            app = Application(**data)
            app.save()
            uhc = iutils.create_uhc_for_application(app)
            apca = ApplicationCallAttribute(application=app, last_call_status='F', is_taken=False,
                                            next_calltime=datetime.datetime.now())
            apca.save()
        return HttpResponse(simplejson.dumps({'success': True}))



from Crypto import Random
from Crypto.Cipher import AES
import base64
import os

import reject_data as putils
@csrf_exempt
def create_policy_bazaar_application(request):
    # print "data ---",request.POST.get('data')

    if not request.POST.get('data'):
  
        BLOCK_SIZE = 16
        PADDING = '{'
        pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
        EncodeAES = lambda c, s: base64.b64encode(c.encrypt(pad(s)))
        DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING)
        secret = os.urandom(BLOCK_SIZE)
        cipher = AES.new(secret)
        msg = simplejson.dumps({'success': False, 'error': "Payload missing"})
        encoded = EncodeAES(cipher, str(msg))
        print 'Encrypted string:', encoded
      
        # decode the encoded string
        decoded = DecodeAES(cipher, encoded)
        print 'Decrypted string:', decoded
        # for pbz encryption pls change to encryption
        return HttpResponse(decoded)

        #return HttpResponse(simplejson.dumps({'success': False, 'error': "Payload missing"}))

    data = request.POST['data']
    try:
        null = ""
        rdata = eval(simplejson.loads(data)['data'])
    except:
        try:
            rdata = simplejson.loads(request.POST['data'])
        except:
            try:
                data = request.POST['data']
                rdata = simplejson.loads(data)
            except:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Incorrect serialization"}))

    try:
        if rdata["Proposer"]:
            rdata = rdata
            is_insurer = "YES"
    except:
        rdata = rdata
        is_insurer = "NO"

    if is_insurer == "YES":

        final_data = rdata["Proposer"].copy()
        ins_final_data = rdata["Insurer"].copy()

        # code to add for special charactor logic
        rlog = ""
        rejected, reason = putils.reject_data(final_data,ins_final_data)
        if rejected:
            response = "Rejected Reason -INVALID  JSON - %s \n" % (reason)
            rlog += response
            return HttpResponse(simplejson.dumps({'success': False, 'error': rlog}))

        # end here        
        if rdata["Proposer"]["product_category"] == "SecureSelf" or rdata["Proposer"][
            "product_category"] == "SecureChild" or rdata["Proposer"]["product_category"] == "SecureSpouse" or \
                        rdata["Proposer"]["product_category"] == "ProtectSelf" or rdata["Proposer"][
            "product_category"] == "JointLife" or rdata["Proposer"]["product_category"] == "VisionStar" or \
                        rdata["Proposer"]["product_category"] == "CancerShield" or rdata["Proposer"][
            "product_category"] == "WealthProtection" or rdata["Proposer"]["product_category"] == "VisionSelf" or \
                        rdata["Proposer"]["product_category"] == "VisionSpouse" or rdata["Proposer"][
            "product_category"] == "CancerSelf" or rdata["Proposer"]["product_category"] == "CancerSpouse" or \
                        rdata["Proposer"]["product_category"] == "WealthSelf" or rdata["Proposer"][
            "product_category"] == "WealthSpouse" or rdata["Proposer"]["product_category"] == "WealthChild":

            if not rdata["Proposer"]["app_id"]:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Application ID is missing"}))

            try:
                data = iutils.pbz_format_application_form_data(rdata["Proposer"])
                ins_data = iutils.pbz_format_application_form_data_1(rdata["Insurer"])

            except Exception as e:
                return HttpResponse(simplejson.dumps({'success': False, 'error': e}))

            try:
                if rdata["Proposer"]:
                    app = Application.objects.filter(app_id=data['app_id'])
                    ins_app = InsurerApplication.objects.filter(ins_app_id=ins_data['ins_app_id'])
            except:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Application not found"}))

            if app:
                    app = app.update(**data)
                    ins_app = ins_app.update(**ins_data)
                    return HttpResponse(
                        simplejson.dumps({'success': True, 'warning': 'Pre-existing application, updated'}))

            else:          
                    app = Application(**data)
                    app.save()
                    app.product_name = rdata["Proposer"]["product_category"]
                    app.save()
                    ins_app = InsurerApplication(**ins_data)
                    ins_app.save()
                    ins_app.ins_application = app
                    ins_app.save()                    

                    uhc = iutils.create_uhc_for_application(app)
                    apca = ApplicationCallAttribute(application=app, last_call_status='F', is_taken=False,
                                                    next_calltime=datetime.datetime.now())
                    apca.save()
            return HttpResponse(simplejson.dumps({'success': True}))

    else:
        if not rdata.get('app_id'):
            return HttpResponse(simplejson.dumps({'success': False, 'error': "Application ID is missing"}))
        try:
            data = iutils.format_application_form_data(rdata)
            print "datataaa", data
        except Exception as e:
            return HttpResponse(simplejson.dumps({'success': False, 'error': e}))

        app = Application.objects.filter(app_id=data['app_id'])
        print "asdasd:>", app
       
        if app:
            app = app.update(**data)
            return HttpResponse(simplejson.dumps({'success': True, 'warning': 'Pre-existing application, updated'}))
        else:
            app = Application(**data)
            app.save()
            uhc = iutils.create_uhc_for_application(app)
            apca = ApplicationCallAttribute(application=app, last_call_status='F', is_taken=False,
                                            next_calltime=datetime.datetime.now())
            apca.save()
        return HttpResponse(simplejson.dumps({'success': True}))        
