cd /home/projects/git/bsliemerge/base;
source /home/projects/bsliemerge/envproj/bin/activate
touch ../../bsliemerge-logs/gunicorn.pid
touch ../../bsliemerge-logs/error_`date +"%Y_%m_%d"`.log
touch ../../bsliemerge-logs/access_`date +"%Y_%m_%d"`.log
gunicorn wsgi:application --bind=0.0.0.0:8001 --pid=../../bsliemerge-logs/gunicorn.pid --access-logfile=../../bsliemerge-logs/access_`date +"%Y_%m_%d"`.log --workers=5 --worker-class=gevent --error-logfile=../../bsliemerge-logs/error_`date +"%Y_%m_%d"`.log --timeout=4500 --name=EMERGE
