#!/bin/bash

#In cron tab put
#1 15 * * * /root/projects/bsliemerge/base/scripts/cron.sh >> /root/projects/bsliemerge/base/logs/cron.log 2>&1

export PYTHONPATH="."
cd /Application/root/projects/bsliemerge/base/;/Application/root/projects/bsliemerge/envproj/bin/python /Application/root/projects/bsliemerge/base/scripts/mailer_uw_extra.py
cd /Application/root/projects/bsliemerge/base/;/Application/root/projects/bsliemerge/envproj/bin/python /Application/root/projects/bsliemerge/base/scripts/mailer_requirement_reminder.py
cd /Application/root/projects/bsliemerge/base/;/Application/root/projects/bsliemerge/envproj/bin/python /Application/root/projects/bsliemerge/base/scripts/mailer_app_status_reminder.py
