#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
from customdb.customquery import sqltojson, sqltodict
import iutils


print "AppID : App_Status : CallHist_ID : APP_LAST_CALL_STATUS"
for apca in ApplicationCallAttribute.objects.filter(app_status__in=['WD','PO','FL','DC', 'IF', 'XX']):
    if apca.last_call_status == "TF-AUTO": continue
    ctype = "TF"
    call = CallHistory(
        application=apca.application,
        call_type='TF',
        assigned_to=User.objects.get(username='callcenter'),
    )
    call.save()
    print "%s : %s : %s : %s" % (apca.application.app_id, apca.app_status, call.id, apca.last_call_status)
    call.call_type = 'TF-AUTO'
    apca.call_barred = True
    apca.is_call_later = False
    call.is_call_later = False
    apca.last_call_status = call.call_type
    apca.is_taken = False

    call.save()
    apca.save()



