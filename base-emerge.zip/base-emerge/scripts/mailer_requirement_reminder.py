#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
from django.db.models import Q
import iutils

ZERO_DAYS = (datetime.datetime.today() - datetime.timedelta(days=0)).date()
SEVEN_DAYS = (datetime.datetime.today() - datetime.timedelta(days=7)).date()
FOURTEEN_DAYS = (datetime.datetime.today() - datetime.timedelta(days=14)).date()
TWENTYONE_DAYS = (datetime.datetime.today() - datetime.timedelta(days=21)).date()

print "\n\n", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), " --------- FUP REQUIREMENT STATUS ---------------- \n"
print "Finding applications for which FUPs are open since 7, 14, 21 days - ", SEVEN_DAYS, FOURTEEN_DAYS, TWENTYONE_DAYS



app_list = Application.objects.filter(Q(fup_associated__received_on__isnull=True, fup_associated__generated_on__in=[ZERO_DAYS, SEVEN_DAYS, FOURTEEN_DAYS, TWENTYONE_DAYS],fup_associated__order_status__in=['ORD'],app_status__in=['', 'PS'])).exclude(fup_associated__code__name='CWA').distinct()
l=[]


for app in app_list:
	
	# 6733 insurer new d2c
	try:
		app_data = Application.objects.get(app_id = app)

                ins_data = InsurerApplication.objects.get(ins_application = app_data)	
		#ins_data = InsurerApplication.objects.get(ins_application=app)
	except:
		ins_data = None
		print "insurer data not in mailer requirement remider script"
		

	
	tests = [f.generated_on for f in app.fup_associated.all()]
	tests.sort()
	
	if app.fup_status_mail == "1":
		print "Open FUPs for application:", app.app_id
		iutils.send_customer_mail(app, 'FUP_STATUS', ins_data) # 6733
		#           app.fup_status_mail = "2"
		#          app.save()
	if app.fup_status_mail == "2":
		#		print "asd",app
		
		#app_second_mail_list = Application.objects.filter(Q(fup_associated__received_on__isnull=True, fup_associated__generated_on__in=[ZERO_DAYS, SEVEN, FOURTEEN, TWENTYONE],fup_associated__order_status__in=['ORD'],app_status__in=['', 'PS'],app_id=app.app_id)).distinct()
		if tests[0] == ZERO_DAYS:
			print "Open FUPs for application ZERO: ", app.app_id
			iutils.send_customer_mail(app, 'FUP_STATUS', ins_data)          # 6733
		if tests[0] == SEVEN_DAYS:
			print "Open FUPs for application SEVEN: ", app.app_id
			iutils.send_customer_mail(app, 'FUP_STATUS', ins_data)        # 6733         
		if tests[0] == FOURTEEN_DAYS:
			print "Open FUPs for application FOURTEEN: ", app.app_id
			iutils.send_customer_mail(app, 'FUP_STATUS', ins_data)            # 6733
 		if tests[0] == TWENTYONE_DAYS:
			print "Open FUPs for application TWENTYONE: ", app.app_id
			iutils.send_customer_mail(app, 'FUP_STATUS', ins_data)         # 6733
 	
# #print app_second_mail_list
# for appsc in app_second_mail_list:
			

# 	iutils.send_customer_mail(app, 'FUP_STATUS')
