import urllib
import urllib2
import json

url = 'http://bsliemerge.glitterbug.in/create-application/'
values = {
    'address_proof': 'LETTER FOM RECOGNISED PUBLIC AUTHORITY/SERVANT',
    'annual_income': '345645645645',
    'annual_premium': '8766237.36',
    'app_id': 'OA0000318',
    'appointee_dob': '06081996',
    'appointee_first_name': 'sdfsdf',
    'appointee_last_name': 'sdfsd',
    'appointee_relationship': 'Grand Mother',
    'appointee_title': 'Mrs.',
    'area': 'sdfds',
    'birth_city': 'Adoni',
    'birth_state': 'Andhra Pradesh',
    'building': 'fsdfsdfs',
    'business_nature': 'dfgfdg',
    'city': 'Badarpur',
    'designation': 'sdfds',
    'dob': '01091996',
    'duty_nature': 'sdfds',
    'education': 'HSC',
    'eia_number': '',
    'email_id': 'jain20@gmail.com',
    'employer_name': 'sdfsd',
    'father_name': '',
    'first_name': 'Abhi',
    'flat': 'cvxc',
    'gender': 'F',
    'id_proof': 'RATION CARD',
    'income_proof': 'Bank Cash-flows statements transactions not older then 6 months',
    'insurance_purpose': 'sdfsdfsdf',
    'ir_emailid': '',
    'ir_name': '',
    'landline': '4534534534543',
    'landmark': 'sdfds',
    'last_name': 'jain',
    'marital_status': 'Married',
    'mobile_no': '9967679737',
    'months_withemployer': '11',
    'nationality': 'Indian',
    'nominee_dob': '12082011',
    'nominee_first_name': 'ssdfs',
    'nominee_last_name': 'sdfd',
    'nominee_relationship': 'Grand Father',
    'nominee_title': 'Ms.',
    'occupation': 'Business',
    'p_area': 'sdfds',
    'p_building': 'fsdfsdfs',
    'p_city': 'Badarpur',
    'p_flat': 'cvxc',
    'p_landline': '4534534534543',
    'p_landmark': 'sdfds',
    'p_pincode': '435434',
    'p_road': 'sdfds',
    'p_state': 'Assam',
    'pan_no': '',
    'pay_amount': '730519.78',
    'pay_status': '',
    'pincode': '435434',
    'politically_exposed': 'Yes',
    'politically_exposeddetails': 'sdfsdfds34534',
    'road': 'sdfds',
    'state': 'Assam',
    'sum_assured': '1342500000',
    'tracker_id': '',
    'transaction_id': '',
    'uid_no': '',
    'years_withemployer': '16'
}

data = urllib.urlencode({'data' : json.dumps({'data' : values})})
req = urllib2.Request(url, data)
try:
    response = urllib2.urlopen(req)
    the_page = response.read()
    print the_page
except urllib2.HTTPError as e:
    print e.code
    print e.read()
