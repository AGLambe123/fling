#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
import iutils



print "\n\n", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), " --------- App status reminder ---------------- \n"

app_list = Application.objects.filter(app_status_mail="-1")
for app in app_list:
        
    # 6733 insurer deatils for rider decline
    try:
         app_data = Application.objects.get(app_id = app)
        
         ins_data = InsurerApplication.objects.get(ins_application = app_data)
         #ins_data = InsurerApplication.objects.get(ins_application=app)
       
    except:
        ins_data = None
        print "insurer data not present  in mailer_app_status script"


    if app.app_status in ['DC','PO','RJ'] and app.app_status_reason and app.app_status_reason_text:
        print "App_status_mail application:", app.app_id
        iutils.send_customer_mail(app, 'APP_STATUS', ins_data)    # 6733
        app.app_status_mail = "1"
        app.save()
      
        
    if app.app_status in ['DC','PO','RJ'] and not app.app_status_reason and not app.app_status_reason_text:
        print "application without app status and app text", app.app_id

    
    try:
        if app.app_status not in ['DC','PO','RJ'] and app.critical_policystatus or app.hospital_policystatus or app.accidental_policystatus or app.surgical_policystatus or app.accidentaldeathbenefit_policystatus or app.waiverofPremium_policystatus or ins_data.ins_app_status:   # wop rider and insurer data  6733
            print "Rider decline mail"
            iutils.send_customer_mail(app, 'RIDER_DECLINE', ins_data) # 6733
            mail_sent = True
    except:        
        if app.app_status not in ['DC','PO','RJ'] and app.critical_policystatus or app.hospital_policystatus or app.accidental_policystatus or app.surgical_policystatus or app.accidentaldeathbenefit_policystatus or app.waiverofPremium_policystatus:         # 6733 wop rider 
            print "rider decline mail", app.app_id
            iutils.send_customer_mail(app, 'RIDER_DECLINE', ins_data)          # 6733
            app.app_status_mail = "1"
            app.save() 
