
export PYTHONPATH="."
cd /home/projects/bsliemerge/base/;/root/projects/bsliemerge/envproj/bin/python /home/projects/bsliemerge/base/scripts/ad_hoc_mailer.py









