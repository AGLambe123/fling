#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
import iutils

print "\n\n", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), " --------- UW EXTRA MAILERS ---------------- \n"
print "Finding applications for which UW Extra mails need to be sent"
app_list = Application.objects.filter(uw_extra_premium_mail="-1")
for app in app_list:
    print "UW Extra application mail for :", app.app_id
    if app.app_uw_reason == 'HLT':
        iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH')
    if app.app_uw_reason == 'ESC':
        iutils.send_customer_mail(app, 'UW_EXTRA_SA_RESTRICTION')
    if app.app_uw_reason == 'NSS':
        iutils.send_customer_mail(app, 'UW_EXTRA_NON_SMOKER_TO_SMOKER')
    if app.app_uw_reason == 'HLTNSS':
        iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER')
    app.uw_extra_premium_mail = 1
    app.save()
