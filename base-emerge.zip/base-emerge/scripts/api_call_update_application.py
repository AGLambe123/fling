import urllib
import urllib2
import json

"""
REQ_ID
REQ_STATUS_ID
REQ_DESC
ORDERED_DATE // fup raised
RECEIVED_DATE  // fup recvd
REC_ACCEPTED_DATE  // fup accepted - closed
CANCELLED_DATE  // fup cancelled
REQ_CREATE_DATE  // same ordered_date
MEDI_IND  // "Medical yes/no"

Final output:

[{
u'application_id': u'BA0000204',
u'bill_date': u'',
u'courier_name': u'',
u'deliveryDate': u'',
u'deliveryStatus': u'',
u'fup': [
    [
        u'CWA',
        u'SIR',
        u'Cash with Application',
        u'',
        u'',
        u'',
        u'',
        u'2014-10-09',
        u'N'
    ],
    [
        u'SIGNM',
        u'SIR',
        u'Signature Required Card',
        u'',
        u'',
        u'',
        u'',
        u'2014-10-09',
        u'N'
    ]
],
u'mailDate': u'',
u'npwDueDate': u'',
u'npwStatus': u'N',
u'policy_issue_date': u'2014-10-09',
u'policy_reject_reason': u'',
u'policy_status': u'Pending, application data incomplete',
u'uwAmount': u'0.00',
u'uwReason': u'Underwriting Reason Code',
u'uwStatus': u'Pending Elementary Underwriting'
} ....  ]
"""

url = 'http://localhost:8000/update-application/'
values = [{
        u'application_id': u'OA0000318',
        u'bill_date': u'',
        u'courier_name': u'',
        u'deliveryDate': u'',
        u'deliveryStatus': u'',
        u'fup': [[u'CWA',
                u'SIR',
                u'Cash with Application',
                u'',
                u'',
                u'',
                u'',
                u'2014-10-09',
                u'N'],
            [u'SIGNM',
                u'SIR',
                u'Signature Required Card',
                u'',
                u'',
                u'',
                u'',
                u'2014-10-09',
                u'N']
            ],
        u'mailDate': u'',
        u'npwDueDate': u'',
        u'npwStatus': u'N',
        u'policy_issue_date': u'2014-10-09',
        u'policy_reject_reason': u'',
        u'policy_status': u'1',
        u'uwAmount': u'0.00',
        u'uwReason': u'Underwriting Reason Code',
        u'uwStatus': u'Pending Elementary Underwriting'
    }, {

        u'application_id': u'A100123494',
        u'bill_date': u'',
        u'courier_name': u'',
        u'deliveryDate': u'',
        u'deliveryStatus': u'',
        u'fup': [[u'CWA',
            u'SIR',
            u'Cash with Application',
            u'',
            u'',
            u'',
            u'',
            u'2014-10-09',
            u'N'],
        [u'SIGNM',
            u'SIR',
            u'Signature Required Card',
            u'',
            u'',
            u'',
            u'',
            u'2014-10-09',
            u'N']
        ],
        u'mailDate': u'',
        u'npwDueDate': u'',
        u'npwStatus': u'N',
        u'policy_issue_date': u'2014-10-09',
        u'policy_reject_reason': u'',
        u'policy_status': u'B',
        u'uwAmount': u'0.00',
        u'uwReason': u'Underwriting Reason Code',
        u'uwStatus': u'Pending Elementary Underwriting'
    }, {
        u'application_id': u'A100123494',
        u'bill_date': u'',
        u'courier_name': u'',
        u'deliveryDate': u'',
        u'deliveryStatus': u'',
        u'fup': [[u'CWA',
            u'SIR',
            u'Cash with Application',
            u'',
            u'',
            u'',
            u'',
            u'2014-10-09',
            u'N'],
            [u'SIGNM',
                u'SIR',
                u'Signature Required Card',
                u'',
                u'',
                u'',
                u'',
                u'2014-10-09',
                u'N']
            ],
        u'mailDate': u'',
        u'npwDueDate': u'',
        u'npwStatus': u'N',
        u'policy_issue_date': u'2014-10-09',
        u'policy_reject_reason': u'',
        u'policy_status': u'A',
        u'uwAmount': u'0.00',
        u'uwReason': u'Underwriting Reason Code',
        u'uwStatus': u'(None)'
    }]

data = urllib.urlencode({'data' : json.dumps(values)})
req = urllib2.Request(url, data)
try:
    response = urllib2.urlopen(req)
    the_page = response.read()
    print the_page
except urllib2.HTTPError as e:
    print e.code
    print e.read()
