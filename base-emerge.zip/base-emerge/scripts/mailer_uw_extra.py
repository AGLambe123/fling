#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
import iutils

print "\n\n", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), " --------- UW EXTRA MAILERS ---------------- \n"
print "Finding applications for which UW Extra mails need to be sent"
app_list = Application.objects.filter(uw_extra_premium_mail="-1")
for app in app_list:
    
    # 6733 insurer for mail trigger by script 
    try:
         app_data = Application.objects.get(app_id = app)
         ins_data = InsurerApplication.objects.get(ins_application = app_data) 
         #ins_data = InsurerApplication.objects.get(ins_application=app)
    except:
        ins_data = None
        print "insurer data not availble to send  email by mailer_uw_extra script "


    
    print "UW Extra application mail for :", app.app_id,app.app_uw_reason
    if app.app_uw_reason == 'HLT':
        iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH', ins_data)  # 6733
    if app.app_uw_reason == 'ESC':
        iutils.send_customer_mail(app, 'UW_EXTRA_SA_RESTRICTION', ins_data)  # 6733
    if app.app_uw_reason == 'NSS':
        iutils.send_customer_mail(app, 'UW_EXTRA_NON_SMOKER_TO_SMOKER', ins_data) # 6733
    if app.app_uw_reason == 'HLTNSS':
        iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER',ins_data)  # 6733



    app.uw_extra_premium_mail = 1
    app.save()
