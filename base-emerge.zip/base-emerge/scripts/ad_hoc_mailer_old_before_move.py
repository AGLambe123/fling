#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from django.db.models import Q
from core.models import *
import iutils

apps = """
BA0000828
"""
app_list = apps.split("\n")
for app_id in app_list:
    if app_id.strip():
        print "Application ID ", app_id
        app = Application.objects.get(app_id=app_id)
        mail_sent = False

        #If app is declined, postponed or rejected
        if app.app_status in ['DC', 'PO', 'RJ']:
            print "App status mail"
            iutils.send_customer_mail(app, 'APP_STATUS')
            mail_sent = True

        if app.app_uw_amount or app.app_uw_reason == 'ESC':
            if app.app_uw_reason == 'HLT':
                print "UW REASON HLT"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH')
            if app.app_uw_reason == 'ESC':
                print "UW REASON ESC"
                iutils.send_customer_mail(app, 'UW_EXTRA_SA_RESTRICTION')
            if app.app_uw_reason == 'NSS':
                print "UW REASON NSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_NON_SMOKER_TO_SMOKER')
            if app.app_uw_reason == 'HLTNSS':
                print "UW REASON HLTNSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER')

        else:
            if not mail_sent:
                apps = Application.objects.filter(Q(fup_associated__received_on__isnull=True, id=app.id) & ~Q(fup_associated__code__name__in=['RQ007', 'RQ006', 'RQ018', 'COFFR', 'REQ73', 'REQ91', 'RQ044']))
                #Requirement reminder mailer
                print "Requirement status mail"
                if apps:
                    iutils.send_customer_mail(apps[0], 'FUP_STATUS')
