#!/bin/bash                                                                                                                                          
#In cron tab put                                                                                                                                     
#1 15 * * * /root/projects/bsliemerge/base/scripts/cron.sh >> /root/projects/bsliemerge/base/logs/cron.log 2>&1                                      

export PYTHONPATH="."
cd /root/projects/bsliemerge/base/;/root/projects/bsliemerge/envproj/bin/python /root/projects/bsliemerge/base/scripts/aspect_crm.py