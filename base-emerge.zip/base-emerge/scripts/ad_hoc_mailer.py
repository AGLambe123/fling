#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from django.db.models import Q
from core.models import *
import iutils




apps = """
BA0015763

BA00016631

BA0015763

BA00013433

BA00018859



"""


app_list = apps.split("\n")
for app_id in app_list:
    if app_id.strip():
        print "Application ID ", app_id
        app = Application.objects.get(app_id=app_id)
        mail_sent = False

         # 6733 insurer call for Rider declined 
        try:
            ins_data = InsurerApplication.objects.get(ins_application=app)
            
        except:
            ins_data = None
            print "insurer data not availble to send insurer email"


        # 6733 added try cATCH to handle ins_data - secondary insurer policy status  policy status
        try:
            #5842-D
            if app.app_status not in ['DC','PO','RJ'] and app.critical_policystatus or app.hospital_policystatus or app.accidental_policystatus or app.surgical_policystatus or app.accidentaldeathbenefit_policystatus or app.waiverofPremium_policystatus or ins_data.ins_app_status:      # wop rider and insurer data  6733
                print "Rider decline mail"
                iutils.send_customer_mail(app, 'RIDER_DECLINE', ins_data) # 6733
                mail_sent = True
            #5842-D

        except:
            #5842-D
            if app.app_status not in ['DC','PO','RJ'] and app.critical_policystatus or app.hospital_policystatus or app.accidental_policystatus or app.surgical_policystatus or app.accidentaldeathbenefit_policystatus or app.waiverofPremium_policystatus :
                print "Rider decline mail"
                iutils.send_customer_mail(app, 'RIDER_DECLINE', ins_data) # 6733
                mail_sent = True
            #5842-D



        #If app is declined, postponed or rejected
        if app.app_status in ['DC', 'PO', 'RJ']:
            print "App status mail"
            iutils.send_customer_mail(app, 'APP_STATUS', ins_data)         #6733
            mail_sent = True

        if app.app_uw_amount or app.app_uw_reason == 'ESC':
            if app.app_uw_reason == 'HLT':
                print "UW REASON HLT"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH', ins_data)         # 6733
                print "done"
            if app.app_uw_reason == 'ESC':
                print "UW REASON ESC"
                iutils.send_customer_mail(app, 'UW_EXTRA_SA_RESTRICTION', ins_data) # 6733       
            if app.app_uw_reason == 'NSS':
                print "UW REASON NSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_NON_SMOKER_TO_SMOKER', ins_data)       # 6733
            if app.app_uw_reason == 'HLTNSS':
                print "UW REASON HLTNSS"
                iutils.send_customer_mail(app, 'UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER', ins_data)    #6733



        else:
            if not mail_sent:
                apps = Application.objects.filter(Q(fup_associated__received_on__isnull=True, id=app.id,fup_associated__order_status__in=['ORD'],app_status__in=['', 'PS']))
                #Requirement reminder mailer
                print "Requirement status mail"
                if apps:
                    iutils.send_customer_mail(apps[0], 'FUP_STATUS', ins_data)    #6733

#& ~Q(fup_associated__code__name__in=['RQ007', 'RQ006', 'RQ018', 'COFFR', 'REQ73', 'REQ91', 'RQ044'])
                    
