#!/usr/bin/env python
import sys, time, datetime, os
import Queue
import settings
import threading
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
import iutils

print "\n\n", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), " --------- App status reminder ---------------- \n"

app_list = Application.objects.filter(app_status_mail="-1")
for app in app_list:
    if app.app_status in ['DC','PO','RJ'] and app.app_status_reason and app.app_status_reason_text:
        print "Declined/Withdrawn for application:", app.app_id
        iutils.send_customer_mail(app, 'APP_STATUS')
        app.app_status_mail = "1"
        app.save()
