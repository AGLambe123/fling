import sys
from os.path import join, isfile
import datetime, time

from django.db import models
from django.db.models import get_model
from django.http import HttpResponse
from django.db.models import Q
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives

import xlrd
from xlwt import Workbook, XFStyle
import random
import simplejson
from customdb.customquery import sqltodict
import utils
import MySQLdb
import base64
from core.models import *
from django.conf import settings
from suds.client import Client

call_stages = {
    'F':None, #Never a call status, only application status
    'W':'V',
    'WV':'R',
    'V':'R',
    'R':'R',
    'TI':None,
    'TF':None,
}




def send_html_mail(application,subject, text_content, to, html_message=None, mail_type=""):
    
    from_email = "customer.support@birlasunlife.com"
    subject, from_email, to = subject, from_email, to
    msg = EmailMultiAlternatives(subject, text_content, from_email, to)
    msg.attach_alternative(html_message, "text/html")
    activityObj = ActionHistory(application=application , subject=subject, message=html_message, meta=mail_type, to=to, action_type='email')
    activityObj.save()
    msg.send()


def send_sms(application, to, message, message_code=""):
    client = Client(str('file://'+settings.SETTINGS_FILE_FOLDER+'/EAPP_SMS_Service.wsdl'))
    ssms = client.factory.create('SendSMS')
    ssms.UserID = '33'
    ssms.Password = 'bsli'
    ssms.MobileNo = to
    ssms.SMSText = message
    client.service.SendSMS(ssms)
    activityObj = ActionHistory(application=application , meta=message_code, to=to, message=message, action_type='sms')
    activityObj.save()
    return



# 6733 infy changes
def send_customer_mail(app, mail_type, ins_data):
    
    mail_html = ""
    sms_txt = ""
    #5842-D
    revised_premium=0
    if app.premium_service_tax:
        revised_premium+= float(app.premium_service_tax)
    if app.accidental_premium_service_tax:
        revised_premium+= float(app.accidental_premium_service_tax)
    if app.critical_premium_service_tax:
        revised_premium+= float(app.critical_premium_service_tax)
    if app.surgical_premium_service_tax:
        revised_premium+= float(app.surgical_premium_service_tax)
    if app.hospital_premium_service_tax:
        revised_premium+= float(app.hospital_premium_service_tax)
    if app.accidentaldeathbenefit_premium_service_tax: #added for ADB new rider
        revised_premium+= float(app.accidentaldeathbenefit_premium_service_tax)    
    # 6733 insurer wop
    if app.waiverofPremium_premium_service_tax:
        revised_premium+= float(app.waiverofPremium_premium_service_tax)

    
    # insurer added for primium service tax calculation
    # 6733
    if app.product_name == "JointLife":
        try:
            ins_tax = InsurerApplication.objects.get(ins_application=app)
            if ins_tax.ins_premium_service_tax:
                revised_premium+= float(ins_tax.ins_premium_service_tax)
        except:
            ins_tax = None
            print "error to calculate revised premium insurer joint life"#

    


    premium_paid=0
    if app.suspense_amount:
        premium_paid+= float(app.suspense_amount)
    if app.accidentaldeathpre:
        premium_paid+= float(app.accidentaldeathpre)
    if app.criticalillnesspre:
        premium_paid+= float(app.criticalillnesspre)
    if app.surgicalcarepre:
        premium_paid+= float(app.surgicalcarepre)
    if app.hospitalcareillnesspre:
        premium_paid+= float(app.hospitalcareillnesspre)
    if app.accidentalDeathAndBenefitPlusPre:  #added for new ADB  rider 
        premium_paid+= float(app.accidentalDeathAndBenefitPlusPre)    
    #6733
    if app.waiverofPremiumpre:
        premium_paid+= float(app.waiverofPremiumpre)

        
    
    
    # added for new tracker URL - new D2C 6733 UAT 
    # 6733
    if app.product_name == "" or app.tracker_id == "7":      
        tracker_string = "app_id="+app.app_id+"&source=D2C"
        tracker_encoded = base64.b64encode(tracker_string)
        tracker_url = "https://lisecuat.birlasunlife.com/Pages/Secured/Individual/MyAccount/MyInsurance/Register.aspx?"+tracker_encoded
    
    else:
        tracker_string = "app_id="+app.app_id+"&source=D2C"
        tracker_encoded = base64.b64encode(tracker_string)
        # new URL not shared by infy team
        #tracker_url = "https://lisecuat.birlasunlife.com/buy-online/my-application"
        tracker_url = "https://lisecuat.birlasunlife.com/buyonline/my-application"
    

    ##### uw_extra_health HLT, UW_HEALTH_SMOKER_SA_RESTRICTION HLTNSSESC,UW_HEALTH_SA_RESTRICTION HLTESC
    product_name  = app.product_name  
    
    if product_name == "JointLife"  or product_name == "ProtectSelf":

        if mail_type in ['UW_EXTRA_HEALTH']:
            mail_html = render_to_string('mailers/joint/latest_uw_mailer1.html', {
                    'app': app,
                    'premium_paid':premium_paid, #5842
                    'revised_premium':revised_premium, #5842
                    #'premium_remain':float(revised_premium)-float(premium_paid), #5842
                    'tracker_url':tracker_url,
                    'mail_type': mail_type,
                    'premium_difference_amount': float(app.premium_service_tax)-float(app.suspense_amount),
                    'current_time':datetime.datetime.now(),
                    'ins_data': ins_data,   #6733
                    })
        if mail_type in ['UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER','UW_EXTRA_NON_SMOKER_TO_SMOKER']:
            mail_html = render_to_string('mailers/joint/latest_uw_mailer2.html', {
                    'app': app,
                    'premium_paid':premium_paid, #5842
                    'revised_premium':revised_premium, #5842
                    #'premium_remain':float(revised_premium)-float(premium_paid), #5842
                    'mail_type': mail_type,
                    'tracker_url':tracker_url,
                    'site_url': settings.SITE_URL,
                    'current_time':datetime.datetime.now(),
                    'ins_data': ins_data,   # 6733
                    })
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
        #5842-D
            
        if mail_type in ['UW_HEALTH_SA_RESTRICTION']: 
            mail_html = render_to_string('mailers/joint/latest_uw_mailer3.html', {
                    'app': app,
                    'premium_paid':premium_paid,
                    'revised_premium':revised_premium,
                    'premium_remain':float(revised_premium)-float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url':tracker_url,
                    'current_time':datetime.datetime.now(),
                    'ins_data': ins_data,   #6733
                    })
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
            
        if mail_type in ['UW_HEALTH_SMOKER_SA_RESTRICTION','UW_EXTRA_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/joint/latest_uw_mailer4.html', {
                    'app': app,
                    'premium_paid':premium_paid,
                    'revised_premium':revised_premium,
                    'premium_remain':float(revised_premium)-float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url':tracker_url,
                    'current_time':datetime.datetime.now(),
                    'ins_data': ins_data,       # 6733
                    })
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type == 'RIDER_DECLINE':
            mail_html = render_to_string('mailers/joint/rider_decline_mailer.html', {
                    'app': app,
                    'premium_paid':premium_paid,
                    'revised_premium':revised_premium,
                    'premium_remain':float(revised_premium)-float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url':tracker_url,
                    'current_time':datetime.datetime.now(),
                    'ins_data':ins_data,              #6733
                  
                    })
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app, 'mail_type': mail_type})  
        #5842-D
        if mail_type == 'APP_STATUS':
            mail_html1 = render_to_string('mailers/joint/latest_mail_app_status.html', {
                    'app': app,
                    'mail_type': mail_type, 
                    'site_url': settings.SITE_URL,
                    'current_time':datetime.datetime.now()
                    })
            mailer_header1 = render_to_string('mailers/joint/latest_mailer_header1.html', {'site_url': settings.SITE_URL})
            mailer_footer1 = render_to_string('mailers/joint/latest_mailer_footer.html', {'site_url': settings.SITE_URL})

            if mail_html1:
                mail_html1 = "%s%s%s" % (mailer_header1, mail_html1, mailer_footer1)
                send_html_mail(app,'Your application/proposal number %s - %s' % (app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html1, [app.email],                 html_message=mail_html1, mail_type=mail_type)

        if mail_type == 'FUP_STATUS':
            TWENTYONE_DAYS = (datetime.datetime.today() - datetime.timedelta(days=21)).date()
            ZERO_DAYS = (datetime.datetime.today() - datetime.timedelta(days=0)).date()

            tests = [f.generated_on for f in app.fup_associated.all()]
            tests.sort()
            twentyone = ""
            zero = ""
            if tests[0] == TWENTYONE_DAYS:
                twentyone = "1"
            if tests[0] == ZERO_DAYS:
                zero = "1"

            mail_html = render_to_string('mailers/joint/mail_requirements.html', {
                    'app': app,
                    'revised_premium': revised_premium,
                    'mail_type': mail_type,
                    'tracker_url':tracker_url,
                    'site_url': settings.SITE_URL,
                    'open_fups': app.fup_associated.filter(received_on__isnull=True),
                    'current_time':datetime.datetime.now(),
                    'twentyone':twentyone,
                    'zero':zero,
                    'ins_data': ins_data # 6733
                    })
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        mailer_header = render_to_string('mailers/joint/latest_mailer_header.html', {'site_url': settings.SITE_URL})
        mailer_footer = render_to_string('mailers/joint/latest_mailer_footer.html', {'site_url': settings.SITE_URL})
        if mail_html:
            mail_html = "%s%s%s" % (mailer_header, mail_html, mailer_footer)
            send_html_mail(app,'Your application/proposal number %s - %s' % (app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html, [app.email], html_message=mail_html, mail_type=mail_type)

        if sms_txt:
            send_sms(app,app.mobile, sms_txt, mail_type)
            pass

    # else block insurer (secure plus) 6733
    elif app.product_name == "SecureSelf" or app.product_name == "SecureChild" or app.product_name == "SecureSpouse":
        if mail_type in ['UW_EXTRA_HEALTH']:
            mail_html = render_to_string('mailers/secure/latest_uw_mailer1.html', {
                'app': app,
                'premium_paid': premium_paid,  # 5842
                'revised_premium': revised_premium,  # 5842
                # 'premium_remain':float(revised_premium)-float(premium_paid), #5842
                'tracker_url': tracker_url,
                'mail_type': mail_type,
                'premium_difference_amount': float(app.premium_service_tax) - float(app.suspense_amount),
                'current_time': datetime.datetime.now(),
                'ins_data': ins_data  # 6733 ins_data
            })
        if mail_type in ['UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER', 'UW_EXTRA_NON_SMOKER_TO_SMOKER']:
            mail_html = render_to_string('mailers/secure/latest_uw_mailer2.html', {
                'app': app,
                'premium_paid': premium_paid,  # 5842
                'revised_premium': revised_premium,  # 5842
                # 'premium_remain':float(revised_premium)-float(premium_paid), #5842
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'site_url': settings.SITE_URL,
                'current_time': datetime.datetime.now(),
                'ins_data': ins_data
            })
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
            # 5842-D

        if mail_type in ['UW_HEALTH_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/secure/latest_uw_mailer3.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                'ins_data': ins_data
            })
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type in ['UW_HEALTH_SMOKER_SA_RESTRICTION', 'UW_EXTRA_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/secure/latest_uw_mailer4.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                'ins_data': ins_data,
            })
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type == 'RIDER_DECLINE':
            mail_html = render_to_string('mailers/secure/rider_decline_mailer.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                'ins_data': ins_data,
                
            })
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
            # 5842-D
        if mail_type == 'APP_STATUS':
            mail_html1 = render_to_string('mailers/secure/latest_mail_app_status.html', {
                'app': app,
                'mail_type': mail_type,
                'site_url': settings.SITE_URL,
                'current_time': datetime.datetime.now()
            })
            mailer_header1 = render_to_string('mailers/secure/latest_mailer_header1.html',
                                              {'site_url': settings.SITE_URL})
            mailer_footer1 = render_to_string('mailers/secure/latest_mailer_footer.html',
                                              {'site_url': settings.SITE_URL})
            if mail_html1:
                mail_html1 = "%s%s%s" % (mailer_header1, mail_html1, mailer_footer1)
                send_html_mail(app, 'Your application/proposal number %s - %s' % (
                    app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html1, [app.email],
                               html_message=mail_html1, mail_type=mail_type)

        if mail_type == 'FUP_STATUS':
            TWENTYONE_DAYS = (datetime.datetime.today() - datetime.timedelta(days=21)).date()
            ZERO_DAYS = (datetime.datetime.today() - datetime.timedelta(days=0)).date()

            tests = [f.generated_on for f in app.fup_associated.all()]
            tests.sort()
            twentyone = ""
            zero = ""
            if tests[0] == TWENTYONE_DAYS:
                twentyone = "1"
            if tests[0] == ZERO_DAYS:
                zero = "1"

            mail_html = render_to_string('mailers/secure/mail_requirements.html', {
                'app': app,
                'revised_premium': revised_premium,
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'site_url': settings.SITE_URL,
                'open_fups': app.fup_associated.filter(received_on__isnull=True),
                'current_time': datetime.datetime.now(),
                'twentyone': twentyone,
                'zero': zero,
            })
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        mailer_header = render_to_string('mailers/secure/latest_mailer_header.html', {'site_url': settings.SITE_URL})
        mailer_footer = render_to_string('mailers/secure/latest_mailer_footer.html', {'site_url': settings.SITE_URL})
        if mail_html:
            mail_html = "%s%s%s" % (mailer_header, mail_html, mailer_footer)
            send_html_mail(app, 'Your application/proposal number %s - %s' % (
                app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html, [app.email],
                           html_message=mail_html,
                           mail_type=mail_type)

        if sms_txt:
            send_sms(app, app.mobile, sms_txt, mail_type)
            pass

    #  block insurer (Vision star)  new d2c 6733-phase2
    elif app.product_name == "VisionStar" or app.product_name == "WealthProtection" or app.product_name == "CancerShield" or app.product_name == "WealthSelf" or app.product_name == "WealthSpouse" or app.product_name == "WealthChild" or app.product_name == "CancerSelf" or app.product_name == "CancerSpouse" or app.product_name == "VisionSelf" or app.product_name == "VisionSpouse":
        if mail_type in ['UW_EXTRA_HEALTH']:
            mail_html = render_to_string('mailers/vision/latest_uw_mailer1.html', {
                'app': app,
                'premium_paid': premium_paid,  # 5842
                'revised_premium': revised_premium,  # 5842  
                'tracker_url': tracker_url,
                'mail_type': mail_type,
                'premium_difference_amount': float(app.premium_service_tax) - float(app.suspense_amount),
                'current_time': datetime.datetime.now(),
                'product_name': app.product_name,
            })
        if mail_type in ['UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER', 'UW_EXTRA_NON_SMOKER_TO_SMOKER']:
            mail_html = render_to_string('mailers/vision/latest_uw_mailer2.html', {
                'app': app,
                'premium_paid': premium_paid,  # 5842
                'revised_premium': revised_premium,  # 5842
                # 'premium_remain':float(revised_premium)-float(premium_paid), #5842
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'site_url': settings.SITE_URL,
                'current_time': datetime.datetime.now(),
                'product_name': app.product_name,
            })
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
            # 5842-D

        if mail_type in ['UW_HEALTH_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/vision/latest_uw_mailer3.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                'product_name': app.product_name,
            })
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type in ['UW_HEALTH_SMOKER_SA_RESTRICTION', 'UW_EXTRA_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/vision/latest_uw_mailer4.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                'product_name': app.product_name, 
            })
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type == 'RIDER_DECLINE':
            mail_html = render_to_string('mailers/vision/rider_decline_mailer.html', {
                'app': app,
                'premium_paid': premium_paid,
                'revised_premium': revised_premium,
                'premium_remain': float(revised_premium) - float(premium_paid),
                'mail_type': mail_type,
                'tracker_url': tracker_url,
                'current_time': datetime.datetime.now(),
                 'product_name': app.product_name,

            })
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type == 'APP_STATUS':
            mail_html1 = render_to_string('mailers/vision/latest_mail_app_status.html', {
                    'app': app,
                    'mail_type': mail_type,
                    'site_url': settings.SITE_URL,
                    'current_time': datetime.datetime.now(),
                    'product_name': app.product_name,
                    })
            mailer_header1 = render_to_string('mailers/vision/latest_mailer_header1.html',
                                              {'site_url': settings.SITE_URL})
            mailer_footer1 = render_to_string('mailers/vision/latest_mailer_footer.html',
                                              {'site_url': settings.SITE_URL})
            if mail_html1:
                mail_html1 = "%s%s%s" % (mailer_header1, mail_html1, mailer_footer1)
                send_html_mail(app, 'Your application/proposal number %s - %s' % (
                        app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html1, [app.email],
                               html_message=mail_html1, mail_type=mail_type)
        
        if mail_type == 'FUP_STATUS':
            TWENTYONE_DAYS = (datetime.datetime.today() - datetime.timedelta(days=21)).date()
            ZERO_DAYS = (datetime.datetime.today() - datetime.timedelta(days=0)).date()

            tests = [f.generated_on for f in app.fup_associated.all()]
            tests.sort()
            twentyone = ""
            zero = ""
            if tests[0] == TWENTYONE_DAYS:
                twentyone = "1"
            if tests[0] == ZERO_DAYS:
                    zero = "1"

            mail_html = render_to_string('mailers/vision/mail_requirements.html', {
                    'app': app,
                    'revised_premium': revised_premium,
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'site_url': settings.SITE_URL,
                    'open_fups': app.fup_associated.filter(received_on__isnull=True),
                    'current_time': datetime.datetime.now(),
                    'twentyone': twentyone,
                    'zero': zero,
                    'product_name': app.product_name,
                    })
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        mailer_header = render_to_string('mailers/vision/latest_mailer_header.html', {'site_url': settings.SITE_URL})
        mailer_footer = render_to_string('mailers/vision/latest_mailer_footer.html', {'site_url': settings.SITE_URL})
        if mail_html:
            mail_html = "%s%s%s" % (mailer_header, mail_html, mailer_footer)
            send_html_mail(app, 'Your application/proposal number %s - %s' % (
                    app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html, [app.email], html_message=mail_html,
                           mail_type=mail_type)

        if sms_txt:
            send_sms(app, app.mobile, sms_txt, mail_type)
            pass


    else:
        if mail_type in ['UW_EXTRA_HEALTH']:
            mail_html = render_to_string('mailers/latest_uw_mailer1.html', {
                    'app': app,
                    'premium_paid': premium_paid,  # 5842
                    'revised_premium': revised_premium,  # 5842
                    # 'premium_remain':float(revised_premium)-float(premium_paid), #5842
                    'tracker_url': tracker_url,
                    'mail_type': mail_type,
                    'premium_difference_amount': float(app.premium_service_tax) - float(app.suspense_amount),
                    'current_time': datetime.datetime.now(),
                    'ins_data': ins_data,  # 6733
                    })
        if mail_type in ['UW_EXTRA_HEALTH_NON_SMOKER_TO_SMOKER', 'UW_EXTRA_NON_SMOKER_TO_SMOKER']:
            mail_html = render_to_string('mailers/latest_uw_mailer2.html', {
                    'app': app,
                    'premium_paid': premium_paid,  # 5842
                    'revised_premium': revised_premium,  # 5842
                    # 'premium_remain':float(revised_premium)-float(premium_paid), #5842
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'site_url': settings.SITE_URL,
                    'current_time': datetime.datetime.now(),
                    'ins_data': ins_data,  # 6733
                    })
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
        # 5842-D

        if mail_type in ['UW_HEALTH_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/latest_uw_mailer3.html', {
                    'app': app,
                    'premium_paid': premium_paid,
                    'revised_premium': revised_premium,
                    'premium_remain': float(revised_premium) - float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'current_time': datetime.datetime.now(),
                    'ins_data': ins_data,  # 6733
                    })
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
            
        if mail_type in ['UW_HEALTH_SMOKER_SA_RESTRICTION', 'UW_EXTRA_SA_RESTRICTION']:
            mail_html = render_to_string('mailers/latest_uw_mailer4.html', {
                    'app': app,
                    'premium_paid': premium_paid,
                    'revised_premium': revised_premium,
                    'premium_remain': float(revised_premium) - float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'current_time': datetime.datetime.now(),
                    'ins_data': ins_data,  # 6733
                    })
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        if mail_type == 'RIDER_DECLINE':
            mail_html = render_to_string('mailers/rider_decline_mailer.html', {
                    'app': app,
                    'premium_paid': premium_paid,
                    'revised_premium': revised_premium,
                    'premium_remain': float(revised_premium) - float(premium_paid),
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'current_time': datetime.datetime.now(),
                    'ins_data': ins_data,  # 6733
                    
                    })
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app, 'mail_type': mail_type})
        # 5842-D
        if mail_type == 'APP_STATUS':
            mail_html1 = render_to_string('mailers/latest_mail_app_status.html', {
                    'app': app,
                    'mail_type': mail_type,
                    'site_url': settings.SITE_URL,
                    'current_time': datetime.datetime.now()
                    })
            mailer_header1 = render_to_string('mailers/latest_mailer_header1.html', {'site_url': settings.SITE_URL})
            mailer_footer1 = render_to_string('mailers/latest_mailer_footer.html', {'site_url': settings.SITE_URL})

            if mail_html1:
                mail_html1 = "%s%s%s" % (mailer_header1, mail_html1, mailer_footer1)
                send_html_mail(app, 'Your application/proposal number %s - %s' % (
                        app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html1, [app.email],
                               html_message=mail_html1, mail_type=mail_type)

        if mail_type == 'FUP_STATUS':
            TWENTYONE_DAYS = (datetime.datetime.today() - datetime.timedelta(days=21)).date()
            ZERO_DAYS = (datetime.datetime.today() - datetime.timedelta(days=0)).date()
            
            tests = [f.generated_on for f in app.fup_associated.all()]
            tests.sort()
            twentyone = ""
            zero = ""
            if tests[0] == TWENTYONE_DAYS:
                twentyone = "1"
            if tests[0] == ZERO_DAYS:
                    zero = "1"

            mail_html = render_to_string('mailers/mail_requirements.html', {
                    'app': app,
                    'revised_premium': revised_premium,
                    'mail_type': mail_type,
                    'tracker_url': tracker_url,
                    'site_url': settings.SITE_URL,
                    'open_fups': app.fup_associated.filter(received_on__isnull=True),
                    'current_time': datetime.datetime.now(),
                    'twentyone': twentyone,
                    'zero': zero,
                    'ins_data': ins_data  # 6733
                    })
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app, 'mail_type': mail_type})

        mailer_header = render_to_string('mailers/latest_mailer_header.html', {'site_url': settings.SITE_URL})
        mailer_footer = render_to_string('mailers/latest_mailer_footer.html', {'site_url': settings.SITE_URL})
        if mail_html:
            mail_html = "%s%s%s" % (mailer_header, mail_html, mailer_footer)
            send_html_mail(app, 'Your application/proposal number %s - %s' % (
                    app.app_id, datetime.datetime.today().strftime("%d/%m/%Y")), mail_html, [app.email], html_message=mail_html,
                           mail_type=mail_type)

        if sms_txt:
            send_sms(app, app.mobile, sms_txt, mail_type)
            pass
    return

def create_uhc_for_application(app):
    uhc_data = app.uhcdata_set.all()
    if uhc_data:
        uhc_data = uhc_data[0]
    else :
        uhc_data = UHCData(
            application = app,
            medicalappointment_location1 = app.medicalappointment_location1,
            medicalappointment_city1 = app.medicalappointment_city1,
            medicalappointment_center1 = app.medicalappointment_center1,
            medicalappointment_date1 = app.medicalappointment_date1,
            medicalappointment_time1 = app.medicalappointment_time1,
            medicalappointment_location2 = app.medicalappointment_location2,
            medicalappointment_city2 = app.medicalappointment_city2,
            medicalappointment_center2 = app.medicalappointment_center2,
            medicalappointment_time2 = app.medicalappointment_time2,
            medicalappointment_date2 = app.medicalappointment_date2,
        )
        uhc_data.save()
    return uhc_data

def format_application_form_data(data):
    """
    DATA.data>> {"app_id":"OA0000318","tracker_id":"","dob":"01091996","first_name":"Abhi","last_name":"jain","gender":"F","birth_state":"Andhra Pradesh","birth_city":"Adoni","marital_status":"Married","nationality":"Indian","father_name":"","education":"HSC","occupation":"Business","annual_income":"345645645645","pan_no":"","uid_no":"","employer_name":"sdfsd","business_nature":"dfgfdg","designation":"sdfds","duty_nature":"sdfds","years_withemployer":"16","months_withemployer":"11","email_id":"jain20@gmail.com","mobile_no":"9967679737","flat":"cvxc","building":"fsdfsdfs","road":"sdfds","area":"sdfds","landmark":"sdfds","state":"Assam","city":"Badarpur","landline":"4534534534543","pincode":"435434","p_flat":"cvxc","p_building":"fsdfsdfs","p_road":"sdfds","p_area":"sdfds","p_landmark":"sdfds","p_state":"Assam","p_city":"Badarpur","p_landline":"4534534534543","p_pincode":"435434","eia_number":"","ir_name":"","ir_emailid":"","nominee_title":"Ms.","nominee_first_name":"ssdfs","nominee_last_name":"sdfd","nominee_dob":"12082011","nominee_relationship":"Grand Father","appointee_title":"Mrs.","appointee_first_name":"sdfsdf","appointee_last_name":"sdfsd","appointee_dob":"06081996","appointee_relationship":"Grand Mother","insurance_purpose":"sdfsdfsdf","id_proof":"RATION CARD","address_proof":"LETTER FOM RECOGNISED PUBLIC AUTHORITY/SERVANT","income_proof":"Bank Cash-flows statements transactions not older then 6 months","politically_exposed":"Yes","politically_exposeddetails":"sdfsdfds34534","annual_premium":"8766237.36","pay_amount":"730519.78","sum_assured":"1342500000","pay_status":"","transaction_id":""}
    """
    map_dict = {
        'app_id': 'app_id',
        'tracker_id' : 'tracker_id',
        'tracker_details' : 'tracker_details',

        'salutation': 'salutaion',
        'first_name': 'first_name',
        'last_name': 'last_name',
        'gender': 'gender',
        'dob': 'dob',
        'marital_status': 'marital_status',
        'nationality': 'nationality',
        'education': 'education',
        'occupation': 'occupation',
        'org_type': 'business_nature',
        'designation': 'designation',
        'annual_income': 'annual_income',

        'father_name' : 'father_name',
        'pancard_number' : 'pan_no',
        'uid_number' : 'uid_no',

        'email': 'email_id',
        'mobile': 'mobile_no',
        'flat': 'flat',
        'building': 'building',
        'road': 'road',
        'area': 'area',
        'landmark' : 'landmark',
        'pincode' : 'pincode',
        'state' : 'state',
        'city' : 'city',
        'landline' : 'landline',

        'p_flat': 'p_flat',
        'p_building': 'p_building',
        'p_road': 'p_road',
        'p_area': 'p_area',
        'p_landmark' : 'p_landmark',
        'p_pincode' : 'p_pincode',
        'p_state' : 'p_state',
        'p_city' : 'p_city',
        'p_landline' : 'p_landline',

        "birth_state": "birth_state",
        "birth_city": "birth_city",
        "employer_name": "employer_name",
        "duty_nature": "duty_nature",
        "years_withemployer": "years_withemployer",
        "months_withemployer": "months_withemployer",

        "eia_number": "eia_number",
        "ir_name": "ir_name",
        "ir_email": "ir_emailid",

        'nominee_title': 'nominee_title',
        'nominee_first_name': 'nominee_first_name',
        'nominee_last_name': 'nominee_last_name',
        'nominee_dob': 'nominee_dob',
        'nominee_relationship': 'nominee_relationship',
        'appointee_title': 'appointee_title',
        'appointee_first_name': 'appointee_first_name',
        'appointee_last_name': 'appointee_last_name',
        'appointee_dob': 'appointee_dob',
        'appointee_relationship': 'appointee_relationship',
        'insurance_purpose': 'insurance_purpose',

        'politically_exposeddetails': 'politically_exposeddetails',
        'politically_exposed': 'politically_exposed',

        'sum_assured_website': 'sum_assured', #5842-D
        'sum_assured_option': 'saOption',
        'sum_assured_interval': 'saInterval',
        'policyterm_website':'term_period', #5842-D
        'sumassured_interval_website':'interval', #5842-D
        'sum_assured_option_website':'sumassured_type',  #5842-D
        'annual_premium': 'annual_premium',

        'photo_id_proof': 'id_proof',
        'address_proof': 'address_proof',
        'income_proof': 'income_proof',
        
        'pay_amount': 'pay_amount',
        'payment_status': 'pay_status',
        'transaction_id': 'transaction_id',
        'transaction_end_time':'transaction_end_time',
        'pay_type':'pay_type',
        'page_name': 'page_name',

        'medicalappointment_center2': 'medicalappointment_center2',
        'medicalappointment_city1': 'medicalappointment_city1',
        'medicalappointment_center1': 'medicalappointment_center1',
        'medicalappointment_city2': 'medicalappointment_city2',
        'medicalappointment_location2': 'medicalappointment_location2',
        'medicalappointment_time1': 'medicalappointment_time1',
        'medicalappointment_time2': 'medicalappointment_time2',
        'medicalappointment_location1': 'medicalappointment_location1',
        'medicalappointment_date1': 'medicalappointment_date1',
        'medicalappointment_date2': 'medicalappointment_date2',
        
        'photo_id_proof_rcvd':'id_proof_upload',
        'address_proof_rcvd':'address_proof_upload',
        'income_proof_rcvd':'income_proof_upload',
        'age_proof_rcvd': 'age_proof_upload',

        'photo_id_proof_rcvd_date':'id_proof_rdate',
        'address_proof_rcvd_date':'address_proof_rdate',
        'income_proof_rcvd_date':'income_proof_rdate',
        'age_proof_rcvd_date':'age_proof_rdate',
        'online_created_date':'online_created_date',
        'accidentaldeath': 'accidentaldeath', # 5842-D start                                                                              
        'criticalillness': 'criticalillness',
        'hospitalcareillness': 'hospitalcareillness',
        'surgicalcare': 'surgicalcare',
        'accidentaldeathpre': 'accidentaldeathpre',
        'criticalillnesspre': 'criticalillnesspre',
        'hospitalcareillnesspre': 'hospitalcareillnesspre',
        'surgicalcarepre': 'surgicalcarepre',
        'riderdisc': 'riderdisc', # 5842-D end ######  
        'accidentalDeathAndBenefitPlus': 'accidentalDeathAndBenefitPlus',  #new rider added accidental death 26 sept      
        'accidentalDeathAndBenefitPlusPre': 'accidentalDeathAndBenefitPlusPre',
        'waiverofPremium': 'waiverofPremium',                     # 6733 wop rider 
        'waiverofPremiumpre': 'waiverofPremiumpre',  # 6733 new rider premium
        'age_proof': 'age_proof', # 6733 age proof create batch data 
        }
    

    """
    extra_fields = [
    'diabetes_eyeabnormality',
    'suffered_chestpain',
    'weight',
    'bp_consumetobacco',
    'diabetes_heartdisease',
    'diabetes_highbp',
    'physician_firstname',
    'diabetes_hospitalized',
    'diabetes_electrocardiogram',
    'diabetes_cigarettessmoked',
    'suffered_albumin',
    'diabetes_doctorname',
    'bp_complications',
    'bp_firstnoticed',
    'medicalquestion_details',
    'bp_investigatedhypertension_details',
    'bp_treatmentdiscontinued',
    'bp_sufferdiabetes',
    'chestpain_bloodpressure',
    'consumed_narcotic',
    'familymedicalhistory_details',
    'diabetes_albumin',
    'bp_treatmentdiscontinued_details',
    'job_hazardous',
    'weightchange_details',
    'physician_lastname',
    'travel_outside',
    'diabetes_weightatdiagnosis',
    'any_medical_advice',
    'diabetes_bloodsugarmeasurements',
    'remained_absent',
    'bp_consumetobacco_details',
    'suffered_ulcer',
    'bp_regulartreatment_details',
    'physician_email',
    'chestpain_heartmurmur',
    'diabetes_datediagnosed',
    'suffered_diabetic',
    'diabetes_hospitalized_details',
    'height_inches',
    'diabetes_type',
    'prior_illness',
    'physician_mobile',
    'suffered_cancer',
    'diabetes_weightloss',
    'bp_investigatedhypertension',
    'surgical_operation',
    'prior_illnessdetails',
    'diabetescontrol_details',
    'chestpain_heartattack',
    'weight_change',
    'diabetes_weightloss_details',
    'recent_bplevel',
    'arthritis',
    'any_gynaecological',
    'diabetes_control',
    'physician_officenumber',
    'height_feet',
    'suffered_asthma',
    'chestpain_chestpain',
    'pregnant',
    'consumed_alcohol',
    'any_complaints_not_consulted',
    'chestpain_highcholesterol',
    'any_physical_defects',
    'diabetes_cigarettessmoked_details',
    'diabetes_kidneyproblem',
    'pregnant_details',
    'diabetessugarmeasurement',
    'diabetes_doctorlastseen',
    'dizziness',
    'bp_regulartreatment',
    'bp_level'
    ]"""

    reverse_map_dict = dict([(v,k) for k,v in map_dict.items()])
    ndata = {}
    ndata['extra'] = {}
    for k,v in data.items():
        if k in reverse_map_dict.keys():
            ndata[reverse_map_dict[k]] = v
        else:
            ndata['extra'].update({k:v})

    if ndata.get('dob'):
        ndata['dob'] = datetime.datetime.strptime(ndata['dob'], '%d%m%Y')
    if ndata.get('appointee_dob'):
        ndata['appointee_dob'] = datetime.datetime.strptime(ndata['appointee_dob'], '%d%m%Y')
    if ndata.get('nominee_dob'):
        ndata['nominee_dob'] = datetime.datetime.strptime(ndata['nominee_dob'], '%d%m%Y')
    if ndata.get('created_on'):
        ndata['created_on'] = datetime.datetime.strptime(ndata['created_on'], '%d%m%Y%H%M%S')
    print "transaction end time",ndata.get('transaction_end_time')
    if ndata.get('transaction_end_time'):
        ndata['transaction_end_time'] = datetime.datetime.strptime(ndata['transaction_end_time'], '%d%m%Y')
    if ndata.get('online_created_date'):# 14 may                          
        ndata['online_created_date'] = datetime.datetime.strftime(datetime.datetime.strptime(ndata['online_created_date'],'%m%d%Y %H:%M:%S'),'%Y-%m-%d %H:%M:%S')
   
   
        
    # if ndata.get('photo_id_proof_rcvd_date'):
    #     ndata['photo_id_proof_rcvd_date'] = datetime.datetime.strptime(ndata['photo_id_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('address_proof_rcvd_date'):
    #     ndata['address_proof_rcvd_date'] = datetime.datetime.strptime(ndata['address_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('age_proof_rcvd_date'):
    #     ndata['age_proof_rcvd_date'] = datetime.datetime.strptime(ndata['age_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('income_proof_rcvd_date'):
    #     ndata['income_proof_rcvd_date'] = datetime.datetime.strptime(ndata['income_proof_rcvd_date'], '%d%m%Y')

    ndata['extra'] = simplejson.dumps(ndata['extra'])

    ndata['photo_id_proof'] = ndata['photo_id_proof'].lower()
    ndata['address_proof'] = ndata['address_proof'].lower()
    ndata['income_proof'] = ndata['income_proof'].lower()
    # to move to prdctn
    ndata['photo_id_proof_rcvd'] = ndata['photo_id_proof_rcvd'].lower()
    ndata['address_proof_rcvd'] = ndata['address_proof_rcvd'].lower()
    ndata['income_proof_rcvd'] = ndata['income_proof_rcvd'].lower()
    ndata['age_proof_rcvd'] = ndata['age_proof_rcvd'].lower()
    
    return ndata

def format_date(mdate, dformat='%Y-%m-%d'):
    if mdate.strip():
        mdate = datetime.datetime.strptime(mdate, dformat)
    else:
        mdate = None
    return mdate

def send_customer_sms(app_id, message_code, data=None):
    app = Application.objects.get(app_id=app_id)
    if message_code in ['MedicalReminder', 'DocumentReminder']:

        # new D2c  Infy Send SMS Logic - project ID - 266 / 293 / 6733 

        if app.product_name == "":
            sms_txt = render_to_string('mailers/sms_reminders.txt', {'app': app})

        elif app.product_name == "ProtectSelf" or app.product_name == "JointLIfe":
            sms_txt = render_to_string('mailers/joint/sms_reminders.txt', {'app': app})

        elif app.product_name == "SecureSelf" or app.product_name == "SecureChild" or app.product_name == "SecureSpouse":
            sms_txt = render_to_string('mailers/secure/sms_reminders.txt', {'app': app})

        elif app.product_name == "VisionSelf" or app.product_name == "VisionSpouse" or app.product_name == "CancerSelf" or  app.product_name == "CancerSpouse" or app.product_name == "WealthSelf" or  app.product_name == "WealthSpouse" or app.product_name == "WealthChild":
            sms_txt = render_to_string('mailers/vision/sms_reminders.txt', {'app': app})                   
            


    send_sms(app, app.mobile, sms_txt, message_code)
    return

def workload_calculator():
    applications_for_the_day = ApplicationCallAttribute.objects.filter(next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), call_barred=False,is_taken=False
    )
    bucket = {}
    for apca in applications_for_the_day:
        b = apca.last_call_status
        #if b == 'V' and apca.application.fup_associated.all()
        if b in bucket.keys():
            bucket[b] += 1
        else:
            bucket[b] = 1

    f = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='F', call_barred=False,is_taken=False).distinct().count()
    vc = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='V', call_barred=False, application__fup_associated__isnull = False,is_taken=False).distinct().count()

    ti = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='TI', call_barred=False,is_taken=False).exclude(application__app_status = 'PS').distinct().count()

    w = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='W', call_barred=False, application__fup_associated__isnull = False,is_taken=False).distinct().count()
    wv = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='WV', call_barred=False,is_taken=False).distinct().count()
    r = ApplicationCallAttribute.objects.filter( next_calltime__lte=datetime.datetime.combine(datetime.date.today(),datetime.time.max), last_call_status='R', call_barred=False,is_taken=False).distinct().count()

    return bucket, vc, ti, w, wv, r, f

#TODO: Consecutive Dispositions on NON-CONTACTABLE more than 6 times, never call again
def save_call_disposition(call, call_form, request):
    app = call.application
    ap_callattr = app.applicationcallattribute

    #Saving Call Information
    call.disposition = request.POST['disposition']
    if request.POST.get('auto_notes'):
        call.predefined_remark = request.POST['auto_notes']
    if request.POST.get('notes'):
        call.remarks = request.POST['notes']

    #Saving Application Attributes
    app_attribute_direct_save = {'courier_date':'courier_date', 'fup_commited_date':'fup_commited_date', 'document_commited_date':'document_commited_date', 'photo_id_proof':'photo_id_proof', 'age_proof':'age_proof', 'address_proof':'address_proof', 'income_proof':'income_proof', 'attested_photograph':'attested_photograph', 'address1':'address1','document_delivery_method':'document_delivery_method'}
    for attr,model_attr in app_attribute_direct_save.items():
        if call_form.cleaned_data.get(attr):
            setattr(ap_callattr, model_attr, call_form.cleaned_data[attr])

    if request.POST.getlist('time_band'):
        ap_callattr.courier_time = ",".join(request.POST.getlist('time_band'))

    next_calltime = None
    if call_form.cleaned_data.get('later_time'):
        next_calltime = call_form.cleaned_data['later_time']

    disposition = request.POST['disposition']
    dp = Disposition()

    if request.POST.get('auto_notes') == "DA_NOT_ASSIGNED" and call.call_type in ['WV', 'V']:
        disposition = "CALLBACK"
        next_calltime = datetime.datetime.now() + datetime.timedelta(hours=24)

    if request.POST.get('auto_notes') == "THIRD_PARTY_DECLINE":
        disposition = "DO_NOT_CALL"

    dispose_call = getattr(dp, "dispose_%s" % disposition)
    dispose_call(call, ap_callattr, next_calltime, request)

    ap_callattr.is_taken = False
    call.save()
    ap_callattr.save()
    
fresh_next_calltime = datetime.timedelta(hours=3)
w_next_calltime = datetime.timedelta(hours=24)
wv_next_calltime = datetime.timedelta(days=7)
r_next_calltime = datetime.timedelta(days=7)
ti_next_calltime = datetime.timedelta(days=2)

#fresh_next_calltime = datetime.timedelta(minutes=2)
#w_next_calltime = datetime.timedelta(minutes=3)
#wv_next_calltime = datetime.timedelta(minutes=5)
#r_next_calltime = datetime.timedelta(minutes=3)
#ti_next_calltime = datetime.timedelta(minutes=2)

class Disposition(object):
    pass

    def dispose_SUCCESS(self, call, ap_callattr, next_calltime, request):
        new_next_calltime = None
        if call.call_type == 'W':
            new_next_calltime = datetime.datetime.now() + w_next_calltime

        if call.call_type in ['WV','V']:
            new_next_calltime = datetime.datetime.now() + wv_next_calltime

        if call.call_type == 'R':
            new_next_calltime = datetime.datetime.now() + r_next_calltime

        if next_calltime:
            ap_callattr.next_calltime = next_calltime
        else:
            if not new_next_calltime:
                new_next_calltime = datetime.datetime.now() + ti_next_calltime #Works for TI
            ap_callattr.next_calltime = new_next_calltime

        if call.call_type == 'TF':
            if ap_callattr.app_status in ['PO','WD','FL','DC', 'XX', 'RJ']: #TODO: add "IF", for all ISSUED call to TF-AUTO
                call.call_type = 'TF-AUTO'
            ap_callattr.call_barred = True #Never call again a TF call disposed successfully

        ap_callattr.is_call_later = False
        call.is_call_later = False
        ap_callattr.last_call_status = call.call_type

    def dispose_CALLBACK(self, call, ap_callattr, next_calltime, request):
        ap_callattr.is_call_later = True
        call.is_call_later = True
        
        if not next_calltime:
            next_calltime = datetime.datetime.now() + fresh_next_calltime

        call.next_calltime = next_calltime
        ap_callattr.next_calltime = next_calltime

    def dispose_NONCONTACTABLE(self, call, ap_callattr, next_calltime, request):
        ap_callattr.is_call_later = False
        call.is_call_later = False
        next_calltime = datetime.datetime.now() + fresh_next_calltime
        call.next_calltime = next_calltime
        ap_callattr.next_calltime = next_calltime

    def dispose_CALL_DROPPED(self, call, ap_callattr, next_calltime, request):
        self.dispose_NONCONTACTABLE(call, ap_callattr, next_calltime, request)

    def dispose_RINGING(self, call, ap_callattr, next_calltime, request):
        self.dispose_NONCONTACTABLE(call, ap_callattr, next_calltime, request)

    def dispose_BUSY(self, call, ap_callattr, next_calltime, request):
        self.dispose_NONCONTACTABLE(call, ap_callattr, next_calltime, request)

    def dispose_UNREACHABLE(self, call, ap_callattr, next_calltime, request):
        self.dispose_NONCONTACTABLE(call, ap_callattr, next_calltime, request)

    def dispose_DO_NOT_CALL(self, call, ap_callattr, next_calltime, request):
        ap_callattr.is_call_later = False
        call.is_call_later = False
        ap_callattr.call_barred = True

class CallCannotBePicked(Exception):
    def __init__(self):
        pass

    def __str__(self):
        return "Call Cannot be picked."

def get_next_call_history_object(request, ap_callattr, next_call_forced_type = None):
    if next_call_forced_type:
        next_call_type = next_call_forced_type
    else:
        if ap_callattr.is_call_later:
            #next_call_type = ap_callattr.last_call_status  Buggy ?
            next_call_type = ap_callattr.application.callhistory_set.order_by('-created_on')[0].call_type
        else:
            next_call_type = call_stages[ap_callattr.last_call_status] #Progress the call to next stage

    #Overriding logic for all types of calls
    fups = FupAssociated.objects.filter(application=ap_callattr.application)
    openfups = FupAssociated.objects.filter(application=ap_callattr.application, received_on__isnull=True)

    if ap_callattr.last_call_status in ['F','W','WV','V','R'] and not openfups and fups:
        next_call_type = 'TI'

    if ap_callattr.app_status in ['IF','DC','WD','FL','PO', 'XX', 'RJ']:
        next_call_type = 'TF'

    c = CallHistory(
        application=ap_callattr.application,
        call_type=next_call_type,
        assigned_to=request.user,
    )
    ap_callattr.is_taken = True
    ap_callattr.last_call_status = next_call_type
    ap_callattr.assigned_to = request.user
    ap_callattr.save()
    c.save()
    return c

def get_call_record_for_application(request, ap_callattr):
    if ap_callattr.is_call_later:
        ctype = 'call_later'
    else:
        ctype = status_call_map[ap_callattr.last_call_status]
    cp = CallPreference()
    func = getattr(cp, "next_%s" % ctype)
    call_history = func(request, ap_callattr)
    return call_history

def get_call_record(request):
    exception_call = True
    print 'Get_Call_Records'
    while exception_call:
        ap_callattr = None
        update_count = 0
        while update_count == 0:
            ctype, ap_callattr = try_call_records(request)
            if not ap_callattr: return None # Calls Exhausted
            if ctype == 'dirty_call' and ap_callattr: break
            update_count = ApplicationCallAttribute.objects.filter(id=ap_callattr.id, is_taken=False).update(is_taken=True, assigned_to=request.user)
            #print "Update Count", update_count
            #print "App Attribute", ap_callattr
        cp = CallPreference()
        func = getattr(cp, "next_%s" % ctype)
        call_history = func(request, ap_callattr)

        #exception case handler for TF calls, auto dispose if app_status in ['WD','PO','FL','DC', 'XX', 'RJ']
        if ap_callattr.app_status in ['WD','PO','FL','DC', 'XX', 'RJ']: #Add "IF" to the list if you want to dispose "IF" automatically
            exception_call = True
            dp = Disposition()
            dp.dispose_SUCCESS(call_history, ap_callattr, None, request)
            ap_callattr.is_taken = False
            call_history.save()
            ap_callattr.save()
        else:
            exception_call = False

    return call_history

def try_call_records(request):
    u = request.user
    ap_callattr = None
    cp = CallPreference()
    ctype, ap_callattr = cp.call_dirty_call(request)
    if ap_callattr:
        return 'dirty_call', ap_callattr

    cpriority = CallPriority.objects.all()[0]
    ctp = dict([("call_%s" % f.name, getattr(cpriority,f.name)) for f in cpriority._meta.fields[1:]])
    while (not ap_callattr) and ctp:
        choice_list = []
        for k,v in ctp.items():
            for i in range(v):
                choice_list.append(k)
        if not choice_list:
            break
        call_type = random.choice(choice_list)
        func = getattr(cp, call_type)
        ctype, ap_callattr = func(request)
        print "********"
        print ctp
        print call_type
        print ap_callattr
        print "********"
        if not ap_callattr:
            ctp.pop(call_type)

    return ctype, ap_callattr

PICK_NUM = 100
status_call_map = {
    'F': 'fresh',
    'W': 'welcome',
    'WV': 'welcome_and_verification',
    'V': 'verification',
    'R': 'reminder',
    'TI': 'thankinprogress',
    'TF': 'thanksyoufinal',
}
class CallPreference(object):
    pass

    def call_dirty_call(self,request):
        #Bucket 1a : Already assigned and dirty call
        ap_callattrs = ApplicationCallAttribute.objects.filter(is_taken = True, assigned_to = request.user)
        for a in ap_callattrs: # Exception case, rare possibility of call barred by still dirty
            if a.call_barred:
                a.is_taken = False
                a.save()
        if ap_callattrs:
            return 'dirty_call', ap_callattrs[0]
        else:
            return None,None

    def next_dirty_call(self, request, ap_callattr):
        #TODO: Check for possibility of no call history existing even if is_taken is true for call attribute
        call_history = ap_callattr.application.callhistory_set.order_by('-created_on')
        return call_history[0]

    def call_call_later(self, request):
        #Bucket 1b : Call Later Calls
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            is_call_later = True,
            next_calltime__lte = datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'call_later', ap_callattrs[0]
        else:
            return None,None

    def next_call_later(self, request, ap_callattr):
        app = ap_callattr.application
        fups = FupAssociated.objects.filter(application=ap_callattr.application)
        openfups = FupAssociated.objects.filter(application=ap_callattr.application, received_on__isnull=True)

        #If application is in fresh state, the call_later logic is like next_fresh call
        if ap_callattr.last_call_status == 'F':
            return self.next_fresh(request, ap_callattr)

        elif ap_callattr.last_call_status == 'W' and fups:
            call = get_next_call_history_object(request, ap_callattr, 'V')

        else:
            call = get_next_call_history_object(request, ap_callattr)
        return call

    def call_fresh(self, request):
        #Bucket 2a : Fresh Calls, FUP open/not-assigned
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            last_call_status='F',
            is_taken = False,
            call_barred=False,
            next_calltime__lte=datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:PICK_NUM]
        if not ap_callattrs:
            ap_callattrs = ApplicationCallAttribute.objects.filter(
                last_call_status='F',
                is_taken = False,
                call_barred=False,
                next_calltime__lte=datetime.datetime.now(),
                assigned_to__isnull = True, 
            ).order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'fresh', ap_callattrs[0]
        else:
            return None,None

    def next_fresh(self, request, ap_callattr):
        app = ap_callattr.application
        if app.fup_associated.all():
            call_type = 'WV'
        else:
            call_type = 'W'

        call = get_next_call_history_object(request, ap_callattr, call_type)
        return call

    def call_welcome(self, request):
        #Bucket 2b : Welcome Calls Done, FUP open
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            last_call_status = 'W',
            application__fup_associated__isnull=False,
            next_calltime__lte=datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'welcome', ap_callattrs[0]
        else:
            return None,None

    def next_welcome(self, request, ap_callattr):
        call = get_next_call_history_object(request, ap_callattr)
        return call

    def call_welcome_and_verification(self, request):
        #Bucket 2c : Welcome+Verfication Calls Done, FUP open
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            last_call_status='WV',
            next_calltime__lte=datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:10]
        if ap_callattrs:
            return 'welcome_and_verification', ap_callattrs[0]
        else:
            return None,None

    def next_welcome_and_verification(self, request, ap_callattr):
        call = get_next_call_history_object(request, ap_callattr)
        return call

    def call_verification(self, request):
        #Bucket 2d : Verfication Calls Done, FUP open
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            last_call_status='V',
            next_calltime__lte=datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'verification', ap_callattrs[0]
        else:
            return None,None

    def next_verification(self, request, ap_callattr):
        call = get_next_call_history_object(request, ap_callattr)
        return call

    def call_reminder(self, request):
        #Bucket 2e : Reminder Calls Done, FUP open
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            last_call_status='R',
            next_calltime__lte=datetime.datetime.now(),
            assigned_to = request.user,
        ).order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'reminder', ap_callattrs[0]
        else:
            return None,None

    def next_reminder(self, request, ap_callattr):
        call = get_next_call_history_object(request, ap_callattr)
        return call

    def call_thankinprogress(self, request):
        #Bucket 2f : FUP closed, Call in proposal bucket
        ap_callattrs = ApplicationCallAttribute.objects.filter(
            is_taken = False,
            call_barred = False,
            last_call_status = 'TI',
            assigned_to = request.user,
            next_calltime__lte=datetime.datetime.now()).filter(
            Q(
                app_status__in=['IF','DC','WD', 'FL','PO', 'XX', 'RJ']
            ) | Q(
                application__fup_associated__isnull=False
            ) & Q(
                application__fup_associated__received_on__isnull=True
            )
            ).distinct().order_by('next_calltime')[:PICK_NUM]
        if ap_callattrs:
            return 'thankinprogress', ap_callattrs[0]
        else:
            return None,None

    def next_thankinprogress(self, request, ap_callattr):
        print "tI",ap_callattr
        openfups = FupAssociated.objects.filter(application=ap_callattr.application, received_on__isnull=True)
        if openfups:
            call = get_next_call_history_object(request, ap_callattr, 'R') #AMR
        else:
            call = get_next_call_history_object(request, ap_callattr, 'TF')
        return call

ftype = {'CharField':unicode, 'TextField':unicode, 'IntegerField':int, 'FloatField':float}
def set_model_values(model, obj_dict, keys):
    save_obj = False
    #print "--------"
    for i in keys:
        #cast to make sure that obj_dict value and model value are of same type
        cast = ftype.get(model._meta.get_field_by_name(i)[0].__class__.__name__, None)
        if cast:
            value = cast(obj_dict[i])
        else:
            value = obj_dict[i]
        if getattr(model, i) == value:
            if not save_obj:save_obj = False
        else:
            #print "=>", model,getattr(model, i), i , value
            setattr(model, i, value)
            save_obj = True
    if save_obj:
        #print "SAVING .... model:", model
        #from IPython import Shell
        #Shell.IPShellEmbed()()
        model.save()
    return save_obj, model

def save_uhc_data(file_contents):
    import_wb = xlrd.open_workbook(file_contents=file_contents)
    import_sheet = import_wb.sheet_by_index(0)
    uhc_updated = 0
    uhc_added = 0
    objects_error = 0
    error_dump = []

    for rx in range(1, import_sheet.nrows):
        try:
        #if True:
            object_value_dict = {}
            model_cell_value = None
            for cx in range(0, import_sheet.ncols):
                if cx in uhc_field_reverse_map.keys():
                    fname = uhc_field_reverse_map[cx]
                    cell_value = import_sheet.cell_value(rowx=rx, colx=cx)
                    if fname == 'app_id':
                        print cell_value.strip()
                        object_value_dict['application'] = Application.objects.get(app_id = cell_value.strip())
                        continue

                    f = UHCData._meta.get_field_by_name(fname)[0]
                    if f.__class__.__name__ == "DateTimeField":
                        if cell_value:
                            time_format = "%Y-%m-%d %H:%M:%S"
                            print cell_value
                            model_cell_value = datetime.datetime.fromtimestamp(time.mktime(time.strptime(cell_value, time_format)))
                        else:
                            model_cell_value = None
                    elif f.__class__.__name__ == "DateField":
                        if cell_value:
                            date_format = "%Y-%m-%d"
                            print cell_value
                            model_cell_value = datetime.datetime.fromtimestamp(time.mktime(time.strptime(cell_value, date_format)))
                        else:
                            model_cell_value = None
                    else:
                        model_cell_value = cell_value
                    if fname == 'app_id':
                        object_value_dict['application'] = Application.object_value_dict.get(app_id = model_cell_value)
                    else:
                        object_value_dict[fname] = model_cell_value

            if object_value_dict.get('application', 0):
                alluhc = UHCData.objects.filter(application = object_value_dict['application'])
                if alluhc:
                    uhc = alluhc[0]
                    is_saved, uhc = set_model_values(uhc, object_value_dict, ['first_call_on', 'remarks1', 'second_call_on','remarks2','third_call_on', 'remarks3','path_appt_date','path_appt_time','path_test_name','path_dc_name','tmt_appt_date','tmt_appt_time','tmt_test_name','tmt_dc_name','last_call_status','final_status'])
                    if is_saved: uhc_updated+=1
                else:
                    uhc = UHCData(**object_value_dict).save()
                    uhc_added+=1
                    print uhc


        except Exception,e:
        #else:
            objects_error += 1
            print e
            print "+++++++++++++++++++++++++++++++++++++"
            error_dump.append([rx, cx, object_value_dict.get('app_id'), str(e)])
    return uhc_added, uhc_updated, objects_error, error_dump

def sum_dict(dict1, dict2, params):
    sumd = {}
    for p in params:
        sumd[p] = dict1.get(p,0) + dict2.get(p,0)
    return sumd

def per_dict(dict1, dict2, params):
    perd = {}
    for p in params:
        if dict2.get(p,1.0)== 0:
            deno = 1
        else:
            deno = float(dict2.get(p,1.0))
        perd[p] = "%.2f"%((float(dict1.get(p,0)) / deno)*100)
    return perd

def multiply_dict(dict1, facto, params):
    multid = {}
    for p in params:
        multid[p] = dict1.get(p,0) * facto
    return multid

def get_plan(value):
    v = value.split('_')[0]
    p = list(Plan.objects.filter(code=v))
    if len(p) < 1:
        return "-unknown-"
    else:
        return p[0].name

def get_verbose_status(app):
    try:
        uhc = app.uhcdata
        uhc_final_status = uhc.final_status
    except:
        uhc_final_status = "----------"

    apca = app.applicationcallattribute

    NRL = NOT_REQUIRED_LIST = ['','NR',False]
    courier_docs_rcvd = (apca.photo_id_proof_rcvd_date or apca.photo_id_proof in NRL) and (apca.age_proof_rcvd_date or apca.age_proof in NRL) and (apca.address_proof_rcvd_date or apca.address_proof in NRL) and (apca.income_proof_rcvd_date or apca.income_proof in NRL) and (apca.attested_photograph_rcvd_date or apca.attested_photograph in NRL)

    if app.app_status == '':
        courier_docs_rcvd = "----------"
    elif app.app_status != 'PS':
        courier_docs_rcvd = "Documents Received"
    else:
        if courier_docs_rcvd:
            courier_docs_rcvd = "Documents Received"
        else:
            courier_docs_rcvd = "Awaiting Documents"

    doc_final_jet_decision = [fa.jet_decision for fa in app.fup_associated.filter(Q(code__is_medical=False) & ~Q(code__name__in=INTERNAL_FUP_LIST)).order_by('-generated_on')]
    if len(doc_final_jet_decision) > 0:
        if app.fup_associated.filter(Q(code__is_medical=False, received_on__isnull=True) & ~Q(code__name__in=INTERNAL_FUP_LIST)).count() == 0:
            doc_final_jet_decision = "R"
        else:
            doc_final_jet_decision = doc_final_jet_decision[0]
            if doc_final_jet_decision == "XS" and len(set([fa.generated_on for fa in app.fup_associated.filter(Q(code__is_medical=False) & ~Q(code__name__in=INTERNAL_FUP_LIST)).order_by('-generated_on')])) > 1:
                doc_final_jet_decision = "EXS"
    else:
        doc_final_jet_decision = "F"

    if doc_final_jet_decision in ['F', 'R', 'XS', 'EXS']:
        med_final_jet_decision = [fa.jet_decision for fa in app.fup_associated.filter(code__is_medical=True).order_by('-generated_on')]
        if len(med_final_jet_decision) > 0:
            if app.fup_associated.filter(code__is_medical=True, received_on__isnull=True).count() == 0:
                med_final_jet_decision = "R"
            else:
                med_final_jet_decision = med_final_jet_decision[0]
                if med_final_jet_decision == "XS" and len(set([fa.generated_on for fa in app.fup_associated.filter(code__is_medical=True).order_by('-generated_on')])) > 1:
                    med_final_jet_decision = "EXS"
        else:
            med_final_jet_decision = "F"

    else:
        med_final_jet_decision = ""


    final_jet_decision = "%s-%s" % (doc_final_jet_decision, med_final_jet_decision)

    jet_verbose = {
        "F-F" : "Thank you for your Payment. We will get back to you within 72 hours",
        "F-R" : "Thank you for completing your medical examination. We have received your medical reports and will get back to you within 72 hours",
        "F-XS" : "Your initial medical examination is awaited.",
        "F-EXS" : "Post reviewing your medical reports, additional medical examination is requested. The details have been mailed to you",

        "R-F" : "We have received the documents your sent. Thank you. We will get back to you, if required",
        "R-R" : "We have received  your documents and medical reports",
        "R-XS" : "We have received your documents, however, the medical examination report is awaited. Request you to complete the medical examination at the earliest",
        "R-EXS" : "We have received your documents, additional medical examination is requested. The details have been mailed to you",

        "XS-F" : "The initial documents requested, are awaited. Request you to mail the same on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a> at the earliest",
        "XS-R" : "The initial documents requested, are still awaited. Thank you for completing your medical examination",
        "XS-XS" : "The initial documents requested, are awaited. Request you to mail the same on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a> at the earliest. We also request you to complete your medical examination, to further process your application",
        "XS-EXS" : "The initial documents requested, are still awaited. Post reviewing your medical reports, additional medical examination is requested. The details have been mailed to you",

        "EXS-F" : "We have received the documents you sent, however we request you to send additional documents, as mentioned below on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a> Thank you",
        "EXS-R" : "We have received the documents you sent, however we request you to send additional documents, as mentioned below on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a>, Thank you for completing your medical examination",
        "EXS-XS" : "We have received the documents your sent, however we request you to send additional documents, as mentioned below, on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a>. Also the medical examination report is awaited. Request you to complete the medical examination at the earliest",
        "EXS-EXS" : "We have received the documents you sent, however we request you to send additional documents, as mentioned below, on <a href='mailto:buyonline@iciciprulife.com'>buyonline@iciciprulife.com</a>. Also based on the medical reports received, additional medical examination is requested. The details have been mailed to you.",

        "XX-" : "Awaiting counter offer acceptance. Awaiting a confirmation on the mail sent to you",
        "DC-" : "Application has been declined",
        "PO-" : "Application has been postponed",
        "AS-" : "Application has been reviewed and will be issued within the next 72 hours",
        "BS-" : "Application has been reviewed and will be issued within the next 72 hours",
        "BS1-" : "Application has been reviewed and will be issued within the next 72 hours",
        "BS2-" : "Application has been reviewed and will be issued within the next 72 hours",
        "J1-" : "Application has been reviewed and will be issued within the next 72 hours",
        "J2-" : "Application has been reviewed and will be issued within the next 72 hours",
        "AX-" : "Post reviewing your medicals and documents submitted, extra premium for applied sum assured is requested. Details have been mailed to you. You can also click <a href='http://iciciprulife.com/payFirstPremium.do' target='_blank'>here</a> to proceed for the payment",
    }

    verbose_app_status = {
        "PO" : "Application has been postponed",
        'WD' : "Application has been withdrawn",
        'FL' : "Your request for cancellation of application is under process",
        'IF' : "Congratulations your application has been issued",
        "DC" : "Application has been declined",
        "XX" : "Application has been declined",
    }

    issued_status = False
    if final_jet_decision.split('-')[1] == "": issued_status = True

    if app.app_status in verbose_app_status.keys():
        current_policy_status = verbose_app_status[app.app_status]
    else:
        current_policy_status = jet_verbose.get(final_jet_decision,'Documents Pending')

    return {'document_status': courier_docs_rcvd, 'medical_test':uhc_final_status, 'current_policy_status': current_policy_status, 'issued_status':issued_status, 'final_jet_decision' : final_jet_decision }

def reconcile_with_lms(app_list):
    dbcon = MySQLdb.connect(host=settings.LMS_HOST, user=settings.LMS_USER, passwd=settings.LMS_PASSWORD, db=settings.LMS_NAME)
    cur = dbcon.cursor()
    for app in app_list:
        cur.execute("UPDATE core_campaigndata INNER JOIN core_customer ON core_campaigndata.customer_id=core_customer.id SET in_emerge=1, in_emerge_status='MOBILE', emerge_transaction_end_time='%s' WHERE core_customer.mobile='%s';" % (app.created_on.strftime("%Y-%m-%d %H:%M:%S"), app.mobile))
        cur.execute("UPDATE core_campaigndata SET in_emerge=1, in_emerge_status='APPID', emerge_transaction_end_time='%s' WHERE application_id='%s';" % (app.created_on.strftime("%Y-%m-%d %H:%M:%S"), app.app_id))
        print "recon______app\n",app.app_id
        print "recon______mobile",app.mobile
    return None

def reconcile_sales_claim():
    #########  Internal Function for validity check ########
    def check_validity_for_claims(claimed_list, ctype=""):
        if ctype :
            ctype = "CLAIM_%s" % ctype
        else:
            ctype = "CLAIM"
        debug_log.append("Found %s valid claims for this application" % len(claimed_list))
        if claimed_list:
            for claimed in claimed_list:
                if claimed.last_call_date < sc.last_call_date:
                    debug_log.append("Original Claimed date is : %s. which is closer to transaction" % claimed.last_call_date)
                    debug_log.append("Claim has been disqualified")
                    sc.match_status = '%s_REJECTED_ALREADY_CLAIMED_FRAUD' % ctype
                    sc.associated_applications.add(app)
                    sc.debug_log = ",\n".join(debug_log)
                    sc.save()
                    continue
                elif claimed.last_call_date == sc.last_call_date:
                    debug_log.append("Original Claimed date is same as this claim %s" % claimed.last_call_date)
                    if claimed.first_call_date <= sc.first_call_date:
                        debug_log.append("Original claim called the customer first")
                        debug_log.append("Claim has been disqualified")
                        sc.match_status = '%s_REJECTED_ALREADY_CLAIMED_SAME_DATE_FRAUD' % ctype
                        sc.associated_applications.add(app)
                        sc.debug_log = ",\n".join(debug_log)
                        sc.save()
                        continue
                    else:
                        debug_log.append("This claim called the customer first")
                        debug_log.append("Claim is genuine. but has already been claimed")
                        sc.match_status = '%s_REJECTED_ALREADY_CLAIMED_SAME_DATE_GENUINE' % ctype
                        sc.associated_applications.add(app)
                        sc.debug_log = ",\n".join(debug_log)
                        sc.save()
                        continue
                else:
                    debug_log.append("Original Claimed date is : %s. this claim called closer to transaction" % claimed.last_call_date)
                    debug_log.append("Claim looks genuine. but has already been claimed")
                    sc.match_status = '%s_REJECTED_ALREADY_CLAIMED_GENUINE' % ctype
                    sc.associated_applications.add(app)
                    sc.debug_log = ",\n".join(debug_log)
                    sc.save()
                    continue
        else:
            debug_log.append("This claim qualifies to be the first one to claim this application")
            sc.match_status = '%s_FOUND' % ctype
            sc.debug_log = ",\n".join(debug_log)
            sc.associated_applications.add(app)
            sc.save()
    #########  Internal Function end ########

    #TODO: If siteID is 0GOO, exception, still let ppl claim it, SITEID column in claim data, space to flag SEM later
    #TODO: Claim date be made DATETIME and not DATE
    #TODO: If two claims with same mobile, give it to one which has app_id (winner strategy : more information)
    #TODO: If all data is same, first call date is the winner
    #TODO: 48 hour uploads : Claim dates cannot be more than 48 hours late

    APPLICATION_CLAIM_VALID_AGE = 300    #default to be kept 2 days (48 hours) (in days)
    LAST_CALL_VALID_AGE = 300          #default to be kept 15 days (in days)
    scs = SaleClaim.objects.filter(match_status='FREE_CLAIM')
    if not scs:
        return

    app_in_psm = []
    dbcon = MySQLdb.connect(host=settings.LMS_HOST, user=settings.LMS_USER, passwd=settings.LMS_PASSWORD, db=settings.LMS_NAME)
    cur = dbcon.cursor()
    params = str(",".join(["'%s'" % s.app_id for s in scs]))
    cur.execute("SELECT app_id FROM core_application WHERE in_emerge=0 and app_id in (%s)" % params)
    fieldnames = ['app_id']
    for row in cur.fetchall():
        for index, data in enumerate(row):
            app_in_psm.append(data)

    for sc in scs:
        debug_log = []
        if sc.app_id.strip():
            app = Application.objects.filter(app_id=sc.app_id.strip())
            if app:
                app = app[0]

                if app.iad_site_id in ["GIGS", "GILG", "GLOL", "GNMD", "GMIC", "GKAS", "GDRE", "GGRO", "GOCL", "OCUM", "OCUM", "OCUM", "CPPM", "OFNP", "INDC", "OLAM", "MLAI", "YMNT", "0EDM", "OGOO", "OYAH", "MEDC", "IBWS", "IPSS", "ABOL", "OJDL", "ORDF", "BBRT"]:
                    debug_log.append("Checking for Advt SiteId")
                    debug_log.append("SiteId is %s, rejecting claim" % (app.iad_site_id))
                    sc.match_status = 'CLAIM_REJECTED_ADVT_SITE_ID_FOUND'
                    sc.debug_log = ",\n".join(debug_log)
                    sc.associated_applications.add(app)
                    sc.save()
                    continue

                if app.iad_site_id in ["OPBZ", "OMIC", "OAPA", "OISA", "OBMD", "OBDI"]:
                    if sc.user.username.lower() != app.iad_site_id.lower():
                        debug_log.append("Checking for Aggregator SiteId")
                        debug_log.append("Aggregator SiteId is %s, uploader code is %s, rejecting claim" % (app.iad_site_id, request.user.username))
                        sc.match_status = 'CLAIM_REJECTED_AGGREGATOR_SITE_ID_FOUND'
                        sc.debug_log = ",\n".join(debug_log)
                        sc.associated_applications.add(app)
                        sc.save()
                        continue
                    else:
                        debug_log.append("Application SiteID %s matches uploading aggregators code %s" % (app.iad_site_id, request.user.username))
                        sc.match_status = 'CLAIM_FOUND'
                        sc.debug_log = ",\n".join(debug_log)
                        sc.associated_applications.add(app)
                        sc.save()
                        continue

                debug_log.append("Application Found in Emerge")
                if (datetime.datetime.now() - app.transaction_end_time) > datetime.timedelta(days=APPLICATION_CLAIM_VALID_AGE):
                    debug_log.append("Cannot claim since 48 hours have passed since transaction")
                    sc.match_status = 'CLAIM_REJECTED_APPLICATION_TOO_OLD'
                    sc.debug_log = ",\n".join(debug_log)
                    sc.associated_applications.add(app)
                    sc.save()
                    continue
                elif (app.transaction_end_time - sc.last_call_date) > datetime.timedelta(days=LAST_CALL_VALID_AGE):
                    debug_log.append("Cannot claim since application was called 15 days before transaction")
                    sc.match_status = 'CLAIM_REJECTED_LAST_CALL_TOO_OLD'
                    sc.debug_log = ",\n".join(debug_log)
                    sc.associated_applications.add(app)
                    sc.save()
                    continue

                else:
                    debug_log.append("Claim fits criteria. checking for validity")
                    #TODO: Check query and "order by" properly
                    claimed = SaleClaim.objects.filter(Q(associated_applications__app_id=app.app_id) & Q(match_status__in=["CLAIM_FOUND","CLAIM_MOBILE_FOUND"]) & ~Q(id=sc.id)).order_by('-last_call_date')
                    check_validity_for_claims(claimed)
                    continue
            else:
                debug_log.append("Application NOT available in Emerge")
                if sc.app_id.strip() in app_in_psm:
                    debug_log.append("Application still in PSM. payment hasn't been completed")
                    sc.match_status = 'CLAIM_FOUND_PAYMENT_NOT_MADE'
                    sc.debug_log = ",\n".join(debug_log)
                    sc.save()
                    continue

        debug_log.append("ApplicationID cannot be found. Searching for a mobile match")
        #If app_id is not present or there is no app_id, check for matching phone regex, then proper names, 70XXX42430

        number_representation_is_valid = False
        if sc.mobile and len(sc.mobile) == 10 and sc.mobile.lower().count('x') <= 3:
            debug_log.append("Mobile Number representation is valid")
            number_representation_is_valid = True

        if not number_representation_is_valid:
            debug_log.append("Mobile Number invalid or not present. Claim is disqualified")
            sc.match_status = 'CLAIM_REJECTED_MOBILE_INVALID'
            sc.debug_log = ",\n".join(debug_log)
            sc.save()
            continue

        matching_regex = sc.mobile.replace("x",".")
        for app in Application.objects.filter(mobile__regex=matching_regex):
            if app.first_name.strip().lower() in "%s %s" % (sc.first_name.strip().lower(), sc.last_name.strip().lower()):
                debug_log.append("Mobile match found. first name matched with full name")
                claimed = SaleClaim.objects.filter(Q(associated_applications__app_id=app.app_id) & Q(match_status__in=["CLAIM_FOUND","CLAIM_MOBILE_FOUND"]) & ~Q(id=sc.id)).order_by('last_call_date')
                check_validity_for_claims(claimed, 'MOBILE')
                continue
            else:
                debug_log.append("Mobile match found. however Name mismatch : '%s' with '%s %s'" % (app.first_name.strip().lower(), sc.first_name.strip().lower(), sc.last_name.strip().lower()))
                sc.match_status = 'CLAIM_MOBILE_MATCH_NAME_INCORRECT'
                sc.debug_log = ",\n".join(debug_log)
                sc.save
                continue

        if sc.match_status == "FREE_CLAIM":
            if sc.app_id:
                debug_log.append("No Corresponding ApplicationID was found")
                sc.match_status = "CLAIM_NOTFOUND"
                sc.debug_log = ",\n".join(debug_log)
                sc.save()
            else:
                debug_log.append("No Corresponding Mobile number was found")
                sc.match_status = "CLAIM_MOBILE_REJECTED_MOBILE_INCORRECT"
                sc.debug_log = ",\n".join(debug_log)
                sc.save()
            continue

# new funxction to format insurer and secondary insurer data 6733
# 6733
# date 1 feb 2017

# 6733
def format_application_form_data_1(data):
    """
    DATA.data>> {"app_id":"OA0000318","tracker_id":"","dob":"01091996","first_name":"Abhi","last_name":"jain","gender":"F","birth_state":"Andhra Pradesh","birth_city":"Adoni","marital_status":"Married","nationality":"Indian","father_name":"","education":"HSC","occupation":"Business","annual_income":"345645645645","pan_no":"","uid_no":"","employer_name":"sdfsd","business_nature":"dfgfdg","designation":"sdfds","duty_nature":"sdfds","years_withemployer":"16","months_withemployer":"11","email_id":"jain20@gmail.com","mobile_no":"9967679737","flat":"cvxc","building":"fsdfsdfs","road":"sdfds","area":"sdfds","landmark":"sdfds","state":"Assam","city":"Badarpur","landline":"4534534534543","pincode":"435434","p_flat":"cvxc","p_building":"fsdfsdfs","p_road":"sdfds","p_area":"sdfds","p_landmark":"sdfds","p_state":"Assam","p_city":"Badarpur","p_landline":"4534534534543","p_pincode":"435434","eia_number":"","ir_name":"","ir_emailid":"","nominee_title":"Ms.","nominee_first_name":"ssdfs","nominee_last_name":"sdfd","nominee_dob":"12082011","nominee_relationship":"Grand Father","appointee_title":"Mrs.","appointee_first_name":"sdfsdf","appointee_last_name":"sdfsd","appointee_dob":"06081996","appointee_relationship":"Grand Mother","insurance_purpose":"sdfsdfsdf","id_proof":"RATION CARD","address_proof":"LETTER FOM RECOGNISED PUBLIC AUTHORITY/SERVANT","income_proof":"Bank Cash-flows statements transactions not older then 6 months","politically_exposed":"Yes","politically_exposeddetails":"sdfsdfds34534","annual_premium":"8766237.36","pay_amount":"730519.78","sum_assured":"1342500000","pay_status":"","transaction_id":""}
    """
    map_dict = {
        'ins_app_id': 'ins_app_id',
        'ins_tracker_id': 'ins_tracker_id',
        'ins_tracker_details': 'ins_tracker_details',

        'ins_salutation': 'ins_salutaion',
        'ins_first_name': 'ins_first_name',
        'ins_last_name': 'ins_last_name',
        'ins_gender': 'ins_gender',
        'ins_dob': 'ins_dob',
        'ins_marital_status': 'ins_marital_status',
        'ins_nationality': 'ins_nationality',
        'ins_education': 'ins_education',
        'ins_occupation': 'ins_occupation',
        'ins_org_type': 'ins_business_nature',
        'ins_designation': 'ins_designation',
        'ins_annual_income': 'ins_annual_income',

        'ins_father_name': 'ins_father_name',
        'ins_pancard_number': 'ins_pan_no',
        'ins_uid_number': 'ins_uid_no',

        'ins_email': 'ins_email_id',
        'ins_mobile': 'ins_mobile_no',
        'ins_flat': 'ins_flat',
        'ins_building': 'ins_building',
        'ins_road': 'ins_road',
        'ins_area': 'ins_area',
        'ins_landmark': 'ins_landmark',
        'ins_pincode': 'ins_pincode',
        'ins_state': 'ins_state',
        'ins_city': 'ins_city',
        'ins_landline': 'ins_landline',

        'ins_p_flat': 'ins_p_flat',
        'ins_p_building': 'ins_p_building',
        'ins_p_road': 'ins_p_road',
        'ins_p_area': 'p_area',
        'ins_p_landmark': 'ins_p_landmark',
        'ins_p_pincode': 'ins_p_pincode',
        'ins_p_state': 'ins_p_state',
        'ins_p_city': 'ins_p_city',
        'ins_p_landline': 'ins_p_landline',

        "ins_birth_state": "ins_birth_state",
        "ins_birth_city": "ins_birth_city",
        "ins_employer_name": "ins_employer_name",
        "ins_duty_nature": "ins_duty_nature",
        "ins_years_withemployer": "ins_years_withemployer",
        "ins_months_withemployer": "ins_months_withemployer",

        "ins_eia_number": "ins_eia_number",
        "ins_ir_name": "ins_ir_name",
        "ins_ir_email": "ins_ir_emailid",

        'ins_nominee_title': 'ins_nominee_title',
        'ins_nominee_first_name': 'ins_nominee_first_name',
        'ins_nominee_last_name': 'ins_nominee_last_name',
        'ins_nominee_dob': 'ins_nominee_dob',
        'ins_nominee_relationship': 'ins_nominee_relationship',
        'ins_appointee_title': 'ins_appointee_title',
        'ins_appointee_first_name': 'ins_appointee_first_name',
        'ins_appointee_last_name': 'ins_appointee_last_name',
        'ins_appointee_dob': 'ins_appointee_dob',
        'ins_appointee_relationship': 'ins_appointee_relationship',
        'ins_insurance_purpose': 'ins_insurance_purpose',

        'ins_politically_exposeddetails': 'ins_politically_exposeddetails',
        'ins_politically_exposed': 'ins_politically_exposed',

        'ins_sum_assured_website': 'ins_sum_assured',  # 5842-D
        'ins_sum_assured_option': 'ins_saOption',
        'ins_sum_assured_interval': 'ins_saInterval',
        'ins_policyterm_website': 'ins_term_period',  # 5842-D
        'ins_sumassured_interval_website': 'ins_interval',  # 5842-D
        'ins_sum_assured_option_website': 'ins_sumassured_type',  # 5842-D
        'ins_annual_premium': 'ins_annual_premium',

        'ins_photo_id_proof': 'ins_id_proof',
        'ins_address_proof': 'ins_address_proof',
        'ins_income_proof': 'ins_income_proof',

        'ins_pay_amount': 'ins_pay_amount',
        'ins_payment_status': 'ins_pay_status',
        'ins_transaction_id': 'ins_transaction_id',
        'ins_transaction_end_time': 'ins_transaction_end_time',
        'ins_pay_type': 'ins_pay_type',
        'ins_page_name': 'ins_page_name',

        'ins_medicalappointment_center2': 'ins_medicalappointment_center2',
        'ins_medicalappointment_city1': 'ins_medicalappointment_city1',
        'ins_medicalappointment_center1': 'ins_medicalappointment_center1',
        'ins_medicalappointment_city2': 'ins_medicalappointment_city2',
        'ins_medicalappointment_location2': 'ins_medicalappointment_location2',
        'ins_medicalappointment_time1': 'ins_medicalappointment_time1',
        'ins_medicalappointment_time2': 'ins_medicalappointment_time2',
        'ins_medicalappointment_location1': 'ins_medicalappointment_location1',
        'ins_medicalappointment_date1': 'ins_medicalappointment_date1',
        'ins_medicalappointment_date2': 'ins_medicalappointment_date2',

        'ins_photo_id_proof_rcvd': 'ins_id_proof_upload',
        'ins_address_proof_rcvd': 'ins_address_proof_upload',
        'ins_income_proof_rcvd': 'ins_income_proof_upload',
        'ins_age_proof_rcvd': 'ins_age_proof_upload',

        'ins_photo_id_proof_rcvd_date': 'ins_id_proof_rdate',
        'ins_address_proof_rcvd_date': 'ins_address_proof_rdate',
        'ins_income_proof_rcvd_date': 'ins_income_proof_rdate',
        'ins_age_proof_rcvd_date': 'ins_age_proof_rdate',
        'ins_online_created_date': 'ins_online_created_date',
        'ins_accidentaldeath': 'ins_accidentaldeath',
        # 5842-D start
        'ins_criticalillness': 'ins_criticalillness',
        'ins_hospitalcareillness': 'ins_hospitalcareillness',
        'ins_surgicalcare': 'ins_surgicalcare',
        'ins_accidentaldeathpre': 'ins_accidentaldeathpre',
        'ins_criticalillnesspre': 'ins_criticalillnesspre',
        'ins_hospitalcareillnesspre': 'ins_hospitalcareillnesspre',
        'ins_surgicalcarepre': 'ins_surgicalcarepre',
        'ins_riderdisc': 'ins_riderdisc',  # 5842-D end ######
        'ins_accidentalDeathAndBenefitPlus': 'ins_accidentalDeathAndBenefitPlus',
        # new rider added accidental death 26 sept
        'ins_accidentalDeathAndBenefitPlusPre': 'ins_accidentalDeathAndBenefitPlusPre',
        'ins_age_proof': 'ins_age_proof',   # insurer age proof 
        
    }

    """
        extra_fields = [
    'diabetes_eyeabnormality',
    'suffered_chestpain',
    'weight',
    'bp_consumetobacco',
    'diabetes_heartdisease',
    'diabetes_highbp',
    'physician_firstname',
    'diabetes_hospitalized',
    'diabetes_electrocardiogram',
    'diabetes_cigarettessmoked',
    'suffered_albumin',
    'diabetes_doctorname',
    'bp_complications',
    'bp_firstnoticed',
    'medicalquestion_details',
    'bp_investigatedhypertension_details',
    'bp_treatmentdiscontinued',
    'bp_sufferdiabetes',
    'chestpain_bloodpressure',
    'consumed_narcotic',
    'familymedicalhistory_details',
    'diabetes_albumin',
    'bp_treatmentdiscontinued_details',
    'job_hazardous',
    'weightchange_details',
    'physician_lastname',
    'travel_outside',
    'diabetes_weightatdiagnosis',
    'any_medical_advice',
    'diabetes_bloodsugarmeasurements',
    'remained_absent',
    'bp_consumetobacco_details',
    'suffered_ulcer',
    'bp_regulartreatment_details',
    'physician_email',
    'chestpain_heartmurmur',
    'diabetes_datediagnosed',
    'suffered_diabetic',
    'diabetes_hospitalized_details',
    'height_inches',
    'diabetes_type',
    'prior_illness',
    'physician_mobile',
    'suffered_cancer',
    'diabetes_weightloss',
    'bp_investigatedhypertension',
    'surgical_operation',
    'prior_illnessdetails',
    'diabetescontrol_details',
    'chestpain_heartattack',
    'weight_change',
    'diabetes_weightloss_details',
    'recent_bplevel',
    'arthritis',
    'any_gynaecological',
    'diabetes_control',
    'physician_officenumber',
    'height_feet',
    'suffered_asthma',
    'chestpain_chestpain',
    'pregnant',
    'consumed_alcohol',
    'any_complaints_not_consulted',
    'chestpain_highcholesterol',
    'any_physical_defects',
    'diabetes_cigarettessmoked_details',
    'diabetes_kidneyproblem',
    'pregnant_details',
    'diabetessugarmeasurement',
    'diabetes_doctorlastseen',
    'dizziness',
    'bp_regulartreatment',
    'bp_level'
    ]"""

    reverse_map_dict = dict([(v, k) for k, v in map_dict.items()])
    ndata = {}
    ndata['ins_extra'] = {}
    for k, v in data.items():
        if k in reverse_map_dict.keys():
            ndata[reverse_map_dict[k]] = v
        else:
            ndata['ins_extra'].update({k: v})

    if ndata.get('ins_dob'):
        ndata['ins_dob'] = datetime.datetime.strptime(ndata['ins_dob'], '%d%m%Y')
    if ndata.get('ins_appointee_dob'):
        ndata['ins_appointee_dob'] = datetime.datetime.strptime(ndata['ins_appointee_dob'], '%d%m%Y')
    if ndata.get('ins_nominee_dob'):
        ndata['ins_nominee_dob'] = datetime.datetime.strptime(ndata['ins_nominee_dob'], '%d%m%Y')
    if ndata.get('ins_created_on'):
        ndata['ins_created_on'] = datetime.datetime.strptime(ndata['ins_created_on'], '%d%m%Y%H%M%S')

    if ndata.get('ins_transaction_end_time'):
        ndata['ins_transaction_end_time'] = datetime.datetime.strptime(ndata['ins_transaction_end_time'], '%d%m%Y')
    if ndata.get('ins_online_created_date'):  # 14 may
        ndata['ins_online_created_date'] = datetime.datetime.strftime(
            datetime.datetime.strptime(ndata['ins_online_created_date'], '%m%d%Y %H:%M:%S'), '%Y-%m-%d %H:%M:%S')

    # if ndata.get('photo_id_proof_rcvd_date'):
    #     ndata['photo_id_proof_rcvd_date'] = datetime.datetime.strptime(ndata['photo_id_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('address_proof_rcvd_date'):
    #     ndata['address_proof_rcvd_date'] = datetime.datetime.strptime(ndata['address_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('age_proof_rcvd_date'):
    #     ndata['age_proof_rcvd_date'] = datetime.datetime.strptime(ndata['age_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('income_proof_rcvd_date'):
    #     ndata['income_proof_rcvd_date'] = datetime.datetime.strptime(ndata['income_proof_rcvd_date'], '%d%m%Y')


    ndata['ins_extra'] = simplejson.dumps(ndata['ins_extra'])

    ndata['ins_photo_id_proof'] = ndata['ins_photo_id_proof'].lower()
    ndata['ins_address_proof'] = ndata['ins_address_proof'].lower()
    ndata['ins_income_proof'] = ndata['ins_income_proof'].lower()
    # to move to prdctn
    ndata['ins_photo_id_proof_rcvd'] = ndata['ins_photo_id_proof_rcvd'].lower()
    ndata['ins_address_proof_rcvd'] = ndata['ins_address_proof_rcvd'].lower()
    ndata['ins_income_proof_rcvd'] = ndata['ins_income_proof_rcvd'].lower()
    ndata['ins_age_proof_rcvd'] = ndata['ins_age_proof_rcvd'].lower()

    return ndata



def pbz_format_application_form_data(data):
    """
    DATA.data>> {"app_id":"OA0000318","tracker_id":"","dob":"01091996","first_name":"Abhi","last_name":"jain","gender":"F","birth_state":"Andhra Pradesh","birth_city":"Adoni","marital_status":"Married","nationality":"Indian","father_name":"","education":"HSC","occupation":"Business","annual_income":"345645645645","pan_no":"","uid_no":"","employer_name":"sdfsd","business_nature":"dfgfdg","designation":"sdfds","duty_nature":"sdfds","years_withemployer":"16","months_withemployer":"11","email_id":"jain20@gmail.com","mobile_no":"9967679737","flat":"cvxc","building":"fsdfsdfs","road":"sdfds","area":"sdfds","landmark":"sdfds","state":"Assam","city":"Badarpur","landline":"4534534534543","pincode":"435434","p_flat":"cvxc","p_building":"fsdfsdfs","p_road":"sdfds","p_area":"sdfds","p_landmark":"sdfds","p_state":"Assam","p_city":"Badarpur","p_landline":"4534534534543","p_pincode":"435434","eia_number":"","ir_name":"","ir_emailid":"","nominee_title":"Ms.","nominee_first_name":"ssdfs","nominee_last_name":"sdfd","nominee_dob":"12082011","nominee_relationship":"Grand Father","appointee_title":"Mrs.","appointee_first_name":"sdfsdf","appointee_last_name":"sdfsd","appointee_dob":"06081996","appointee_relationship":"Grand Mother","insurance_purpose":"sdfsdfsdf","id_proof":"RATION CARD","address_proof":"LETTER FOM RECOGNISED PUBLIC AUTHORITY/SERVANT","income_proof":"Bank Cash-flows statements transactions not older then 6 months","politically_exposed":"Yes","politically_exposeddetails":"sdfsdfds34534","annual_premium":"8766237.36","pay_amount":"730519.78","sum_assured":"1342500000","pay_status":"","transaction_id":""}
    """
    map_dict = {
        'app_id': 'app_id',
        'tracker_id': 'tracker_id',
        'tracker_details': 'tracker_details',

        'salutation': 'salutaion',
        'first_name': 'first_name',
        'last_name': 'last_name',
        'gender': 'gender',
        'dob': 'dob',
        'marital_status': 'marital_status',
        'nationality': 'nationality',
        'education': 'education',
        'occupation': 'occupation',
        'org_type': 'business_nature',
        'designation': 'designation',
        'annual_income': 'annual_income',

        'father_name': 'father_name',
        'pancard_number': 'pan_no',
        'uid_number': 'uid_no',

        'email': 'email_id',
        'mobile': 'mobile_no',
        'flat': 'flat',
        'building': 'building',
        'road': 'road',
        'area': 'area',
        'landmark': 'landmark',
        'pincode': 'pincode',
        'state': 'state',
        'city': 'city',
        'landline': 'landline',

        'p_flat': 'p_flat',
        'p_building': 'p_building',
        'p_road': 'p_road',
        'p_area': 'p_area',
        'p_landmark': 'p_landmark',
        'p_pincode': 'p_pincode',
        'p_state': 'p_state',
        'p_city': 'p_city',
        'p_landline': 'p_landline',

        "birth_state": "birth_state",
        "birth_city": "birth_city",
        "employer_name": "employer_name",
        "duty_nature": "duty_nature",
        "years_withemployer": "years_withemployer",
        "months_withemployer": "months_withemployer",

        "eia_number": "eia_number",
        "ir_name": "ir_name",
        "ir_email": "ir_emailid",

        'nominee_title': 'nominee_title',
        'nominee_first_name': 'nominee_first_name',
        'nominee_last_name': 'nominee_last_name',
        'nominee_dob': 'nominee_dob',
        'nominee_relationship': 'nominee_relationship',
        'appointee_title': 'appointee_title',
        'appointee_first_name': 'appointee_first_name',
        'appointee_last_name': 'appointee_last_name',
        'appointee_dob': 'appointee_dob',
        'appointee_relationship': 'appointee_relationship',
        'insurance_purpose': 'insurance_purpose',

        'politically_exposeddetails': 'politically_exposeddetails',
        'politically_exposed': 'politically_exposed',

        'sum_assured_website': 'sum_assured',  # 5842-D
        'sum_assured_option': 'saOption',
        'sum_assured_interval': 'saInterval',
        'policyterm_website': 'term_period',  # 5842-D
        'sumassured_interval_website': 'interval',  # 5842-D
        'sum_assured_option_website': 'sumassured_type',  # 5842-D
        'annual_premium': 'annual_premium',

        'photo_id_proof': 'id_proof',
        'address_proof': 'address_proof',
        'income_proof': 'income_proof',

        'pay_amount': 'pay_amount',
        'payment_status': 'pay_status',
        'transaction_id': 'transaction_id',
        'transaction_end_time': 'transaction_end_time',
        'pay_type': 'pay_type',
        'page_name': 'page_name',

        'medicalappointment_center2': 'medicalappointment_center2',
        'medicalappointment_city1': 'medicalappointment_city1',
        'medicalappointment_center1': 'medicalappointment_center1',
        'medicalappointment_city2': 'medicalappointment_city2',
        'medicalappointment_location2': 'medicalappointment_location2',
        'medicalappointment_time1': 'medicalappointment_time1',
        'medicalappointment_time2': 'medicalappointment_time2',
        'medicalappointment_location1': 'medicalappointment_location1',
        'medicalappointment_date1': 'medicalappointment_date1',
        'medicalappointment_date2': 'medicalappointment_date2',

        'photo_id_proof_rcvd': 'id_proof_upload',
        'address_proof_rcvd': 'address_proof_upload',
        'income_proof_rcvd': 'income_proof_upload',
        'age_proof_rcvd': 'age_proof_upload',

        'photo_id_proof_rcvd_date': 'id_proof_rdate',
        'address_proof_rcvd_date': 'address_proof_rdate',
        'income_proof_rcvd_date': 'income_proof_rdate',
        'age_proof_rcvd_date': 'age_proof_rdate',
        'online_created_date': 'online_created_date',
        'accidentaldeath': 'accidentaldeath',
    # 5842-D start
        'criticalillness': 'criticalillness',
        'hospitalcareillness': 'hospitalcareillness',
        'surgicalcare': 'surgicalcare',
        'accidentaldeathpre': 'accidentaldeathpre',
        'criticalillnesspre': 'criticalillnesspre',
        'hospitalcareillnesspre': 'hospitalcareillnesspre',
        'surgicalcarepre': 'surgicalcarepre',
        'riderdisc': 'riderdisc',  # 5842-D end ######
        'accidentalDeathAndBenefitPlus': 'accidentalDeathAndBenefitPlus',
    # new rider added accidental death 26 sept
        'accidentalDeathAndBenefitPlusPre': 'accidentalDeathAndBenefitPlusPre',
        'waiverofPremium': 'waiverofPremium',  # 6733 wop rider
        'waiverofPremiumpre': 'waiverofPremiumpre',  # 6733 new rider premium
        'age_proof': 'age_proof',  # 6733 age proof create batch data
    }

    """
    extra_fields = [
    'diabetes_eyeabnormality',
    'suffered_chestpain',
    'weight',
    'bp_consumetobacco',
    'diabetes_heartdisease',
    'diabetes_highbp',
    'physician_firstname',
    'diabetes_hospitalized',
    'diabetes_electrocardiogram',
    'diabetes_cigarettessmoked',
    'suffered_albumin',
    'diabetes_doctorname',
    'bp_complications',
    'bp_firstnoticed',
    'medicalquestion_details',
    'bp_investigatedhypertension_details',
    'bp_treatmentdiscontinued',
    'bp_sufferdiabetes',
    'chestpain_bloodpressure',
    'consumed_narcotic',
    'familymedicalhistory_details',
    'diabetes_albumin',
    'bp_treatmentdiscontinued_details',
    'job_hazardous',
    'weightchange_details',
    'physician_lastname',
    'travel_outside',
    'diabetes_weightatdiagnosis',
    'any_medical_advice',
    'diabetes_bloodsugarmeasurements',
    'remained_absent',
    'bp_consumetobacco_details',
    'suffered_ulcer',
    'bp_regulartreatment_details',
    'physician_email',
    'chestpain_heartmurmur',
    'diabetes_datediagnosed',
    'suffered_diabetic',
    'diabetes_hospitalized_details',
    'height_inches',
    'diabetes_type',
    'prior_illness',
    'physician_mobile',
    'suffered_cancer',
    'diabetes_weightloss',
    'bp_investigatedhypertension',
    'surgical_operation',
    'prior_illnessdetails',
    'diabetescontrol_details',
    'chestpain_heartattack',
    'weight_change',
    'diabetes_weightloss_details',
    'recent_bplevel',
    'arthritis',
    'any_gynaecological',
    'diabetes_control',
    'physician_officenumber',
    'height_feet',
    'suffered_asthma',
    'chestpain_chestpain',
    'pregnant',
    'consumed_alcohol',
    'any_complaints_not_consulted',
    'chestpain_highcholesterol',
    'any_physical_defects',
    'diabetes_cigarettessmoked_details',
    'diabetes_kidneyproblem',
    'pregnant_details',
    'diabetessugarmeasurement',
    'diabetes_doctorlastseen',
    'dizziness',
    'bp_regulartreatment',
    'bp_level'
    ]"""

    reverse_map_dict = dict([(v, k) for k, v in map_dict.items()])
    ndata = {}
    ndata['extra'] = {}
    for k, v in data.items():
        if k in reverse_map_dict.keys():
            ndata[reverse_map_dict[k]] = v
        else:
            ndata['extra'].update({k: v})

    if ndata.get('dob'):
        ndata['dob'] = datetime.datetime.strptime(ndata['dob'], '%d%m%Y')
    if ndata.get('appointee_dob'):
        ndata['appointee_dob'] = datetime.datetime.strptime(ndata['appointee_dob'], '%d%m%Y')
    if ndata.get('nominee_dob'):
        ndata['nominee_dob'] = datetime.datetime.strptime(ndata['nominee_dob'], '%d%m%Y')
    if ndata.get('created_on'):
        ndata['created_on'] = datetime.datetime.strptime(ndata['created_on'], '%d%m%Y%H%M%S')
    print "transaction end time", ndata.get('transaction_end_time')
    if ndata.get('transaction_end_time'):
        ndata['transaction_end_time'] = datetime.datetime.strptime(ndata['transaction_end_time'], '%d%m%Y')
    if ndata.get('online_created_date'):  # 14 may
        ndata['online_created_date'] = datetime.datetime.strftime(
            datetime.datetime.strptime(ndata['online_created_date'], '%m%d%Y %H:%M:%S'), '%Y-%m-%d %H:%M:%S')

    # if ndata.get('photo_id_proof_rcvd_date'):
    #     ndata['photo_id_proof_rcvd_date'] = datetime.datetime.strptime(ndata['photo_id_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('address_proof_rcvd_date'):
    #     ndata['address_proof_rcvd_date'] = datetime.datetime.strptime(ndata['address_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('age_proof_rcvd_date'):
    #     ndata['age_proof_rcvd_date'] = datetime.datetime.strptime(ndata['age_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('income_proof_rcvd_date'):
    #     ndata['income_proof_rcvd_date'] = datetime.datetime.strptime(ndata['income_proof_rcvd_date'], '%d%m%Y')

    ndata['extra'] = simplejson.dumps(ndata['extra'])

    ndata['photo_id_proof'] = ndata['photo_id_proof'].lower()
    ndata['address_proof'] = ndata['address_proof'].lower()
    ndata['income_proof'] = ndata['income_proof'].lower()
    # to move to prdctn
    ndata['photo_id_proof_rcvd'] = ndata['photo_id_proof_rcvd'].lower()
    ndata['address_proof_rcvd'] = ndata['address_proof_rcvd'].lower()
    ndata['income_proof_rcvd'] = ndata['income_proof_rcvd'].lower()
    ndata['age_proof_rcvd'] = ndata['age_proof_rcvd'].lower()

    return ndata


def pbz_format_application_form_data_1(data):
    """
    DATA.data>> {"app_id":"OA0000318","tracker_id":"","dob":"01091996","first_name":"Abhi","last_name":"jain","gender":"F","birth_state":"Andhra Pradesh","birth_city":"Adoni","marital_status":"Married","nationality":"Indian","father_name":"","education":"HSC","occupation":"Business","annual_income":"345645645645","pan_no":"","uid_no":"","employer_name":"sdfsd","business_nature":"dfgfdg","designation":"sdfds","duty_nature":"sdfds","years_withemployer":"16","months_withemployer":"11","email_id":"jain20@gmail.com","mobile_no":"9967679737","flat":"cvxc","building":"fsdfsdfs","road":"sdfds","area":"sdfds","landmark":"sdfds","state":"Assam","city":"Badarpur","landline":"4534534534543","pincode":"435434","p_flat":"cvxc","p_building":"fsdfsdfs","p_road":"sdfds","p_area":"sdfds","p_landmark":"sdfds","p_state":"Assam","p_city":"Badarpur","p_landline":"4534534534543","p_pincode":"435434","eia_number":"","ir_name":"","ir_emailid":"","nominee_title":"Ms.","nominee_first_name":"ssdfs","nominee_last_name":"sdfd","nominee_dob":"12082011","nominee_relationship":"Grand Father","appointee_title":"Mrs.","appointee_first_name":"sdfsdf","appointee_last_name":"sdfsd","appointee_dob":"06081996","appointee_relationship":"Grand Mother","insurance_purpose":"sdfsdfsdf","id_proof":"RATION CARD","address_proof":"LETTER FOM RECOGNISED PUBLIC AUTHORITY/SERVANT","income_proof":"Bank Cash-flows statements transactions not older then 6 months","politically_exposed":"Yes","politically_exposeddetails":"sdfsdfds34534","annual_premium":"8766237.36","pay_amount":"730519.78","sum_assured":"1342500000","pay_status":"","transaction_id":""}
    """
    map_dict = {
        'ins_app_id': 'ins_app_id',
        'ins_tracker_id': 'ins_tracker_id',
        'ins_tracker_details': 'ins_tracker_details',

        'ins_salutation': 'ins_salutaion',
        'ins_first_name': 'ins_first_name',
        'ins_last_name': 'ins_last_name',
        'ins_gender': 'ins_gender',
        'ins_dob': 'ins_dob',
        'ins_marital_status': 'ins_marital_status',
        'ins_nationality': 'ins_nationality',
        'ins_education': 'ins_education',
        'ins_occupation': 'ins_occupation',
        'ins_org_type': 'ins_business_nature',
        'ins_designation': 'ins_designation',
        'ins_annual_income': 'ins_annual_income',

        'ins_father_name': 'ins_father_name',
        'ins_pancard_number': 'ins_pan_no',
        'ins_uid_number': 'ins_uid_no',

        'ins_email': 'ins_email_id',
        'ins_mobile': 'ins_mobile_no',
        'ins_flat': 'ins_flat',
        'ins_building': 'ins_building',
        'ins_road': 'ins_road',
        'ins_area': 'ins_area',
        'ins_landmark': 'ins_landmark',
        'ins_pincode': 'ins_pincode',
        'ins_state': 'ins_state',
        'ins_city': 'ins_city',
        'ins_landline': 'ins_landline',

        'ins_p_flat': 'ins_p_flat',
        'ins_p_building': 'ins_p_building',
        'ins_p_road': 'ins_p_road',
        'ins_p_area': 'p_area',
        'ins_p_landmark': 'ins_p_landmark',
        'ins_p_pincode': 'ins_p_pincode',
        'ins_p_state': 'ins_p_state',
        'ins_p_city': 'ins_p_city',
        'ins_p_landline': 'ins_p_landline',

        "ins_birth_state": "ins_birth_state",
        "ins_birth_city": "ins_birth_city",
        "ins_employer_name": "ins_employer_name",
        "ins_duty_nature": "ins_duty_nature",
        "ins_years_withemployer": "ins_years_withemployer",
        "ins_months_withemployer": "ins_months_withemployer",

        "ins_eia_number": "ins_eia_number",
        "ins_ir_name": "ins_ir_name",
        "ins_ir_email": "ins_ir_emailid",

        'ins_nominee_title': 'ins_nominee_title',
        'ins_nominee_first_name': 'ins_nominee_first_name',
        'ins_nominee_last_name': 'ins_nominee_last_name',
        'ins_nominee_dob': 'ins_nominee_dob',
        'ins_nominee_relationship': 'ins_nominee_relationship',
        'ins_appointee_title': 'ins_appointee_title',
        'ins_appointee_first_name': 'ins_appointee_first_name',
        'ins_appointee_last_name': 'ins_appointee_last_name',
        'ins_appointee_dob': 'ins_appointee_dob',
        'ins_appointee_relationship': 'ins_appointee_relationship',
        'ins_insurance_purpose': 'ins_insurance_purpose',

        'ins_politically_exposeddetails': 'ins_politically_exposeddetails',
        'ins_politically_exposed': 'ins_politically_exposed',

        'ins_sum_assured_website': 'ins_sum_assured',  # 5842-D
        'ins_sum_assured_option': 'ins_saOption',
        'ins_sum_assured_interval': 'ins_saInterval',
        'ins_policyterm_website': 'ins_term_period',  # 5842-D
        'ins_sumassured_interval_website': 'ins_interval',  # 5842-D
        'ins_sum_assured_option_website': 'ins_sumassured_type',  # 5842-D
        'ins_annual_premium': 'ins_annual_premium',

        'ins_photo_id_proof': 'ins_id_proof',
        'ins_address_proof': 'ins_address_proof',
        'ins_income_proof': 'ins_income_proof',

        'ins_pay_amount': 'ins_pay_amount',
        'ins_payment_status': 'ins_pay_status',
        'ins_transaction_id': 'ins_transaction_id',
        'ins_transaction_end_time': 'ins_transaction_end_time',
        'ins_pay_type': 'ins_pay_type',
        'ins_page_name': 'ins_page_name',

        'ins_medicalappointment_center2': 'ins_medicalappointment_center2',
        'ins_medicalappointment_city1': 'ins_medicalappointment_city1',
        'ins_medicalappointment_center1': 'ins_medicalappointment_center1',
        'ins_medicalappointment_city2': 'ins_medicalappointment_city2',
        'ins_medicalappointment_location2': 'ins_medicalappointment_location2',
        'ins_medicalappointment_time1': 'ins_medicalappointment_time1',
        'ins_medicalappointment_time2': 'ins_medicalappointment_time2',
        'ins_medicalappointment_location1': 'ins_medicalappointment_location1',
        'ins_medicalappointment_date1': 'ins_medicalappointment_date1',
        'ins_medicalappointment_date2': 'ins_medicalappointment_date2',

        'ins_photo_id_proof_rcvd': 'ins_id_proof_upload',
        'ins_address_proof_rcvd': 'ins_address_proof_upload',
        'ins_income_proof_rcvd': 'ins_income_proof_upload',
        'ins_age_proof_rcvd': 'ins_age_proof_upload',

        'ins_photo_id_proof_rcvd_date': 'ins_id_proof_rdate',
        'ins_address_proof_rcvd_date': 'ins_address_proof_rdate',
        'ins_income_proof_rcvd_date': 'ins_income_proof_rdate',
        'ins_age_proof_rcvd_date': 'ins_age_proof_rdate',
        'ins_online_created_date': 'ins_online_created_date',
        'ins_accidentaldeath': 'ins_accidentaldeath',
        # 5842-D start
        'ins_criticalillness': 'ins_criticalillness',
        'ins_hospitalcareillness': 'ins_hospitalcareillness',
        'ins_surgicalcare': 'ins_surgicalcare',
        'ins_accidentaldeathpre': 'ins_accidentaldeathpre',
        'ins_criticalillnesspre': 'ins_criticalillnesspre',
        'ins_hospitalcareillnesspre': 'ins_hospitalcareillnesspre',
        'ins_surgicalcarepre': 'ins_surgicalcarepre',
        'ins_riderdisc': 'ins_riderdisc',  # 5842-D end ######
        'ins_accidentalDeathAndBenefitPlus': 'ins_accidentalDeathAndBenefitPlus',
        # new rider added accidental death 26 sept
        'ins_accidentalDeathAndBenefitPlusPre': 'ins_accidentalDeathAndBenefitPlusPre',
        'ins_age_proof': 'ins_age_proof',  # insurer age proof

    }

    """
        extra_fields = [
    'diabetes_eyeabnormality',
    'suffered_chestpain',
    'weight',
    'bp_consumetobacco',
    'diabetes_heartdisease',
    'diabetes_highbp',
    'physician_firstname',
    'diabetes_hospitalized',
    'diabetes_electrocardiogram',
    'diabetes_cigarettessmoked',
    'suffered_albumin',
    'diabetes_doctorname',
    'bp_complications',
    'bp_firstnoticed',
    'medicalquestion_details',
    'bp_investigatedhypertension_details',
    'bp_treatmentdiscontinued',
    'bp_sufferdiabetes',
    'chestpain_bloodpressure',
    'consumed_narcotic',
    'familymedicalhistory_details',
    'diabetes_albumin',
    'bp_treatmentdiscontinued_details',
    'job_hazardous',
    'weightchange_details',
    'physician_lastname',
    'travel_outside',
    'diabetes_weightatdiagnosis',
    'any_medical_advice',
    'diabetes_bloodsugarmeasurements',
    'remained_absent',
    'bp_consumetobacco_details',
    'suffered_ulcer',
    'bp_regulartreatment_details',
    'physician_email',
    'chestpain_heartmurmur',
    'diabetes_datediagnosed',
    'suffered_diabetic',
    'diabetes_hospitalized_details',
    'height_inches',
    'diabetes_type',
    'prior_illness',
    'physician_mobile',
    'suffered_cancer',
    'diabetes_weightloss',
    'bp_investigatedhypertension',
    'surgical_operation',
    'prior_illnessdetails',
    'diabetescontrol_details',
    'chestpain_heartattack',
    'weight_change',
    'diabetes_weightloss_details',
    'recent_bplevel',
    'arthritis',
    'any_gynaecological',
    'diabetes_control',
    'physician_officenumber',
    'height_feet',
    'suffered_asthma',
    'chestpain_chestpain',
    'pregnant',
    'consumed_alcohol',
    'any_complaints_not_consulted',
    'chestpain_highcholesterol',
    'any_physical_defects',
    'diabetes_cigarettessmoked_details',
    'diabetes_kidneyproblem',
    'pregnant_details',
    'diabetessugarmeasurement',
    'diabetes_doctorlastseen',
    'dizziness',
    'bp_regulartreatment',
    'bp_level'
    ]"""

    reverse_map_dict = dict([(v, k) for k, v in map_dict.items()])
    ndata = {}
    ndata['ins_extra'] = {}
    for k, v in data.items():
        if k in reverse_map_dict.keys():
            ndata[reverse_map_dict[k]] = v
        else:
            ndata['ins_extra'].update({k: v})

    if ndata.get('ins_dob'):
        ndata['ins_dob'] = datetime.datetime.strptime(ndata['ins_dob'], '%d%m%Y')
    if ndata.get('ins_appointee_dob'):
        ndata['ins_appointee_dob'] = datetime.datetime.strptime(ndata['ins_appointee_dob'], '%d%m%Y')
    if ndata.get('ins_nominee_dob'):
        ndata['ins_nominee_dob'] = datetime.datetime.strptime(ndata['ins_nominee_dob'], '%d%m%Y')
    if ndata.get('ins_created_on'):
        ndata['ins_created_on'] = datetime.datetime.strptime(ndata['ins_created_on'], '%d%m%Y%H%M%S')

    if ndata.get('ins_transaction_end_time'):
        ndata['ins_transaction_end_time'] = datetime.datetime.strptime(ndata['ins_transaction_end_time'], '%d%m%Y')
    if ndata.get('ins_online_created_date'):  # 14 may
        ndata['ins_online_created_date'] = datetime.datetime.strftime(
            datetime.datetime.strptime(ndata['ins_online_created_date'], '%m%d%Y %H:%M:%S'), '%Y-%m-%d %H:%M:%S')

    # if ndata.get('photo_id_proof_rcvd_date'):
    #     ndata['photo_id_proof_rcvd_date'] = datetime.datetime.strptime(ndata['photo_id_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('address_proof_rcvd_date'):
    #     ndata['address_proof_rcvd_date'] = datetime.datetime.strptime(ndata['address_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('age_proof_rcvd_date'):
    #     ndata['age_proof_rcvd_date'] = datetime.datetime.strptime(ndata['age_proof_rcvd_date'], '%d%m%Y')
    # if ndata.get('income_proof_rcvd_date'):
    #     ndata['income_proof_rcvd_date'] = datetime.datetime.strptime(ndata['income_proof_rcvd_date'], '%d%m%Y')


    ndata['ins_extra'] = simplejson.dumps(ndata['ins_extra'])

    ndata['ins_photo_id_proof'] = ndata['ins_photo_id_proof'].lower()
    ndata['ins_address_proof'] = ndata['ins_address_proof'].lower()
    ndata['ins_income_proof'] = ndata['ins_income_proof'].lower()
    # to move to prdctn
    ndata['ins_photo_id_proof_rcvd'] = ndata['ins_photo_id_proof_rcvd'].lower()
    ndata['ins_address_proof_rcvd'] = ndata['ins_address_proof_rcvd'].lower()
    ndata['ins_income_proof_rcvd'] = ndata['ins_income_proof_rcvd'].lower()
    ndata['ins_age_proof_rcvd'] = ndata['ins_age_proof_rcvd'].lower()

    return ndata
