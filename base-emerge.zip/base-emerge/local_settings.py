import os
from setting import setting
EMAIL_HOST = "10.155.1.73"


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'emerge',                      # Or path to database file if using sqlite3.
        'USER': 'root',                      # Not used with sqlite3.
        'PASSWORD': 'admin@0101',                  # Not used with sqlite3.
        'HOST': '',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

DEBUG=True

DATABASE_OPTIONS = {
    "connect_timeout": 60,
}

MEDIA_ROOT = os.path.join(REPO_FOLDER,'media/bsliemerge/static')
SITE_URL = 'http://10.155.1.233:81'

