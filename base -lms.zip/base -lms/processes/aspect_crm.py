import sys, time, datetime, os
import settings
from django.core.management import setup_environ
from collections import defaultdict

setup_environ(settings)

from core.models import *
from customdb.customquery import sqltojson, sqltodict

import redis, datetime
import json
from django.db.models import Q
import pyodbc
from datetime import datetime, timedelta, time, date


dsn = 'sqlserverdatasource'
user = 'user_click;'
password = 'pass@123;'
database = 'ACR;'
now = datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")
now1 = datetime.strftime(datetime.now(),"%Y-%m-%d %H:10:10")
t = date.today() + timedelta(days=-1)
t1 = str(t) + " " + "00:00:00"
t2 = str(t) + " " + "23:59:59"
con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)
cnxn = pyodbc.connect(con_string)
cur=cnxn.cursor()


try:
    #query="""select * from UAT_ClickToDial where App_Name='LMS' and RecordInsertDt between concat(date_sub(curdate(),Interval 1 day)," ","00:00:00")  and concat(date_sub(curdate(),Interval 1 day)," ","23:59:59")"""
    #query1="select App_ID,Field2,Call_Duration_Seconds,CallStartDT,CallEndDT,DialFlag from UAT_ClickToDial where App_Name='LMS' and RecordInsertDt < '2015-11-19 23:59:59'"
    query1="select App_ID,Field2,Call_Duration_Seconds,CallStartDT,CallEndDT,DialFlag from ClickToDial_view where App_Name='LMS' and RecordInsertDt between '%s' and '%s'" % (t1,t2)
    cur.execute(query1)
    c = cur.fetchall()
    for i in c:
        print i[0]
        CampaignData.objects.filter(id=i[1]).update(aspectcall_start_date=i[3],aspectcall_end_date=i[4],aspectcall_duration=i[2],aspectcall_dialflag=i[5])
       #query2="update lms.core_campaigndata set aspectcall_start_date='%s',aspectcall_end_date='%s',aspectcall_duration='%s',aspectcall_created_on='%s' where "
        #query2="insert into lms.core_campaigndata(aspectcall_start_date,aspectcall_end_date,aspectcall_duration,aspectcall_created_on) values('%s', #'%s','%s','%s')" %(i[3],i[4],i[2],now)

except Exception as e:
    print "Exception in Click to dial",e
