#!/usr/bin/env python
import sys, time, datetime, os
import settings
from django.core.management import setup_environ
from collections import defaultdict

setup_environ(settings)

from core.models import *
from customdb.customquery import sqltojson, sqltodict

import redis, datetime
import json

publisher = redis.Redis(host='localhost', port=6380)
pipeline = publisher.pipeline()

#TODO Optimize for 3-4 queries only
def main():
    print datetime.datetime.now()
    campaign_list = Campaign.objects.all()

    assigned_user = {}
    for u in User.objects.all():
        assigned_user[u] = publisher.lrange("inprocess_user%s" % u.id, 0, -1)

    for campaign in campaign_list:
        # Calls belonging to the caller
        print "For campaign", campaign
        in_process_calls = CampaignData.objects.filter(
            campaign = campaign,
            status = 'IN_PROCESS',
            next_call_time__lte = datetime.datetime.now(),
            is_taken = False,
        ).order_by("-next_call_time")

        if in_process_calls:
            data_store = publisher.mget(["data%s" % cd.id for cd in in_process_calls])
        else:
            data_store = []
        in_process_data = []
        print "Looping with calls : ", len(in_process_calls)
        for cd,ds in zip(in_process_calls, data_store):
            if cd.id not in assigned_user[u]:
                print "Pushing campaign data", cd.id
                pipeline.lpush("inprocess_user%s" % cd.assigned_to_id, cd.id)
                assigned_user[u].append(cd.id)
            if not ds:
                pipeline.set("data%s" % cd.id, json.dumps(cd.mini_json()))
        pipeline.execute()
        print "-------------------Executed--------------"

main()
