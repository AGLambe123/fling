#!/usr/bin/env python
import sys, time, datetime, os
import settings
from django.core.management import setup_environ

setup_environ(settings)

from core.models import *
import project_utils as putils
from customdb.customquery import sqltojson, sqltodict

#TODO Optimize for 3-4 queries only
def main():
    call_limit = 6
    remove_disposition = ",".join(["'%s'" % d for d in putils.DISPOSITION_MAP['NONCONTACTABLE']])

    query = "SELECT core_campaigndata.customer_id as cust_id, count(core_campaigndata.customer_id) as cust_count FROM core_campaigndata INNER JOIN core_campaigndata_history ON (core_campaigndata.id = core_campaigndata_history.campaigndata_id) INNER JOIN core_history ON (core_campaigndata_history.history_id = core_history.id) where core_campaigndata.status != 'CONCLUDED' AND core_history.call_disposition in (%s) group by cust_id having cust_count > %s;" % (remove_disposition, call_limit)

    results = sqltodict(query, [])
    pks = [res['cust_id'] for res in results]

    search_string = ",".join(['NONCONTACTABLE']*call_limit)
    for cd in CampaignData.objects.filter(customer_id__in=pks):
        full_status = ",".join([putils.REV_DISTRIBUTION_MAP[ch.call_disposition] for ch in cd.history.all() if ch.call_disposition and ch.call_disposition not in ['DUPLICATE_API', 'LIMIT_EXCEEDED','DONE', 'PAYMENT_SUCCESSFUL']])
        if search_string in full_status:
            print cd
            cd.dispose_manually("LIMIT_EXCEEDED")
    print datetime.datetime.now()

main()
