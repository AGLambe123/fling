#!/usr/bin/env python
import sys, time, datetime, os
import settings
from django.core.management import setup_environ

setup_environ(settings)
from core.models import *

import httplib, urllib

data = eval(sys.argv[1])
print data
params = urllib.urlencode({'data':simplejson.dumps(data)})
headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"}
conn = httplib.HTTPConnection("localhost", 8000)
conn.request("POST", "/data-push/", params, headers)
response = conn.getresponse()
print response.status, response.reason

data = response.read()
print data

conn.close()
