import logging
import re
import time
import datetime
import os
import hashlib
from django.conf import settings
import simplejson
from core.models import *

def context_processor(request):
    d = {
        'current_time' : datetime.datetime.now(),
        'static_path' : settings.STATIC_PATH,
    }
    return d

def create_field_map(data):
    fmap = {}
    i = 0
    for fld in data['list_order']:
        if re.sub(r'^list_','include_',fld) in data['include_fields']:
            if re.sub(r'^list_','format_',fld) in data['format_fields'].keys():
                fmap[i] = (fld, data['format_fields'][re.sub(r'^list_','format_',fld)])
            else:
                fmap[i] = fld
            i += 1
    return fmap

def save_model_config(campaign, post_data, instance=None):
    list_order = simplejson.loads(post_data['field_order'])
    include_fields = [t for t in post_data.keys() if t.startswith('include_')]
    format_fields = dict([(t, post_data[t]) for t in post_data.keys() if t.startswith('format_')])
    raw_data = {'list_order' : list_order, 'include_fields' : include_fields, 'format_fields' : format_fields}
    title = post_data.get('title')
    if not title : title = "%s-%s" % (campaign.name, datetime.datetime.now().strftime('%d-%m-%Y-%H-%M-%S'))
    fmap = create_field_map(raw_data)
    if instance:
        instance.title = title
        instance.raw_data = simplejson.dumps(raw_data)
        instance.field_map = simplejson.dumps(fmap)
        instance.save()
    else:
        instance = UploadSchema(
            title = title,
            raw_data = simplejson.dumps(raw_data),
            field_map=simplejson.dumps(fmap),
        )
        instance.save()
        campaign.upload_schemas.add(instance)

    return instance
