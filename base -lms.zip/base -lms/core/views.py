import datetime
import hashlib
import logging
from itertools import izip

from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseRedirect
from django.http import Http404
from django.template import RequestContext
from datetime import datetime, timedelta, time , date #6043
from django.shortcuts import render_to_response, get_object_or_404
from django.template.loader import render_to_string
from django.db.models import Q
from django.db import connection
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from django.core import serializers
from django.forms.models import modelformset_factory
from django.forms.formsets import formset_factory
from django.contrib.auth import authenticate, login
import json
from django.core.serializers.json import DjangoJSONEncoder
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from collections import defaultdict

import project_utils as putils
from core.forms import *
from core.models import *
from customdb.customquery import sqltojson, sqltodict, executesql
from excelib import excel_generator, render_excel, render_custom_excel_to_file, render_excel_to_file
import thread
from xl2python import Xl2Python
import utils
import csv

import lutils
from Crypto.Cipher import Blowfish
from xml2json import Xml2Json
import base64
import redis
import parse_query
import math
import pyodbc
import requests
from django.contrib.auth.signals import user_logged_in #6109
from django.contrib.auth import logout #6109                                                                                                         
from django.views.decorators.cache import never_cache, cache_page
from django.views.decorators.vary import vary_on_headers

publisher = redis.Redis(host='localhost', port=6380)
pipeline = publisher.pipeline()

# def delete_user_sessions(user):
#      user_sessions = UserSession.objects.filter(user = user)
#      for user_session in user_sessions:
#          user_session.session.delete()

@login_required
def index(request):
    if request.user.is_authenticated():
      #   userObj = UserSession.objects.filter(user = request.user.id).values_list('session_id')
      #   if userObj:
      #       if userObj[0][0] != request.session.session_key:
      #           #  delete_user_sessions(request.user.id)                                                                                             
      #           #            return HttpResponseRedirect('/accounts/logout')
      # #messages = str(request.user)+" "+ "already logged in" # Caller caller                                                               

      #           logout(request)
      #           messages = str(request.user.username)+" "+ "already logged in"
      #           return render_to_response("registration/login.html",{"messages":messages},
      #                                  context_instance=RequestContext(request))
    
        if request.user.is_superuser:
            return HttpResponseRedirect('/nimda/')
        try:
            user_profile = request.user.userprofile
        except:
            return HttpResponse("""Error! There is some problem with your user account, contact support or mail us at ranedk@glitterbug.in !<br/> click <a href="/accounts/logout/">here</a> to try again!
            """)

        user_urls = {
            "MANAGER" : '/manager/dashboard/',
            "ADMIN" : '/manager/dashboard/',
            "UPLOAD" : '/upload/dashboard/',
            "REPORT" : '/report/dashboard/',
            "CALLER" : '/caller/dashboard/',
            "POLICY_PLAN_NAME" :'/lms/upload/',
        }
        return HttpResponseRedirect(user_urls.get(user_profile.role,"/search/"))
    else:
        return HttpResponseRedirect("/accounts/login/")
        
@csrf_exempt
def create_application_old_webservice(request, campaign_name=None):
    """ Direct Http Data push """
    
    print "API HIT RECORD"
    
    if not request.POST.get('data'):
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Payload missing"}))
    print "______________________________________________"
    data = request.POST['data']    
    try:
        rdata = eval(simplejson.loads(data)['data'])
    except:
        try:
            rdata = simplejson.loads(data)
        except:
            try:                
                rdata = simplejson.loads(str(data))
            except:
                return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Incorrect serialization"}))  
           
   
    try:
        final_data, response, rdata_logger = normalize_api_data(rdata)
        
        utils.response_logger.info(rdata_logger)
        if response:
            return HttpResponse(response)
        
       
        if campaign_name:
            campaign = Campaign.objects.get(name=campaign_name)
        else:
            #campaign = Campaign.objects.get(name="D2C") #change 19 Dec
            if final_data.get('application_id') == "BA0000000":  # 6043
                campaign = Campaign.objects.get(name="D2CQ")
            else:
                campaign = Campaign.objects.get(name="D2C")
                
        (rdata_logger, response) = conclude_save_lead(final_data, campaign)
        print "******************\n", rdata_logger, "************************\n"
        utils.response_logger.info(rdata_logger)
        return HttpResponse(response)
    except Exception, e:
        return HttpResponse(simplejson.dumps({'success': False, 'error' : str(e)}))
   

def normalize_api_data(rdata):
    rdata_logger = ""
    response = ""
    rdata_logger += simplejson.dumps(rdata)
    
    if not rdata.get('app_id'):
        fake_app_id = "NA" + hashlib.md5().hexdigest()[:10]
        rdata['app_id'] = fake_app_id
        rdata['application_id'] = fake_app_id
    #if not rdata.get('app_id'):
    #    response = simplejson.dumps({'success' : False, 'error' : "Application ID is missing"})
    #    rdata_logger += "\n" + response
    #    return (None, rdata_logger, response)

    final_data = dict([(putils.API_FIELD_DICT.get(k, k),v) for k,v in rdata.items()])

    if rdata.get('needhelp_details'):
        if rdata['needhelp_details'].get('mobile'):
            final_data.update(rdata['needhelp_details'])
    return final_data, response, rdata_logger


# 6733 old conclude save using only for reports function -- uploas clecnup
def conclude_save_lead_old(final_data, campaign, row=-1):
    rlog = ""
    rejected, reason = putils.reject_data(final_data)
    if rejected:
        response = "Rejected - Reason - %s\n" % (reason)
        rlog += response
        return rlog, json.dumps({'success': False, 'error': rlog})

    customer, created = Customer.objects.get_or_create(mobile = final_data['mobile'])
    if final_data.get('first_name'):
        customer.name = "%s %s" % (final_data.get('first_name'), final_data.get('last_name'))
    if final_data.get('email'):
        customer.email = final_data.get('email')
    customer.save()

    # Close all older data points (which are not concluded) as duplicate_api
    assigned_to = None
    campaign_name = str(campaign)
    if final_data.get('page_name'):
        page_weightage_value = ''
        page_id_value = ''
        if campaign_name == 'D2C':
            try:
                page_weightage_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][0]
                page_id_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][2]
                print "D2C",page_weightage_value
            except Exception as e:
                page_weightage_value = 0
                page_id_value = 0
                print "Page weight zero for these application", final_data['page_name'],final_data['application_id']
        elif campaign_name == 'C2C':
            page_weightage_value = 100
            try:
                page_id_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][2]
            except Exception as e:
                page_id_value = 0
                print "C2C error",e
        else:
             page_weightage_value = 0
             page_id_value = 0

    else:
        return json.dumps({'success':True, 'error':'No page name'})

    for cd in CampaignData.objects.filter(customer=customer).order_by('uploaded_on'):
        if cd.status in ['FRESH', 'IN_PROCESS'] and final_data.get('oneshotpayment') == '':
            rlog += "Row : %s , Customer Exists, Disposing old as DUPLICATE_API\n" % (str(row))
            cd.dispose_manually("DUPLICATE_API")
            if cd.assigned_to:
                publisher.lrem("inprocess_user%s" % cd.assigned_to.id, cd.id)
                for cu in User.objects.filter(userprofile__role='CALLER'):
                    publisher.lrem("fresh_user%s" % cu.id, cd.id)
        if cd.assigned_to and cd.assigned_to.is_active and cd.assigned_to.username != 'system':
            assigned_to = cd.assigned_to
    
    d = CampaignData(
            status = "FRESH",
            application_id = final_data.get('application_id',''),
            data = simplejson.dumps(final_data),
            campaign = campaign,
            next_call_time = datetime.datetime.now(),
            customer = customer,
            is_taken = False,
            assigned_to = assigned_to,
            site_id = final_data.get('site_id',''),
            page_weight = page_weightage_value,
            page_id = page_id_value
    )
    d.save()

    if final_data.get('oneshotpayment') == 'Y' or final_data.get('pay_status') == 'Y':
        for cd in CampaignData.objects.filter(Q(customer=customer) & ~Q(status="CONCLUDED")).order_by('uploaded_on'):
            cd.dispose_manually("PAYMENT_SUCCESSFUL")
            rlog += "Row : %s , Customer Exists, Disposing old as Payment successful of %s\n" % (str(row),cd.id)
        d.status = "CONCLUDED"
        d.last_call_disposition = "PAYMENT_SUCCESSFUL"
        d.save()

    if final_data.get('created_on'):
        d.created_on = datetime.datetime.strptime(final_data['created_on'],"%d/%m/%Y %H:%M:%S")
        d.save()
    if final_data.get('online_created_date'):
        d.online_created_date = datetime.datetime.strptime(final_data['online_created_date'],"%m%d%Y %H:%M:%S")
        d.save()

    rlog += "Row : %s , Creating new Record ID : %s" % (str(row), str(d.id))

    #  Take all callers assigned to that campaign, check if, siteid for any user matches the one in data
    #  if siteid matches, assign it to him, else assign it to everyone
    matching_users = []
    for u in campaign.callers.all():
        campaign_condition = dict(u.userprofile.get_data('call_condition',[])).get('campaign_%s' % campaign.id,'')
        for cond in campaign_condition.split(','):
            if final_data.get('site_id') == cond.strip():
                matching_users.append(u)

    if matching_users:
        for mu in matching_users:
            publisher.lpush("fresh_user%s" % mu.id, d.id)
    else:
        for mu in campaign.callers.all():
            publisher.lpush("fresh_user%s" % mu.id, d.id)

    publisher.set("data%s" % d.id, simplejson.dumps(d.mini_json()))
    return rlog, json.dumps({'success': True})




# 6733
# conclude save lead for new and old d2C
def conclude_save_lead(final_data, campaign, insurer, row=-1):
    rlog = ""
    rejected, reason = putils.reject_data(final_data, insurer)  # insurer added to VAPT project  to remove special charactor  27 april 2017
    if rejected:
        response = "Rejected - Reason - %s\n" % (reason)
        rlog += response
        return rlog, json.dumps({'success': False, 'error': rlog})

    customer, created = Customer.objects.get_or_create(mobile = final_data['mobile'])
    if final_data.get('first_name'):
        customer.name = "%s %s" % (final_data.get('first_name'), final_data.get('last_name'))
    if final_data.get('email'):
        customer.email = final_data.get('email')
    customer.save()
    # Close all older data points (which are not concluded) as duplicate_api
    assigned_to = None
    campaign_name = str(campaign)
    if final_data.get('page_name'):
        page_weightage_value = ''
        page_id_value = ''
        if campaign_name == 'D2C':
            try:
                page_weightage_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][0]
                page_id_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][2]
                print "D2C",page_weightage_value
            except Exception as e:
                page_weightage_value = 0
                page_id_value = 0
                print "Page weight zero for these application", final_data['page_name'],final_data['application_id']
        elif campaign_name == 'C2C':
            page_weightage_value = 100
            try:
                page_id_value = putils.PAGE_WEIGHTAGE[final_data['page_name'].lower()][2]
            except Exception as e:
                page_id_value = 0
                print "C2C error",e
        else:
             page_weightage_value = 0
             page_id_value = 0

    else:
        return json.dumps({'success':True, 'error':'No page name'})

    for cd in CampaignData.objects.filter(customer=customer).order_by('uploaded_on'):
        if cd.status in ['FRESH', 'IN_PROCESS'] and final_data.get('oneshotpayment') == '':

            # LMS Data Dump project may 2017 - ID -  293

            if final_data.get('product_category') == cd.product_name and final_data.get('mobile') == customer.mobile:
 
                rlog += "Row : %s , Customer Exists, Disposing old as DUPLICATE_API\n" % (str(row))
                cd.dispose_manually("DUPLICATE_API")
                if cd.assigned_to:
                    publisher.lrem("inprocess_user%s" % cd.assigned_to.id, cd.id)
                    for cu in User.objects.filter(userprofile__role='CALLER'):
                        publisher.lrem("fresh_user%s" % cu.id, cd.id)
        if cd.assigned_to and cd.assigned_to.is_active and cd.assigned_to.username != 'system':
            assigned_to = cd.assigned_to
    
    d = CampaignData(
            status = "FRESH",
            application_id = final_data.get('application_id',''),
            data = simplejson.dumps(final_data),
            campaign = campaign,
            next_call_time = datetime.datetime.now(),
            customer = customer,
            is_taken = False,
            assigned_to = assigned_to,
            site_id = final_data.get('site_id',''),
            page_weight = page_weightage_value,
            page_id = page_id_value,
            insurer_data = insurer, #6733 insurer data
            product_name = final_data.get('product_category','') # 6733
            )  
    d.save()
    if final_data.get('oneshotpayment') == 'Y' or final_data.get('pay_status') == 'Y':
        for cd in CampaignData.objects.filter(Q(customer=customer) & ~Q(status="CONCLUDED")).order_by('uploaded_on'):
            cd.dispose_manually("PAYMENT_SUCCESSFUL")
            rlog += "Row : %s , Customer Exists, Disposing old as Payment successful of %s\n" % (str(row),cd.id)
        d.status = "CONCLUDED"
        d.last_call_disposition = "PAYMENT_SUCCESSFUL"
        d.save()

    if final_data.get('created_on'):
        d.created_on = datetime.datetime.strptime(final_data['created_on'],"%d/%m/%Y %H:%M:%S")
        d.save()
    if final_data.get('online_created_date'):
        d.online_created_date = datetime.datetime.strptime(final_data['online_created_date'],"%m%d%Y %H:%M:%S")
        d.save()
    rlog += "Row : %s , Creating new Record ID : %s" % (str(row), str(d.id))
    #  Take all callers assigned to that campaign, check if, siteid for any user matches the one in data
    #  if siteid matches, assign it to him, else assign it to everyone
    matching_users = []
    for u in campaign.callers.all():
         campaign_condition = dict(u.userprofile.get_data('call_condition',[])).get('campaign_%s' % campaign.id,'')
         for cond in campaign_condition.split(','):
             if final_data.get('site_id') == cond.strip():
                 matching_users.append(u)
    if matching_users:
        for mu in matching_users:
                publisher.lpush("fresh_user%s" % mu.id, d.id)
    else:
        for mu in campaign.callers.all():
                publisher.lpush("fresh_user%s" % mu.id, d.id)

    publisher.set("data%s" % d.id, simplejson.dumps(d.mini_json()))
    return rlog, json.dumps({'success': True})         




@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_save_notes(request):
    notes = request.POST['notes']
    up = request.user.userprofile
    up.set_data('notes', notes)
    return HttpResponse("OK")

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_activity_log(request):
    atype = request.POST['type']
    action = request.POST['action']
    if action == "START":
        tt = TimeTracker.objects.filter(user=request.user, type=atype, end_time__isnull=True)
        if not tt:
            tt = TimeTracker(
                type = atype,
                user = request.user,
                start_time = datetime.datetime.now(),
            )
            tt.save()
        else:
            tt = tt[0]
            tt.start_time = datetime.datetime.now()
            tt.save()

    if action == "STOP":
        tt = TimeTracker.objects.get(user=request.user, type=atype, end_time__isnull=True)
        tt.end_time = datetime.datetime.now()
        tt.save()
    return HttpResponse("OK")

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_daily_stats(request):
    from django.db import connection
    cursor = connection.cursor()
    u = request.user
    time_track_today = TimeTracker.objects.filter(user=u, start_time__gte=datetime.datetime.combine(datetime.datetime.now(), datetime.time.min), end_time__lte=datetime.datetime.combine(datetime.datetime.now(), datetime.time.max))
    daily = {}
    for t in time_track_today:
        if not daily.get(t.type):
            daily[t.type] = t.end_time-t.start_time
        else:
            daily[t.type] += (t.end_time-t.start_time)

    time_track_month = TimeTracker.objects.filter(user=u, start_time__month=datetime.date.today().month, start_time__year=datetime.date.today().year)
    monthly = {}
    for t in time_track_month:
        if not monthly.get(t.type):
            monthly[t.type] = t.end_time-t.start_time
        else:
            if t.end_time:
            	monthly[t.type] += (t.end_time-t.start_time)
            else: 
            	monthly[t.type] += (datetime.datetime.now()-t.start_time)

    rval = {}
    rval['daily'] = [(ttype, math.ceil(tval.seconds/60.0)) for ttype, tval in daily.items()]
    rval['monthly'] = [(ttype, math.ceil(tval.seconds/60.0)) for ttype, tval in monthly.items()]
    return HttpResponse(simplejson.dumps(rval))

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_monthly_stats(request):
    pass

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_yearly_stats(request):
    pass

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_load_waiting_calls(request):
    inp_q = Q()
    fresh_q = Q()
    pg_type = Q()
    cm_type = Q()
    cl_type = Q()

    remove_campaign_ids = request.POST.get('campaign_ids', '').split(",")
    if request.POST.get('fresh_latest_date'):
        fresh_latest_date = datetime.datetime.strptime(request.POST['fresh_latest_date'], "%d-%m-%Y %H:%M")
        fresh_q = Q(next_call_time__gte = fresh_latest_date)
    else:
        fresh_latest_date = None
    if request.POST.get('in_process_latest_date'):
        in_process_latest_date = datetime.datetime.strptime(request.POST['in_process_latest_date'], "%d-%m-%Y %H:%M")
        inp_q = Q(next_call_time__gte = in_process_latest_date)
    else:
        in_process_latest_date = None

    if len(remove_campaign_ids) == 1 and remove_campaign_ids[0] == "":
        remove_campaign_ids = []
    else:
        inp_q = inp_q & ~Q(id__in=remove_campaign_ids)
        fresh_q = fresh_q & ~Q(id__in=remove_campaign_ids)
    if request.POST.get('page_type'):
        pg_type = Q(page_id=request.POST.get('page_type'))

    if request.POST.get('camp_type'):
        cm_type = Q(campaign=request.POST.get('camp_type'))

    if request.POST.get('call_type'):
        cl_type = Q(last_call_head_disposition=request.POST.get('call_type'))


    del_inprocess = publisher.delete("inprocess_user%s" % request.user.id, 0, -1)
    # Calls belonging to the caller
    #            next_call_time__gte = datetime.datetime.combine(datetime.date.today(), datetime.time.min),
    today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
    in_process_calls = CampaignData.objects.filter(
        Q(
            status = 'IN_PROCESS',

            next_call_time__lte = today_start+datetime.timedelta(days=1),
            is_taken = False,
            assigned_to = request.user
        ) & inp_q
    ).order_by("-next_call_time")


    existing_inprocess = publisher.lrange("inprocess_user%s" % request.user.id, 0, -1)
    dids = ["data%s" % cd.id for cd in in_process_calls]
    if dids:
        data_store = publisher.mget(dids)
        for ds, cip in zip(data_store, in_process_calls):
            if not ds:
                publisher.set("data%s" % cip.id, simplejson.dumps(cip.mini_json()))
            if str(cip.id) not in existing_inprocess:
                publisher.lpush("inprocess_user%s" % request.user.id, cip.id)
                existing_inprocess.append(cip.id)

    #from IPython.frontend.terminal.embed import InteractiveShellEmbed
    #InteractiveShellEmbed()()
    # Fresh calls which have not been taken
    fresh_calls = CampaignData.objects.filter(
        Q(
            next_call_time__lte = datetime.datetime.now(),
            status = 'FRESH',
        ) &
        (
            Q(assigned_to__isnull = True) |
            Q(assigned_to = request.user)
        ) & pg_type & cm_type & cl_type & fresh_q #& fresh_q
        ).order_by("-page_weight","next_call_time") #-next_call_time

    existing_fresh = publisher.lrange("fresh_user%s" % request.user.id, 0, -1)
    dids = ["data%s" % cd.id for cd in fresh_calls]
    if dids:
        data_store = publisher.mget(dids)
        for ds, cip in zip(data_store, fresh_calls):
            if not ds:
                publisher.set("data%s" % cip.id, simplejson.dumps(cip.mini_json()))
            if str(cip.id) not in existing_fresh:
                publisher.rpush("fresh_user%s" % request.user.id, cip.id)
                existing_fresh.append(cip.id)

    inprocess_data = [cd.mini_json() for cd in in_process_calls]
    fresh_data = [cd.mini_json() for cd in fresh_calls]

    return HttpResponse(simplejson.dumps({'inprocess':inprocess_data, 'fresh':fresh_data}))

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_load_calls(request):
    fresh_channel = "fresh_user%s" % request.user.id
    inprocess_channel = "inprocess_user%s" % request.user.id

    fresh_data = publisher.lrange(fresh_channel, 0, -1)
    inprocess_data = publisher.lrange(inprocess_channel, 0, -1)

    if request.POST.get('campaign_ids'):
        remove_campaign_ids = request.POST.get('campaign_ids').split(",")
        inprocess_data = [x for x in inprocess_data if x not in remove_campaign_ids]
        fresh_data = [x for x in fresh_data if x not in remove_campaign_ids]

    inprocess_data = [publisher.get("data%s" % cd) for cd in list(inprocess_data)[:100]]
    fresh_data = [publisher.get("data%s" % cd) for cd in list(fresh_data)[:100]]
    return HttpResponse(simplejson.dumps({'inprocess':inprocess_data, 'fresh':fresh_data}))

@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_load_initial_calls(request):
#    publisher.flushdb()
    
    campaigns = request.user.caller_for_campaigns.all()

    condition_data = dict(request.user.userprofile.get_data('call_condition',[]))
    conditional_clause = Q()

    all_site_ids = set([val['site_id'] for val in CampaignData.objects.values('site_id').distinct()])

    for camp in Campaign.objects.all():
        campaign_conditional_present = False
        if ("campaign_%s" % camp.id) in condition_data.keys():
            campaign_conditional_present = True
            other_user_site_ids = []
            for cc in camp.callers.all():
                site_ids = dict(cc.userprofile.get_data('call_condition',[])).get('campaign_%d' % (camp.id))
                if site_ids:
                    other_user_site_ids.extend(site_ids.split(","))
            other_user_site_ids = set(other_user_site_ids)
            user_site_ids = set(condition_data["campaign_%s" % (camp.id)].split(","))

            exclude_site_ids = other_user_site_ids.difference(user_site_ids)
            for site_id in exclude_site_ids:
                if site_id:
                    conditional_clause = conditional_clause & ~(Q(site_id=site_id) & Q(campaign_id=camp.id))

            include_site_ids = all_site_ids.difference(other_user_site_ids).union(user_site_ids)
            for site_id in include_site_ids:
                conditional_clause = conditional_clause | (Q(site_id=site_id) & Q(campaign_id=camp.id))

        else:
            for cc in camp.callers.all():
                site_ids = dict(cc.userprofile.get_data('call_condition',[])).get('campaign_%d' % (camp.id))
                if site_ids:
                    for site_id in site_ids.split(","):
                        campaign_conditional_present = True
                        if site_id:
                            conditional_clause = conditional_clause & ~(Q(site_id=site_id) & Q(campaign_id=camp.id))
        if not campaign_conditional_present:
            if camp in campaigns:
                conditional_clause = conditional_clause | Q(campaign_id=camp.id)
            else:
                conditional_clause = conditional_clause & ~Q(campaign_id=camp.id)


    # Fresh calls which have not been taken
    fresh_calls = CampaignData.objects.filter(
        Q(
            #campaign__in = list(campaigns),
            status = 'FRESH',
            next_call_time__lte = datetime.datetime.now()
        ) &
        (
            Q(assigned_to__isnull = True) |
            Q(assigned_to = request.user)
        )).filter(conditional_clause).order_by("-page_weight","next_call_time") #add "-page_weight"

    del_inprocess = publisher.delete("inprocess_user%s" % request.user.id, 0, -1)
    #print "FRESH CALL IDS", fresh_calls.query
    today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
#        next_call_time__gte = datetime.datetime.combine(datetime.date.today(), datetime.time.min),
    in_process_calls = CampaignData.objects.filter(Q(
        status = 'IN_PROCESS',

        next_call_time__lte = today_start+datetime.timedelta(days=1),
        assigned_to = request.user,
    )).order_by("-next_call_time")
     
    # in_process_calls = CampaignData.objects.filter(
    #     status = 'IN_PROCESS',
    #     next_call_time__lte = datetime.datetime.now(),
    #     assigned_to = request.user,
    # ).order_by("-next_call_time")


   
    existing_inprocess = publisher.lrange("inprocess_user%s" % request.user.id, 0, -1)
    data_store = []
    if in_process_calls:
        data_store = publisher.mget(["data%s" % cd.id for cd in in_process_calls])

    for ds, cip in zip(data_store, in_process_calls):
        if not ds:
            publisher.set("data%s" % cip.id, simplejson.dumps(cip.mini_json()))
        if str(cip.id) not in existing_inprocess:
            publisher.rpush("inprocess_user%s" % request.user.id, cip.id)
#            pubisher.sort("inprocess_user%s" % request.user.id,today_start)
            existing_inprocess.append(cip.id)

    existing_fresh = publisher.lrange("fresh_user%s" % request.user.id, 0, -1)
    data_store = []
    if fresh_calls:
        data_store = publisher.mget(["data%s" % cd.id for cd in fresh_calls])
    for ds, cip in zip(data_store, fresh_calls):
        if not ds:
            publisher.set("data%s" % cip.id, simplejson.dumps(cip.mini_json()))
        if str(cip.id) not in existing_fresh:
            publisher.rpush("fresh_user%s" % request.user.id, cip.id)
            existing_fresh.append(cip.id)

    fresh_data = [] #[fd.mini_json() for fd in fresh_calls]
    in_process_data = [] #[pd.mini_json() for pd in in_process_calls]

    call_data = [["in_process", "In Process", in_process_data],
                ["fresh", "Fresh", fresh_data]]

    return HttpResponse(simplejson.dumps(call_data))

@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_search(request):
    response = HttpResponse()
    if request.POST:
        search_form = SearchForm(request.POST)
    if request.GET:
        search_form = SearchForm(request.GET)
    if search_form.is_valid():
        query = search_form.get_query(request)
        d = search_form.cleaned_data
        if d['limit_calls'] :
            calls = CampaignData.objects.filter(query).order_by("next_call_time")[:d['limit_calls']]
        else:
            calls = CampaignData.objects.filter(query).order_by("next_call_time")
        #print calls.query
        #print calls
        search_data = [d.mini_json() for d in calls]
        call_data = ["search_data", "Search Data", search_data]
        return HttpResponse(simplejson.dumps(call_data))
    else:
        print search_form.errors
        return HttpResponse(json.dumps({'success': False, 'errors': search_form.errors}))

@cache_page(30)
@vary_on_headers('Cookie')
@login_required
@utils.profile_type_only("CALLER")
def caller_dashboard(request):
    call_data = (("in_process", "In Process"),
                ("fresh", "Fresh"))
    data = None
    campaigns = request.user.caller_for_campaigns.all()
    ld_selector = []
    pg_selector = []

    for ld in list(set(putils.REV_DISTRIBUTION_MAP.values())):
        ld_selector.append((ld, putils.VERBOSE_DISPOSITION[ld]))
    for pgk,pgv in putils.PAGE_WEIGHTAGE.items():
        pg_selector.append((pgv[2],pgv[1]))
    pg_selector.sort(reverse=True)
    if request.user.userprofile.data:
        data = simplejson.loads(request.user.userprofile.data)
    today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min)

    in_process_calls = CampaignData.objects.filter(Q(
            status = 'IN_PROCESS',
            next_call_time__gte = today_start,
            next_call_time__lte = today_start+datetime.timedelta(days=1),
            assigned_to = request.user,
            )).order_by("next_call_time")
    in_process_calls = [cd.mini_json() for cd in in_process_calls]
    return render_to_response("core/caller_dashboard.html", {
            'call_data' : call_data,
            'DISPOSITION_MAP' : putils.VISIBLE_DISPOSITION_MAP,
            'user_data' : data,
            'ld_selector' : ld_selector,
            'campaigns' : campaigns,
            'pg_selector':pg_selector,
            'in_process_calls':in_process_calls,
        },
        context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only("REPORT", 'MANAGER', 'ADMIN')
def report_dashboard(request):
    if request.method == 'GET':
        form = ReportFiltersForm(request.GET)
        if form.is_valid():
            filename = "data_dump.xls"
            def calculate():
                from_time = form.cleaned_data['start_date']
                to_time = form.cleaned_data['end_date'] + datetime.timedelta(days = 1)
                data_fields = DataForm().fields.keys()

                object_field = data_fields[:-2]
                data_fields.append("Created on")
                data_row_list = []
                for d in Data.objects.filter(uploaded_on__gte=from_time, uploaded_on__lte=to_time):
                    cdata = json.loads(d.data)
                    row = [cdata.get(cof,'') for cof in object_field]
                    row.extend([d.dataattr.last_call_disposition, d.dataattr.next_call_time, d.uploaded_on])
                    data_row_list.append(row)

                #print filename
                render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), data_fields, data_row_list)

            thread.start_new_thread(calculate,())
            return HttpResponse("%s/static/downloads/%s" % (settings.SITE_URL, filename))
        else:
            print form.errors
    else:
        form = ReportFiltersForm()
    error_msg = ''
    return render_to_response('core/select_daterange.html', {'form' : form, 'error_msg': error_msg},
            context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only("CALLER","MANAGER" ,'ADMIN')
def call_detail(request, pid):
    campaign_data = get_object_or_404(CampaignData, pk=pid)
    state_data = json.loads(campaign_data.data)
    call_form = CallForm(initial = {
        'name' : campaign_data.customer.name,
        'alt_numbers' : state_data.get('alt_numbers',''),
        'likely_date_of_payment' : state_data.get('likely_date_of_payment',''),
        'notes' : state_data.get('notes',''),
    })
    personal_fields = [(fl[2], fl[1]) for fl in putils.FIELD_LIST[:12]]
    product_fields = [(fl[2], fl[1]) for fl in putils.FIELD_LIST[14:]]

    template_data = render_to_string('core/call_form.html', {
        'render_form' : False,
        'cdata' : campaign_data,
        'data': json.loads(campaign_data.data),
        'personal_fields' : personal_fields,
        'product_fields' : product_fields,
        'call_form' : call_form,
    }, context_instance=RequestContext(request))
    return HttpResponse(simplejson.dumps({'success':True, 'id' : campaign_data.id, 'message':template_data}))

@login_required
@utils.profile_type_only("CALLER")
def call_form(request, pid):
    campaign_data = get_object_or_404(CampaignData, pk=pid)
    if request.POST:
        call_form = CallForm(request.POST)
        if call_form.is_valid():
            print call_form.cleaned_data
            campaign_data.save_call_form(request, call_form)
            publisher.set("data%s" % campaign_data.id, simplejson.dumps(campaign_data.mini_json()))
            return HttpResponse(json.dumps({'success':True, 'id':campaign_data.id}))
        else:
            return HttpResponse(json.dumps({'success':False, 'errors': call_form.errors}))
    else:
        update_count = CampaignData.objects.filter(
            Q(id=campaign_data.id, status__in=['IN_PROCESS','FRESH']) &
            (
                Q(is_taken=False, assigned_to=request.user) |
                Q(is_taken=False, assigned_to__isnull=True) |
                Q(is_taken=True, assigned_to=request.user)
            )
        ).update(is_taken=True, assigned_to=request.user)
        campaign_data = get_object_or_404(CampaignData, pk=pid)

        publisher.lrem("inprocess_user%s" % request.user.id, campaign_data.id)
        publisher.lrem("fresh_user%s" % request.user.id, campaign_data.id)
        if campaign_data.assigned_to:
            publisher.lrem("inprocess_user%s" % campaign_data.assigned_to.id, campaign_data.id)
            publisher.lrem("fresh_user%s" % campaign_data.assigned_to.id, campaign_data.id)

   #Remove all user-campaign mapping existing for a campaign_data point
        campaign = campaign_data.campaign
        for u in campaign.callers.all():
            publisher.lrem("fresh_user%s" % u.id, campaign_data.id)
            publisher.lrem("inprocess_user%s" % u.id, campaign_data.id)

        if update_count == 0:
            return HttpResponse(json.dumps({'success':False, 'id': campaign_data.id}))

        state_data = json.loads(campaign_data.data)
        call_form = CallForm(initial = {
            'name' : campaign_data.customer.name,
            'alt_numbers' : state_data.get('alt_numbers',''),
            'likely_date_of_payment' : state_data.get('likely_date_of_payment',''),
            'notes' : state_data.get('notes',''),
        })
        personal_fields = [(fl[2], fl[1]) for fl in putils.FIELD_LIST[:12]]
        product_fields = [(fl[2], fl[1]) for fl in putils.FIELD_LIST[13:]]

        template_data = render_to_string('core/call_form.html', {
            'render_form' : True,
            'cdata' : campaign_data,
            'data': json.loads(campaign_data.data),
            'personal_fields' : personal_fields,
            'product_fields' : product_fields,
            'make':'make',
            'call_form' : call_form,
            'email':json.loads(campaign_data.data)['email'],
        }, context_instance=RequestContext(request))
        return HttpResponse(json.dumps({'success':True, 'id' : campaign_data.id, 'message':template_data}))

@login_required
@utils.profile_type_only('MANAGER', 'ADMIN')
def manager_dashboard(request):
    user_list = User.objects.filter(userprofile__isnull=False, is_active=True)
    return render_to_response("core/mdashboard.html", {
            'user_list' : user_list,
            'active' : 'users',
        },
        context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only('MANAGER', 'ADMIN')
def preset_upload(request):
    campaign_list = request.user.admin_for_campaigns.all()
    return render_to_response("core/mpreset_upload.html", {
            'active' : 'preset_upload',
            'campaign_list' : campaign_list,
        },
        context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only('MANAGER' , 'ADMIN')
def manager_reports(request):

    product_details = Product.objects.all() # LMS desposition New D2C   ID -  293
    campaigns = Campaign.objects.all()
    return render_to_response("core/mreports.html", {
            'active' : 'report',
            'campaigns' : campaigns,
            'product_details':product_details     # LMS desposition New D2C   ID -  293
        },
        context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only('MANAGER' ,'ADMIN')
def upload_history(request, uid=None):
    uph_objects = UploadFile.objects.order_by('-created_on')
    paginator = Paginator(uph_objects, 50)
    try:
        page = int(request.GET.get('page', '1'))
    except ValueError:
        page = 1
    try:
        uph_list = paginator.page(page)
    except (EmptyPage, InvalidPage):
        uph_list = paginator.page(paginator.num_pages)

    uph = None
    if uid:
        uph = UploadFile.objects.get(id=uid)
        uph.output = json.loads(uph.output)
        uph.count = {}
        uph.count['duplicate'] = len(uph.output.get('duplicates',[]))
        uph.count['rejected'] = sum([res.find('Rejected') >= 0 for res in uph.output.get('response',[])])
        uph.count['fresh'] = sum([res.find('Creating new Record') >= 0 for res in uph.output.get('response',[])])
    return render_to_response("core/mupload_history.html", {
            'uph_list' : uph_list,
            'uph' : uph,
            'active' : 'upload_history'
        },
        context_instance=RequestContext(request)
    )

# @never_cache
# @login_required
# @csrf_exempt
# @utils.profile_type_only("MANAGER")
# def user_sessions(request):
#      cur= connection.cursor()
#      uname = User.objects.filter(userprofile__role='CALLER', is_active=True)
#      form = request.POST

#      if request.method == 'POST':
#           try:
#                username = get_object_or_404(User, pk=request.POST.get('username'))
#                u_name = username.username
#                query1 = "select lms.auth_user.id from lms.auth_user where lms.auth_user.username = '%s';" % (u_name)
#                cur.execute(query1)
#                query1_result = cur.fetchall()
#                for i in query1_result:
#                     query = "delete from lms.core_usersession where lms.core_usersession.user_id = %s;" % (i)
#                     cur.execute(query)
#                     msg = "Selected user "+u_name +"'s session has been deleted"
#                     return render_to_response("core/user_session.html",
#                          {
#                               'user_names' : uname,
#                               'success':msg,
#                          },context_instance=RequestContext(request))
#           except:
#                 return HttpResponseRedirect("/manager/dashboard/user-session/")
#      return render_to_response("core/user_session.html",
#              {
#                   'user_names' : uname,
#              },context_instance=RequestContext(request))



@login_required
@utils.profile_type_only('MANAGER', 'ADMIN')
def manager_reassign_calls(request):
    if request.POST:
        #print request.POST
        assign_to = User.objects.get(id=request.POST['to'])
        pids = filter(lambda x: x.strip()!='', request.POST['pids'].split(','))
        n = 50
        pid_groups = [pids[i:i+n:] for i in range(0, len(pids), n)]

        existing_calls = publisher.lrange("inprocess_user%s" % assign_to.id, 0, -1)
        for gpid in pid_groups:
            CampaignData.objects.filter(id__in=gpid).update(assigned_to=assign_to)
            for cd in CampaignData.objects.filter(id__in=gpid):
                for u in cd.campaign.callers.all():
                    publisher.lrem("inprocess_user%s" % u.id, cd.id)
                    publisher.lrem("fresh_user%s" % u.id, cd.id)
                if str(cd.id) not in existing_calls:
                    publisher.rpush("inprocess_user%s" % assign_to.id, cd.id)
                publisher.set("data%s" % cd.id, simplejson.dumps(cd.mini_json()))

        return HttpResponse('OK')
    else:
        search_form = SearchForm()
        return render_to_response("core/mreassign.html", {
                'active' : 'reassign_calls',
                'search_form' : search_form,
            },
            context_instance=RequestContext(request)
        )

@login_required
@utils.profile_type_only('MANAGER', 'ADMIN')
def ajax_user_add(request, uid=None):
    if request.POST:
        if uid:
            uform = UserManagementForm(uid, request.POST)
        else:
            uform = UserManagementForm(None, request.POST)
        if uform.is_valid():
            uform.save()
            return HttpResponse(json.dumps({'success':True}))
        else:
            print uform.errors
            return HttpResponse(json.dumps({'success':False, 'errors':uform.errors}))
    else:
        if uid:
            uform = UserManagementForm(uid)
        else:
            uform = UserManagementForm()
   
    template_data = render_to_string("core/ajax_user_form.html", {
            'uform' : uform,
        },
        context_instance=RequestContext(request)
    )
    return HttpResponse(json.dumps({'success':True, 'form': template_data}))

def setup_upload(request, cid):
    campaign = Campaign.objects.get(id=cid)
    upload_form = UploadForm()
    if request.POST:
        conf = lutils.save_model_config(campaign, request.POST)
        return HttpResponse('OK')
    else:
        field_list = putils.FIELD_LIST
        return render_to_response("core/mupload_config.html",{
                'field_list' : field_list,
                'campaign' : campaign,
                'upload_form' : upload_form,
                'active' : 'upload_config',
            },
            context_instance=RequestContext(request),
        )

def setup_upload_edit(request, cid, uid):
    upload_form = UploadForm()
    campaign = Campaign.objects.get(id=cid)
    upload_schema = UploadSchema.objects.get(id=uid)
    config_data = simplejson.loads(upload_schema.raw_data)

    if request.POST:
        mc = lutils.save_model_config(campaign, request.POST, instance=upload_schema)
        return HttpResponse('OK')
    else:
        field_list = putils.FIELD_LIST
        return render_to_response("core/mupload_config.html",{
                'field_list' : field_list,
                'm' : upload_schema,
                'field_order' : [str(i) for i in config_data['list_order']],
                'include_fields' : config_data['include_fields'],
                'format_fields' : config_data['format_fields'],
                'campaign' : campaign,
                'upload_form' : upload_form,
            },
            context_instance=RequestContext(request),
        )

class MyUpload(Xl2Python):
    pass

    def clean_mobile(self, val):
        return str(val)[:10]

    def clean_dob_yy(self, val):
        dob_mm_dd = "%(dob_dd)s/%(dob_mm)s" % (self.current_row)
        self.current_row['dob'] = "%s/%s" % (dob_mm_dd, val)
        return val

    def clean_created_on(self, val):
        if val:
            return datetime.datetime.strptime(val, "%Y-%m-%d %H:%M:%S.0").strftime("%d/%m/%Y %H:%M:%S")
        else:
            return None

class NEWSYSTEMUpload(Xl2Python):
    pass

    def clean_mobile(self, val):
        return str(val)[:10]

    def clean_dob(self, val):
        return val.split(" ")[0]

    def clean_created_on(self, val):
        if val:
            return datetime.datetime.strptime(val, "%d/%m/%Y %H:%M:%S").strftime("%d/%m/%Y %H:%M:%S")
        else:
            return None

class PSMUpload(Xl2Python):
    pass

    def clean_mobile(self, val):
        return str(val)[:10]

    def clean_dob_yy(self, val):
        dob_mm_dd = "%(dob_dd)s/%(dob_mm)s" % (self.current_row)
        self.current_row['dob'] = "%s/%s" % (dob_mm_dd, val)
        return val

    def clean_created_on(self, val):
        if val:
            return datetime.datetime.strptime(val, "%Y-%m-%d %H:%M:%S.0").strftime("%d/%m/%Y %H:%M:%S")
        else:
            return None

def upload_cleanup(campaign, xlm, upfile):
    duplicate_count = 0
    response = []
    dup_row = []
    if xlm.is_valid():
        #print "=========>", xlm.cleaned_data
        rrow = 0
        dedup_data = []
        app_dict = {}
        mobile_dict = {}
        xdata = xlm.cleaned_data[:]
        xdata.reverse()
        total_rows = len(xdata)
        for r in xdata:
            row = total_rows - rrow
            if r.get('application_id') and app_dict.has_key(r['application_id']):
                dup_row.append(row)
                rrow += 1
                continue
            if mobile_dict.has_key(r['mobile']):
                dup_row.append(row)
                rrow += 1
                continue
            if r.get('application_id'):
                app_dict[r['application_id']] = 1
            mobile_dict[r['mobile']] = 1
            dedup_data.append((row,r))
            rrow += 1

        duplicate_count = len(dup_row)
        dedup_data.reverse()
        for rcount, rdata in dedup_data:
            # 6733 old conclude point 
            resp = conclude_save_lead_old(rdata, campaign, rcount)
            print "****************\n", resp, "****************\n"
            utils.response_logger.info(resp)
            response.append(resp)
    else:
        print "ERRORS DATA => " , xlm.errors

    upfile.is_processed=True
    output_dict = {
        'error' : xlm.errors,
        'output' : xlm.cleaned_data,
        'duplicates' : dup_row,
        'response' : response,
    }
    output = simplejson.dumps(output_dict)
    upfile.output = output
    upfile.save()
    return output_dict

def campaign_preset_upload(request, upload_type):
    field_map_name = "%s_FIELD_MAP" % upload_type.upper()
    campaign = Campaign.objects.get(id=request.POST['campaign_id'])
    xlm = None
    xl_field_map = getattr(putils, field_map_name)
    print xl_field_map

    if request.FILES and request.FILES.get('upload_file'):

        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, created_by=request.user)
        upfile.save()
        upload_file = upfile.upload_file

        if field_map_name == "PSM_FIELD_MAP":
            xlm = PSMUpload(xl_field_map, upload_file)

        if field_map_name == "NEWSYSTEM_FIELD_MAP":
            xlm = NEWSYSTEMUpload(xl_field_map, upload_file)

        output = upload_cleanup(campaign, xlm, upfile)
        return HttpResponseRedirect('/manager/dashboard/upload-history/%s/?page=%s' % (str(upfile.id), '1'))

    upload_form = UploadForm()
    campaign_list = request.user.admin_for_campaigns.all()
    return render_to_response("core/mpreset_upload.html",{
            'upload_url': '/manager/dashboard/campaign/preset-upload/%s/' % (upload_type.upper()),
            'upload_form' : upload_form,
            'campaign' : campaign,
            'output' : output,
            'active' : 'preset_upload',
            'campaign_list' : campaign_list,
        },
        context_instance=RequestContext(request),
    )

def campaign_upload(request, cid, uid):
    campaign = Campaign.objects.get(id=cid)
    us = UploadSchema.objects.get(id=uid)
    response = ""
    xlm = None
    xl_field_map = dict([(int(k),v.replace('list_','',1)) for k,v in simplejson.loads(us.field_map).items()])

    if request.FILES and request.FILES.get('upload_file'):
        upload_file = request.FILES['upload_file']
        upfile = UploadFile(upload_file=upload_file, created_by=request.user)
        upfile.save()
        upload_file = upfile.upload_file

        xlm = MyUpload(xl_field_map, upload_file)
        campaign = Campaign.objects.get(id=cid)

        output = upload_cleanup(campaign, xlm, upfile)
        return HttpResponseRedirect('/manager/dashboard/upload-history/%s/?page=%s' % (str(upfile.id), '1'))

    upload_form = UploadForm()
    return render_to_response("core/campaign-upload.html",{
            'upload_form' : upload_form,
            'campaign' : campaign,
            'output' : output,
            'active' : 'preset_upload',
        },
        context_instance=RequestContext(request),
    )

@utils.profile_type_only('MANAGER', 'ADMIN')
def workload(request):
    fresh_data = [(camp, CampaignData.objects.filter(status="FRESH", assigned_to__isnull=True, campaign=camp).count()) for camp in Campaign.objects.all()]

    users = [(u,u.username) for u in User.objects.filter(userprofile__role='CALLER', is_active=True)]
    dt = datetime.datetime.combine(datetime.date.today(), datetime.time.min)

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__status__in=("IN_PROCESS","FRESH")).annotate(count = Count('campaigndata__id')).values('username', 'count')
    workload_total = dict([(d['username'], d['count']) for d in data])

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__status__in=("IN_PROCESS","FRESH")).annotate(count = Count('campaigndata__id')).values('campaigndata__status','username', 'count')
    workload_breakup = defaultdict(list)
    for d in data:
         workload_breakup[d['username']].append("%s = %s" % ((d['campaigndata__status']), d['count']))

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__next_call_time__gte=dt, campaigndata__next_call_time__lte=dt+datetime.timedelta(days=1), campaigndata__status="IN_PROCESS").annotate(count = Count('campaigndata__id')).values('username', 'count'
)
    workload_today = dict([(d['username'], d['count']) for d in data])

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__status__in=("IN_PROCESS","FRESH")).annotate(count = Count('campaigndata__id')).values('username','campaigndata__campaign__name', 'count')
    campaign_breakup = defaultdict(list)
    for d in data:
         campaign_breakup[d['username']].append("%s = %s"%(d['campaigndata__campaign__name'],d['count']))

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__next_call_time__gte=dt, campaigndata__next_call_time__lte=dt+datetime.timedelta(days=1)).annotate(count = Count('campaigndata__last_call_disposition')).values('campaigndata__last_call_disposition','username', 'count')

    status_breakup = defaultdict(list)
    for d in data:
        if d['campaigndata__last_call_disposition'] == '':
            d['campaigndata__last_call_disposition'] = 'FRESH'
        status_breakup[d['username']].append("%s = %s" % (d['campaigndata__last_call_disposition'], d['count']))

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__last_call_time__gte=dt, campaigndata__last_call_time__lte=dt+datetime.timedelta(days=1)).annotate(count = Count('campaigndata__id')).values('username', 'count')
    unique_called_today = dict([(d['username'], d['count']) for d in data])

    data = User.objects.filter(userprofile__role="CALLER", is_active=True).filter(campaigndata__last_call_time__gte=dt, campaigndata__last_call_time__lte=dt+datetime.timedelta(days=1)).annotate(count = Count('campaigndata__last_call_disposition')).values('campaigndata__last_call_disposition','username', 'count')
    disposition_breakup_data = [(d['username'], putils.REV_DISTRIBUTION_MAP.get(d['campaigndata__last_call_disposition'], 'SYSTEM'), d['count']) for d in data]
    #disposition_breakup_data = [(d['username'], d['campaigndata__last_call_disposition'], d['count']) for d in data]
    #print disposition_breakup_data
    dtmp = {}
    for d in disposition_breakup_data:
        if not dtmp.get(d[0]): dtmp[d[0]] = {}
        if not dtmp[d[0]].get(d[1]) : dtmp[d[0]][d[1]] = 0
        dtmp[d[0]][d[1]] += d[2]

    #print dtmp
    disposition_breakup = {}
    for k,v in dtmp.items():
        for i,j in v.items():
            if not disposition_breakup.get(k) : disposition_breakup[k] = []
            disposition_breakup[k].append("%s-%s" % (i,j))
    #structure [username, workload_total, workload_today, unique_called_today]
    data = []
    for u, uname in users:
        data.append([u, workload_total.get(uname,0), workload_today.get(uname,0), unique_called_today.get(uname,0), disposition_breakup.get(uname,''), status_breakup.get(uname,''),workload_breakup.get(uname,''), campaign_breakup.get(uname,'')])

    return render_to_response("core/workload.html",{
            'fresh_data' : fresh_data,
            'data' : data,
            'active' : 'workload'
        },
        context_instance=RequestContext(request),
    )


@utils.profile_type_only('MANAGER', 'ADMIN')
def last_call_campaignwise_dump(request):
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "last_call_campaignwise_%s_%s-%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data.get('campaign',''), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            capture_attrs = putils.VERBOSE_FIELD_DICT.copy()
            header_row = ['Application Id','Product Name','Uploaded On','Campaign','Mobile','Email','Alt Numbers','Name','Assigned To'] #product name added LMS call disposition 293 may 2017
            header_row.extend(capture_attrs.values())
            header_row.extend(['Caller', 'Call Time', 'Next Call', 'Main Disposition', 'Disposition',"Notes"])
            data_row_list = []
            #print df.cleaned_data['from_date'], df.cleaned_data['to_date'], df.cleaned_data.get('campaign')
            query_data = History.objects.filter(campaigndata__online_created_date__gte=df.cleaned_data['from_date'], campaigndata__online_created_date__lte=df.cleaned_data['to_date'],)
           
            
            # LMS Call disposition project - ID 293 may 2017
            temp = df.cleaned_data.get('product')
            if str(temp) == "SecurePlus":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name = "SecureSelf"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                   query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name= "SecureSelf"))
                    
            elif str(temp) == "ProtectEase":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "") | Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name ="JointLife"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name = "") | Q(campaigndata__product_name= "JointLife"))


            elif str(temp) == "VisionStar":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"))
                
            elif str(temp) == "CancerShield":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"))
                    

            elif str(temp) == "WealthProtection":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name ="WealthChild"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name= "WealthChild"))

            

            else:
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'],campaigndata__product_name=df.cleaned_data['product'])  #LMS Call
                    
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                    
                elif df.cleaned_data.get('product'):
                    query_data = query_data.filter(campaigndata__product_name=df.cleaned_data['product'])
                    

            # commented old logic before LMS call disposition project 
            #if df.cleaned_data.get('campaign'):
            #    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])

            final_data = {}
            for ch in query_data.order_by("-created_on"):
                cd = ch.campaigndata_set.get()
                if final_data.get("%s-%s" % (cd.id, cd.customer_id)):
                    continue
                final_data["%s-%s" % (cd.id, cd.customer_id)] = True
                campaign_data_list = []
                campaign_data = json.loads(cd.data)
                campaign_data['application_id'] = cd.application_id
                campaign_data['uploaded_on'] = cd.uploaded_on.strftime("%D %H:%M")
                campaign_data['campaign'] = cd.campaign.name
                campaign_data['mobile'] = cd.customer.mobile
                campaign_data['email'] = cd.customer.email
                campaign_data['alt_numbers'] = cd.customer.alt_numbers
                campaign_data['name'] = cd.customer.name
                campaign_data['product_name'] = cd.product_name  # product name added LMS call disposition 293 - may 2017
                campaign_data['assigned_to'] = ''
                if cd.assigned_to:
                    campaign_data['assigned_to'] = cd.assigned_to.get_full_name()

                # Campaign Data in campaign_data__list
                campaign_data_list.extend([campaign_data[verb] for verb in ['application_id','product_name','uploaded_on','campaign','mobile','email','alt_numbers','name','assigned_to']])   # LMS call disposition 293 product name added
                campaign_data_list.extend([campaign_data.get(verb) for verb in capture_attrs.keys()])

                call_data = json.loads(ch.changed_data)
                call_data['caller'] = ch.caller.get_full_name()
                call_data['call_time'] = ch.created_on.strftime("%D %H:%M")
                call_data['disposition'] = ch.call_disposition
                call_data['call_status'] = ch.call_status
                if ch.call_disposition in ['DUPLICATE_API', 'LIMIT_EXCEEDED', 'DONE', 'PAYMENT_SUCCESSFUL']:
                    call_data['head_disposition'] = 'SYSTEM'
                else:
                    call_data['head_disposition'] = putils.REV_DISTRIBUTION_MAP_ALL[ch.call_disposition]
                # Call Data in campaign_data_list
                campaign_data_list.extend([call_data.get(verb) for verb in ['caller','call_time','later_time','call_status','head_disposition','disposition','notes']])
                data_row_list.append(campaign_data_list)
            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), header_row, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(5)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    return HttpResponse("OK")

@utils.profile_type_only('MANAGER', 'ADMIN')
def last_call_customerwise_dump(request):  
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "last_call_customerwise_%s_%s-%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data.get('campaign',''), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            capture_attrs = putils.VERBOSE_FIELD_DICT.copy()
            header_row = ['Application Id','Product Name','Uploaded On','Campaign','Mobile','Email','Alt Numbers','Name','Assigned To']
            header_row.extend(capture_attrs.values())
            header_row.extend(['Caller', 'Call Time', 'Next Call', 'Main Disposition', 'Disposition',"Notes"])
            data_row_list = []
            #print df.cleaned_data['from_date'], df.cleaned_data['to_date'], df.cleaned_data.get('campaign')
            query_data = History.objects.filter(campaigndata__last_call_time__gte=df.cleaned_data['from_date'], campaigndata__last_call_time__lte=df.cleaned_data['to_date'])

            # LMS Call disposition project - ID 293 may 2017   
            temp = df.cleaned_data.get('product')
            if str(temp) == "SecurePlus":
             
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name = "SecureSelf") , campaigndata__campaign=df.cleaned_data['campaign'])
                
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name= "SecureSelf"))
                elif df.cleaned_data.get('campaign'):
                   query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                

            elif str(temp) == "ProtectEase":

                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "") | Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name ="JointLife"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name = "") | Q(campaigndata__product_name= "JointLife"))
        
            elif str(temp) == "VisionStar":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"))

            elif str(temp) == "CancerShield":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"))

            
            elif str(temp) == "WealthProtection":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name ="WealthChild"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name= "WealthChild"))

            
            else:  
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):                    
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'],campaigndata__product_name=df.cleaned_data['product'])  #LMS Call
                
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                
                elif df.cleaned_data.get('product'):
                    query_data = query_data.filter(campaigndata__product_name=df.cleaned_data['product'])
                
                
            final_data = {}
            for ch in query_data.order_by("-call_time"):
                cd = ch.campaigndata_set.get()
                if final_data.get(cd.customer_id):
                    continue
                final_data[cd.customer_id] = True
                campaign_data_list = []
                campaign_data = json.loads(cd.data)
                campaign_data['application_id'] = cd.application_id
                campaign_data['uploaded_on'] = cd.uploaded_on.strftime("%D %H:%M")
                campaign_data['campaign'] = cd.campaign.name
                campaign_data['mobile'] = cd.customer.mobile
                campaign_data['email'] = cd.customer.email
                campaign_data['alt_numbers'] = cd.customer.alt_numbers
                campaign_data['name'] = cd.customer.name
                campaign_data['product_name'] = cd.product_name
                campaign_data['assigned_to'] = ''
                if cd.assigned_to:
                    campaign_data['assigned_to'] = cd.assigned_to.get_full_name()

                # Campaign Data in campaign_data__list
                campaign_data_list.extend([campaign_data[verb] for verb in ['application_id','product_name','uploaded_on','campaign','mobile','email','alt_numbers','name','assigned_to']])
                campaign_data_list.extend([campaign_data.get(verb) for verb in capture_attrs.keys()])

                call_data = json.loads(ch.changed_data)
                call_data['caller'] = ch.caller.get_full_name()
                call_data['call_time'] = ch.created_on.strftime("%D %H:%M")
                call_data['disposition'] = ch.call_disposition
                if ch.call_disposition in ['DUPLICATE_API', 'LIMIT_EXCEEDED', 'DONE', 'PAYMENT_SUCCESSFUL']:
                    call_data['head_disposition'] = 'SYSTEM'
                else:
                    call_data['head_disposition'] = putils.REV_DISTRIBUTION_MAP_ALL[ch.call_disposition]
                # Call Data in campaign_data_list

                
                campaign_data_list.extend([call_data.get(verb) for verb in ['caller','call_time','later_time','head_disposition','disposition','notes']])
                
                data_row_list.append(campaign_data_list)

            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), header_row, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(5)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    return HttpResponse("OK")

def callhistory_report(request):
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "callhistory_%s_%s-%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data.get('campaign',''), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            capture_attrs = putils.VERBOSE_FIELD_DICT.copy()
            header_row = ['Application Id','Uploaded On','Campaign','Mobile','Email','Alt Numbers','Name']
            header_row.extend(capture_attrs.values())
            header_row.extend(["Caller", 'Call Time', 'Next Call', 'Main Disposition', 'Disposition',"Notes"])
            data_row_list = []
            #print df.cleaned_data['from_date'], df.cleaned_data['to_date']
            query_data = History.objects.filter(campaigndata__uploaded_on__gte=df.cleaned_data['from_date'], campaigndata__uploaded_on__lte=df.cleaned_data['to_date'])
            if df.cleaned_data.get('campaign'):
                query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
            for ch in query_data:
                cd = ch.campaigndata_set.get()
                campaign_data_list = []
                campaign_data = json.loads(cd.data)
                campaign_data['application_id'] = cd.application_id
                campaign_data['uploaded_on'] = cd.uploaded_on.strftime("%D %H:%M")
                campaign_data['campaign'] = cd.campaign.name
                campaign_data['mobile'] = cd.customer.mobile
                campaign_data['email'] = cd.customer.email
                campaign_data['alt_numbers'] = cd.customer.alt_numbers
                campaign_data['name'] = cd.customer.name

                # Campaign Data in campaign_data__list
                campaign_data_list.extend([campaign_data[verb] for verb in ['application_id','uploaded_on','campaign','mobile','email','alt_numbers','name']])
                campaign_data_list.extend([campaign_data.get(verb) for verb in capture_attrs.keys()])

                call_data = json.loads(ch.changed_data)
                call_data['caller'] = ch.caller.get_full_name()
                call_data['call_time'] = ch.created_on.strftime("%D %H:%M")
                call_data['disposition'] = ch.call_disposition
                if ch.call_disposition in ['DUPLICATE_API', 'LIMIT_EXCEEDED','DONE', 'PAYMENT_SUCCESSFUL']:
                    call_data['head_disposition'] = 'SYSTEM'
                else:
                    call_data['head_disposition'] = putils.REV_DISTRIBUTION_MAP_ALL[ch.call_disposition]
                last_call_disposition = ch.call_disposition
                # Call Data in campaign_data_list
                campaign_data_list.extend([call_data.get(verb) for verb in ['caller','call_time','later_time','head_disposition','disposition','notes']])
                data_row_list.append(campaign_data_list)

            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), header_row, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(5)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    return HttpResponse("OK")

def call_report(request):
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "campaignwise_callhistory_%s_%s-%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data.get('campaign',''), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            capture_attrs = putils.VERBOSE_FIELD_DICT.copy()
            header_row = ['Application Id','Product Name','Uploaded On','Campaign','Mobile','Email','Alt Numbers','Name','Assigned To','Last Call Disposition'] # LMS call disposition 293 product name added march 2017
            header_row.extend(capture_attrs.values())
            [header_row.extend(['%s-Caller'%i, '%s-Call Time'%i, '%s-Next Call'%i, '%s-Main Disposition'%i, '%s-Disposition'%i,"%s-Notes"%i]) for i in range(1,9)]
            data_row_list = []
            #print df.cleaned_data['from_date'], df.cleaned_data['to_date']
            query_data = History.objects.filter(campaigndata__created_on__gte=df.cleaned_data['from_date'], campaigndata__created_on__lte=df.cleaned_data['to_date'])

            # LMS Call disposition project - ID 293 may 2017
            temp = df.cleaned_data.get('product')
            if str(temp) == "SecurePlus":
                
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name = "SecureSelf"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "SecureChild") | Q(campaigndata__product_name = "SecureSpouse") | Q(campaigndata__product_name= "SecureSelf"))
                    
            elif str(temp) == "ProtectEase":

                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "") | Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name ="JointLife"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "ProtectSelf") | Q(campaigndata__product_name = "") | Q(campaigndata__product_name= "JointLife"))
            
 
            elif str(temp) == "VisionStar":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "VisionSelf") | Q(campaigndata__product_name = "VisionSpouse"))

            elif str(temp) == "CancerShield":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "CancerSelf") | Q(campaigndata__product_name = "CancerSpouse"))
                    
            elif str(temp) == "WealthProtection":
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name ="WealthChild"), campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                elif df.cleaned_data.get('product'):
                    query_data  = query_data.filter(Q(campaigndata__product_name = "WealthSelf") | Q(campaigndata__product_name = "WealthSpouse") | Q(campaigndata__product_name= "WealthChild"))
                    
                    
            else:
                if df.cleaned_data.get('campaign') and df.cleaned_data.get('product'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'],campaigndata__product_name=df.cleaned_data['product'])  #LMS Call
                    
                elif df.cleaned_data.get('campaign'):
                    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
                    
                elif df.cleaned_data.get('product'):
                    query_data = query_data.filter(campaigndata__product_name=df.cleaned_data['product'])
                    
           

            # commented old logic before LMS call disposition project
            #if df.cleaned_data.get('campaign'):
            #    query_data = query_data.filter(campaigndata__campaign=df.cleaned_data['campaign'])
            

            for ch in query_data:
                cd = ch.campaigndata_set.get()
                campaign_data_list = []
                campaign_data = json.loads(cd.data)
                campaign_data['application_id'] = cd.application_id
                campaign_data['uploaded_on'] = cd.uploaded_on.strftime("%D %H:%M")
                campaign_data['campaign'] = cd.campaign.name
                campaign_data['mobile'] = cd.customer.mobile
                campaign_data['email'] = cd.customer.email
                campaign_data['alt_numbers'] = cd.customer.alt_numbers
                campaign_data['name'] = cd.customer.name
                campaign_data['product_name'] = cd.product_name  # product name added LMS call disposition 293 - may 2017
                campaign_data['assigned_to'] = ''
                if cd.assigned_to:
                    campaign_data['assigned_to'] = cd.assigned_to.get_full_name()

                # Campaign Data in campaign_data__list
                campaign_data_list.extend([campaign_data[verb] for verb in ['application_id','product_name','uploaded_on','campaign','mobile','email','alt_numbers','name','assigned_to']])

                call_history_list = list(cd.history.all())
                last_call_disposition = ""
                if call_history_list:
                    last_call_disposition = call_history_list[-1].call_disposition
                    #print "LAST CALL DISP ", last_call_disposition
                campaign_data_list.append(last_call_disposition)

                campaign_data_list.extend([campaign_data.get(verb) for verb in capture_attrs.keys()])

                for ch in list(cd.history.all())[-10:]:
                    call_data = json.loads(ch.changed_data)
                    call_data['caller'] = ch.caller.get_full_name()
                    call_data['call_time'] = ch.created_on.strftime("%D %H:%M")
                    call_data['disposition'] = ch.call_disposition
                    if ch.call_disposition in ['DUPLICATE_API', 'LIMIT_EXCEEDED','DONE', 'PAYMENT_SUCCESSFUL']:
                        call_data['head_disposition'] = 'SYSTEM'
                    else:
                        call_data['head_disposition'] = putils.REV_DISTRIBUTION_MAP_ALL[ch.call_disposition]
                    last_call_disposition = ch.call_disposition
                    # Call Data in campaign_data_list
                    campaign_data_list.extend([call_data.get(verb) for verb in ['caller','call_time','later_time','head_disposition','disposition','notes']])
                if campaign_data_list not in data_row_list:
                    data_row_list.append(campaign_data_list)


            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), header_row, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(6)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    return HttpResponse("OK")
#def c2c_campaign(request, source_code="",promo_id="",site_id="",banner_id="", agent_code=""):
@csrf_exempt
def c2c_campaign(request):
    campaign = Campaign.objects.get(name="D2C")
    if request.POST:
        cform = EmailCampaignForm(request.POST)
        if cform.is_valid():
            cdata = cform.cleaned_data
            customer, created = Customer.objects.get_or_create(mobile = cdata['mobile'])
            print request.POST
            final_data = {
                'mobile' : request.POST.get('mobile'),
                'first_name' : request.POST.get('name') or "%s %s" % (request.POST.get('first_name'), request.POST.get('last_name')),
                'product_code' : request.POST.get('product_code'),
                'page' : request.POST.get('page',''),
                'source' : request.POST.get('uid',''),
                'gender' : request.POST.get('gender'),
                'dob' : request.POST.get('dob'),
                'application_id' : request.POST.get('app',''),
                'sum_assured': request.POST.get('sa'),
                'total_premium': request.POST.get('premium'),
            }
            proper_data = {}
            for k,v in final_data.items():
                if v:
                    proper_data[k] = v

            # 6733 change to old its working
            response = conclude_save_lead_old(proper_data, campaign)
            print "******************\n", response, "************************\n"
            utils.response_logger.info(response)
            return HttpResponseRedirect(request.POST.get('furl'))

        else:
            print cform.errors
    else:
        cform = EmailCampaignForm()
    return render_to_response("campaign/index1.html", {
            'cform' : cform,
        },
        context_instance=RequestContext(request)
    )

def c2c_campaign_success(request):
    return render_to_response("campaign/thankyou1.html", {
        },
        context_instance=RequestContext(request)
    )

@login_required
@utils.profile_type_only('MANAGER', 'REPORT','ADMIN')
def unique_customerwise_report(request):
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "unique_customer_month_wise_%s_%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            from_time = df.cleaned_data['from_date']
            to_time = df.cleaned_data['to_date'] + datetime.timedelta(days = 1)

            months = []
            d = from_time
            while(d < to_time):
                months.append("%s-%s" % (d.month, d.year))
                d = d + datetime.timedelta(days=20)
            months = list(set(months))

            num_call_agents = len(months)

            disp_ch = {}
            rvmap = putils.REV_DISTRIBUTION_MAP.copy()
            rvmap.update({
                'FRESH_CALLS': 'SYSTEM',
                'DUPLICATE_API' : 'SYSTEM',
                'LIMIT_EXCEEDED' : 'SYSTEM',
                'DONE' : 'SYSTEM',
                'PAYMENT_SUCCESSFUL' : 'SYSTEM',
            })

            for k, v in rvmap.items():
                for u in months:
                    disp_ch.setdefault(v,{}).setdefault(k,{}).setdefault(u,0)

            dispo_dict = dict(putils.DISPOSITIONS)
            dispo_dict.update({
                'FRESH_CALLS' : 'Fresh Calls',
                'DUPLICATE_API' : 'Duplicate Disposed',
                'LIMIT_EXCEEDED' : 'Limit Exceeded',
                'SYSTEM' : 'System',
                'DONE' : 'System Done',
                'PAYMENT_SUCCESSFUL' : 'Payment successful'
            })

            final_called_history = {}
            for ch in History.objects.filter(created_on__gte=from_time, created_on__lte=to_time).order_by('-created_on').select_related('campaigndata'):
                final_called_history[ch.campaigndata_set.get().customer_id] = True
                main_disp = rvmap.get(ch.call_disposition)
                disp_ch[main_disp][ch.call_disposition]["%s-%s" % (ch.created_on.month, ch.created_on.year)] += 1

            for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys():
                disp_ch['SYSTEM']['FRESH_CALLS'][i] = CampaignData.objects.filter(history__isnull=True).count()

            order = ['Disposition', 'Sub-Disposition']
            order.extend([i for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys()])
            order.append("TOTAL")
            data_row_list = []

            tot_row = 0
            SORTED_DISP_LIST = ['NOT_INTERESTED', 'CALLBACK_LATER', 'INTERESTED', 'PAYMENT_RECEIVED', 'NONCONTACTABLE', 'NOT_ELIGIBLE', 'DO_NOT_CALL', 'LOST_CASES', 'SYSTEM']
            #for d in disp_ch.keys():
            for d in SORTED_DISP_LIST:
                i = 0
                for subd in disp_ch[d].keys():
                    if i == 0:
                        drow = [dispo_dict[d], dispo_dict[subd]]
                    else:
                        drow = ['', dispo_dict[subd]]
                    i += 1
                    tot_row += 1
                    for v in disp_ch[d][subd].values():
                        drow.append(v)
                    drow.append('formula-SUM(%s%s:%s%s)' % ('C',tot_row+1, putils.excel_column(num_call_agents+1,''), tot_row+1))
                    data_row_list.append(drow)
            data_row_list.append(["FRESH UNCLAIMED", CampaignData.objects.filter(history__isnull=True, assigned_to__isnull=True).count()])

            formulae_row = ["","TOTAL"]
            disp_count = len(putils.DISPOSITIONS) + 1
            for i in range(0,num_call_agents):
                formulae_row.append("formula-SUM(%s%s:%s%s)" % (putils.excel_column(i+2,''), 2, putils.excel_column(i+2,''), disp_count+1))
            formulae_row.append("formula-SUM(%s%s:%s%s)" % ("C", disp_count+2, putils.excel_column(i+2,''), disp_count+2))
            data_row_list.append(formulae_row)
            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), order, data_row_list)
        thread.start_new_thread(calculate,())
        return HttpResponse("%s/static/downloads/%s" % (settings.SITE_URL, filename))
    else:
        print form.errors
    return HttpResponse("OK")

@login_required
@utils.profile_type_only('MANAGER', 'REPORT','ADMIN')
def report_disposition_month_wise(request):
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "disposition_month_wise_%s_%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"), df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            from_time = df.cleaned_data['from_date']
            to_time = df.cleaned_data['to_date'] + datetime.timedelta(days = 1)

            months = []
            d = from_time
            while(d < to_time):
                months.append("%s-%s" % (d.month, d.year))
                d = d + datetime.timedelta(days=20)
            months = list(set(months))

            num_call_agents = len(months)

            disp_ch = {}
            rvmap = putils.REV_DISTRIBUTION_MAP_ALL.copy()
            rvmap.update({
                'FRESH_CALLS': 'SYSTEM',
                'DUPLICATE_API' : 'SYSTEM',
                'LIMIT_EXCEEDED' : 'SYSTEM',
                'DONE' : 'SYSTEM',
                'PAYMENT_SUCCESSFUL' : 'SYSTEM',
            })

            for k, v in rvmap.items():
                for u in months:
                    disp_ch.setdefault(v,{}).setdefault(k,{}).setdefault(u,0)

            dispo_dict = dict(putils.DISPOSITIONS)
            dispo_dict.update({
                'FRESH_CALLS' : 'Fresh Calls',
                'DUPLICATE_API' : 'Duplicate Disposed',
                'LIMIT_EXCEEDED' : 'Limit Exceeded',
                'SYSTEM' : 'System',
                'DONE' : 'System Done',
                'PAYMENT_SUCCESSFUL' : 'Payment successful'
            })

            for ch in History.objects.filter(created_on__gte=from_time, created_on__lte=to_time):
                main_disp = rvmap.get(ch.call_disposition)
                disp_ch[main_disp][ch.call_disposition]["%s-%s" % (ch.created_on.month, ch.created_on.year)] += 1

            for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys():
                disp_ch['SYSTEM']['FRESH_CALLS'][i] = CampaignData.objects.filter(history__isnull=True).count()

            order = ['Disposition', 'Sub-Disposition']
            order.extend([i for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys()])
            data_row_list = []
            order.append('Total')
            tot_row = 0
            SORTED_DISP_LIST = ['NOT_INTERESTED', 'CALLBACK_LATER', 'INTERESTED','NONCONTACTABLE', 'NOT_ELIGIBLE', 'DO_NOT_CALL', 'LOST_CASES', 'SYSTEM']
            # SORTED_DISP_LIST = ['NOT_INTERESTED', 'CALLBACK_LATER', 'INTERESTED', 'PAYMENT_RECEIVED', 'NONCONTACTABLE', 'NOT_ELIGIBLE', 'DO_NOT_CALL', 'LOST_CASES', 'SYSTEM']

            #for d in disp_ch.keys():
            for d in SORTED_DISP_LIST:
                i = 0
                for subd in disp_ch[d].keys():
                    if i == 0:
                        drow = [dispo_dict[d], dispo_dict[subd]]
                    else:
                        drow = ['', dispo_dict[subd]]
                    i += 1
                    tot_row += 1
                    for v in disp_ch[d][subd].values():
                        drow.append(v)
                    drow.append('formula-SUM(%s%s:%s%s)' % ('C',tot_row+1, putils.excel_column(num_call_agents+1,''), tot_row+1))
                    data_row_list.append(drow)
            

            formulae_row = ["","TOTAL"]
            disp_count = len(putils.DISPOSITIONS) + 1
            for i in range(0,num_call_agents):
                formulae_row.append("formula-SUM(%s%s:%s%s)" % (putils.excel_column(i+2,''), 2, putils.excel_column(i+2,''), disp_count-7))
            formulae_row.append("formula-SUM(%s%s:%s%s)" % ("C", disp_count-1, putils.excel_column(i+2,''), disp_count-1))
            data_row_list.append(formulae_row)
            data_row_list.append(["FRESH UNCLAIMED", CampaignData.objects.filter(history__isnull=True, assigned_to__isnull=True).count()])
            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), order, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(5)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    else:
        print form.errors
    return HttpResponse("OK")

@login_required
@utils.profile_type_only('MANAGER', 'REPORT', 'ADMIN')
def report_disposition_agent_wise(request):
    # Single query to get all answers : History.objects.filter(created_on__range=(from_date, to_date)).extra({'month_disposition' : "CONCAT(MONTH(created_on),'-',YEAR(created_on),'-',call_disposition)"}).values('month_disposition').annotate(count=Count('id')).order_by('month_disposition')
    df = DateForm(request.GET)
    if df.is_valid():
        filename = "disposition_agent_wise_%s_%s-%s.xls" % (datetime.datetime.now().strftime("%d%m%Y%H%M%S"),df.cleaned_data['from_date'].strftime("%d_%m_%Y"), df.cleaned_data['to_date'].strftime("%d_%m_%Y"))
        def calculate():
            from_time = df.cleaned_data['from_date']
            to_time = df.cleaned_data['to_date'] + datetime.timedelta(days = 1)

            call_agents = list(User.objects.filter(userprofile__role='CALLER'))
            call_agents.append(User.objects.get(username='system'))

            num_call_agents = len(call_agents)

            disp_ch = {}
            rvmap = putils.REV_DISTRIBUTION_MAP_ALL.copy()
            #print rvmap
            rvmap.update({
                'FRESH_CALLS': 'SYSTEM',
                'DUPLICATE_API' : 'SYSTEM',
                'LIMIT_EXCEEDED' : 'SYSTEM',
                'DONE' : 'SYSTEM',
                'PAYMENT_SUCCESSFUL' : 'SYSTEM'
            })

            for k, v in rvmap.items():
                for u in call_agents:
                    disp_ch.setdefault(v,{}).setdefault(k,{}).setdefault(u,0)
                    
            dispo_dict = dict(putils.DISPOSITIONS)
            dispo_dict.update({
                'FRESH_CALLS' : 'Fresh Calls',
                'DUPLICATE_API' : 'Duplicate Disposed',
                'LIMIT_EXCEEDED' : 'Limit exceeded',
                'SYSTEM' : 'System',
                'DONE' : 'System Disposed Done',
                'PAYMENT_SUCCESSFUL' : 'Payment Successfull'
            })

            for ch in History.objects.filter(created_on__gte=from_time, created_on__lte=to_time):
                main_disp = rvmap.get(ch.call_disposition)
                disp_ch[main_disp][ch.call_disposition][ch.caller] += 1

            for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys():
                disp_ch['SYSTEM']['FRESH_CALLS'][i] = CampaignData.objects.filter(history__isnull=True, assigned_to=i).count()

            order = ['Disposition', 'Sub-Disposition']
            order.extend([i.username for i in disp_ch['SYSTEM']['FRESH_CALLS'].keys()])
            order.append('Total')
            data_row_list = []

            tot_row = 0
            SORTED_DISP_LIST = ['NOT_INTERESTED', 'CALLBACK_LATER', 'INTERESTED', 'NONCONTACTABLE', 'NOT_ELIGIBLE', 'DO_NOT_CALL', 'LOST_CASES', 'SYSTEM']
            # SORTED_DISP_LIST = ['NOT_INTERESTED', 'CALLBACK_LATER', 'INTERESTED', 'PAYMENT_RECEIVED', 'NONCONTACTABLE', 'NOT_ELIGIBLE', 'DO_NOT_CALL', 'LOST_CASES', 'SYSTEM']

            #for d in disp_ch.keys():
            for d in SORTED_DISP_LIST:
                i = 0
                for subd in disp_ch[d].keys():
                    if i == 0:
                        drow = [dispo_dict[d], dispo_dict[subd]]
                    else:
                        drow = ['', dispo_dict[subd]]
                    i += 1
                    tot_row += 1
                    for v in disp_ch[d][subd].values():
                        drow.append(v)
                    drow.append('formula-SUM(%s%s:%s%s)' % ('C',tot_row+1, putils.excel_column(num_call_agents+1,''), tot_row+1))
                    data_row_list.append(drow)

            formulae_row = ["","TOTAL"]
            disp_count = len(putils.DISPOSITIONS) + 1
            #print "disp_count",disp_count
            for i in range(0,num_call_agents):
                formulae_row.append("formula-SUM(%s%s:%s%s)" % (putils.excel_column(i+2,''), 2, putils.excel_column(i+2,''), disp_count-7))
            formulae_row.append("formula-SUM(%s%s:%s%s)" % ("C", disp_count-1, putils.excel_column(i+2,''), disp_count-1))
            data_row_list.append(formulae_row)
            data_row_list.append(["FRESH UNCLAIMED", CampaignData.objects.filter(history__isnull=True, assigned_to__isnull=True).count()])

            render_excel_to_file(os.path.join(settings.DOWNLOADS_ROOT, filename), order, data_row_list)
        thread.start_new_thread(calculate,())
        time.sleep(5)
        return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    else:
        print form.errors
    return HttpResponse("OK")

@login_required
@utils.profile_type_only("REPORT","MANAGER","ADMIN")
def manager_search(request):
    return render_to_response("core/manager_search.html",
        context_instance=RequestContext(request)
)

def call_reports(request):
#    response = HttpResponse()
    df = DateForm(request.GET)
    cur = connection.cursor()
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Call_Report_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response,delimiter=';')
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
#        response.write(to_date)
 #       return response
        query= "select distinct lms.core_campaigndata.application_id,username,mobile,lms.core_campaigndata.created_on,last_call_time,next_call_time,last_call_disposition,lms.core_campaign.name,lms.core_customer.name,lms.core_campaigndata.last_call_head_disposition,lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata,lms.core_customer,lms.auth_user,lms.core_campaign where lms.core_campaigndata.customer_id=lms.core_customer.id and lms.core_campaigndata.assigned_to_id=lms.auth_user.id and lms.core_campaigndata.campaign_id=lms.core_campaign.id and core_campaigndata.last_call_time between '%s' and '%s' order by last_call_time desc;"%(from_date,to_date)
#        response.write(query)
 #       return response

        cur.execute(query)
        query_result = cur.fetchall()
        row_count = cur.rowcount
       # srno = 1
        if query_result:
            def csv_print():
                srno = 1
                for i in list(query_result):
                    remarks=""
                    if i[9]:
                        remarks=i[9].replace('\n','')
                    
                    row=[
                        ("Sr no", srno),
                        ("Application ID", str(i[0])),
                        ("Username", str(i[1])),
                        ("Customer", str(json.loads(i[11]).get('first_name')+" "+ json.loads(i[11]).get('last_name'))),
                        ("Mobile", str(i[2])),
                        ("Created on", str(i[3])),
                        ("Last call time", str(i[4])),
                        ("Next call time", str(i[5])),
                        ("Head Disposition", str(i[9])),
                        ("Disposition", str(i[6])),
                        ("Remarks", str(i[10])),
                        ("Campaign Name", str(i[7])),
                        ("Drop Page", str(json.loads(i[11]).get('page_name'))),
                        ("Source", str(json.loads(i[11]).get('tracker_id'))),
                        
                        ]
                    if srno == 1:
                        writer.writerow([k[0] for k in row])

                    writer.writerow([k[1] for k in row])
                    srno = srno + 1
                    # response.write(i[0])
                return response
            try:
                thread.start_new_thread(csv_print,())
                time.sleep(3)
                return response
            except:
                print "Error in thread"
                return response

        else:
            return response


def last_call_disposition_reports(request):

    df = DateForm(request.GET)
    cur = connection.cursor()
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Last_Call_disposition_Report_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
        query= "select distinct lms.core_campaigndata.application_id,username,mobile,lms.core_campaigndata.created_on,last_call_time,next_call_time,last_call_disposition,lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition,lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata,lms.core_customer,lms.auth_user,lms.core_campaign where lms.core_campaigndata.customer_id=lms.core_customer.id and lms.core_campaigndata.assigned_to_id=lms.auth_user.id and lms.core_campaigndata.campaign_id=lms.core_campaign.id and core_campaigndata.last_call_time between '%s' and '%s' and last_call_disposition != 'DUPLICATE_API'  order by last_call_time desc;" %(from_date,to_date)

        cur.execute(query)
        query_result = cur.fetchall()
        row_count = cur.rowcount
        srno = 1
        l=[]
        camp = []
        if query_result:
            for i in list(query_result):
                if i[2] not in l:
                    l.append(i[2])
                    remarks=""
                    if i[9]:
                        remarks = i[9].replace('\n','')
                    row=[
                        ("Sr no", srno),
                        ("Application ID", str(i[0])),
                        ("Username", str(i[1])),
                        ("Customer", str(json.loads(i[10]).get('first_name')+" "+ json.loads(i[10]).get('last_name'))),
                        ("Mobile", str(i[2])),
                        ("Created on", str(i[3])),
                        ("Last call time", str(i[4])),
                        ("Next call time", str(i[5])),
                        ("Head Disposition",str(i[8])),
                        ("Disposition", str(i[6])),
                        ("Remarks", str(remarks)),
                        ("Campaign Name", str(i[7])),
                        ("Drop Page", str(json.loads(i[10]).get('page_name'))),
                        ("Source", str(json.loads(i[10]).get('tracker_id'))),

                        ]
                    if srno == 1:
                        writer.writerow([k[0] for k in row])

                    writer.writerow([k[1] for k in row])
                    srno = srno + 1
                    # response.write(i[0])                                                                                                            
            return response
        else:
            return response

def multipledisposition_report(request):
    df = DateForm(request.GET)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="multiple_Call_Report_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
        cur = connection.cursor()
        query="select distinct lms.core_campaigndata.application_id from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' order by last_call_time desc;" %(from_date,to_date)

        cur.execute(query)
        query_result = cur.fetchall()
        applicationno=[]
        applicationdata=[]
        maindata=[]
        maindataheader=['Application ID','Username','Customer','mobile','Created On']
        maindataheader_opt=['Drop Page','Source','Last Call Time','Next Call Time','Head Dispostion','Dispostion','Remarks','Campaign Name']
        maindataheader.extend(["%s-%s" %(co,str(i)) for i in range(1,26) for co in maindataheader_opt])
        maindata.append(maindataheader)
        cur1=connection.cursor()
        if query_result:
            for a in query_result:
                if a[0] != 'NAd41d8cd98f' and a[0] != 'BA0000000':
                    applicationno.append(a[0])
        srno=0
        for i in applicationno:

            cur1=connection.cursor()
            query1="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' and lms.core_campaigndata.application_id='%s'  order by last_call_time asc;" %(from_date,to_date,i)

            cur1.execute(query1)
            query_result1 = cur1.fetchall()
            if query_result1:
                for a1 in query_result1:
                    remarks=""
                    if a1[9]:
                        remarks = a1[9].replace('\n','')
                    if i in applicationdata:
                        applicationdata.append(str(json.loads(a1[10]).get('page_name')))#drop page                                                   
                        applicationdata.append(str(json.loads(a1[10]).get('tracker_id')))#source                                                     
                        applicationdata.append(a1[4])#last_call_time                                                                                 
                        applicationdata.append(a1[5])#next_call_time                                                                                 
                        applicationdata.append(a1[8])#header disposition                                                                             
                        applicationdata.append(a1[6])#Disposition                                                                                    
                        applicationdata.append(remarks)#Remarks                                                                                      
                        applicationdata.append(a1[7])#compain name                                                                                   
                    else:
                        applicationdata.append(a1[0])#application_ID                                                                                 
                        applicationdata.append(a1[1])#username                                                                                       
                        applicationdata.append(str(json.loads(a1[10]).get('first_name')+" "+json.loads(a1[10]).get('last_name')))#customer           
                        applicationdata.append(a1[2])#mobile                                                                                         
                        applicationdata.append(a1[3])#created                                                                                        
                        applicationdata.append(str(json.loads(a1[10]).get('page_name')))#drop page                                                   
                        applicationdata.append(str(json.loads(a1[10]).get('tracker_id')))#source                                                     
                        applicationdata.append(a1[4])#last_call_time                                                                                 
                        applicationdata.append(a1[5])#next_call_time                                                                                 
                        applicationdata.append(a1[8])#header disposition                                                                             
                        applicationdata.append(a1[6])#Disposition                                                                                    
                        applicationdata.append(remarks)#Remarks                                                                                      
                        applicationdata.append(a1[7])#compain name                                                                                   

                maindata.append(applicationdata)
                applicationdata=[]
        c2cmobile=[]
        c2cmobiledata=[]
        cur2=connection.cursor()
        query2="select distinct lms.core_customer.mobile from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' and core_campaigndata.application_id = 'NAd41d8cd98f';"%(from_date,to_date)
        cur2.execute(query2)
        query_result2 = cur2.fetchall()
        if query_result2:
            for j in query_result2:
                c2cmobile.append(j[0])
        for i1 in c2cmobile:

            cur3=connection.cursor()
            query3="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' and lms.core_customer.mobile='%s' and lms.core_campaigndata.application_id = 'NAd41d8cd98f' order by last_call_time asc;" %(from_date,to_date,i1)
            cur3.execute(query3)
            query_result3 = cur3.fetchall()
            if query_result3:
                for a1new in query_result3:
                    remarks=""
                    if a1new[9]:
                        remarks = a1new[9].replace('\n','')
                    if i1 in c2cmobiledata:
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('page_name')))#drop page                                                  
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('tracker_id')))#source                                                    
                        c2cmobiledata.append(a1new[4])#last_call_time                                                                                
                        c2cmobiledata.append(a1new[5])#next_call_time                                                                                
                        c2cmobiledata.append(a1new[8])#header disposition                                                                            
                        c2cmobiledata.append(a1new[6])#Disposition                                                                                   
                        c2cmobiledata.append(remarks)#Remarks                                                                                        
                        c2cmobiledata.append(a1new[7])#compain name                                                                                  
                    else:
                        c2cmobiledata.append(a1new[0])#application_ID                                                                                
                        c2cmobiledata.append(a1new[1])#username                                                                                      
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('first_name')+" "+json.loads(a1new[10]).get('last_name')))#customer       
                        c2cmobiledata.append(a1new[2])#mobile                                                                                        
                        c2cmobiledata.append(a1new[3])#created                                                                                       
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('page_name')))#drop page                                                  
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('tracker_id')))#source                                                    
                        c2cmobiledata.append(a1new[4])#last_call_time                                                                                
                        c2cmobiledata.append(a1new[5])#next_call_time                                                                                
                        c2cmobiledata.append(a1new[8])#header disposition                                                                            
                        c2cmobiledata.append(a1new[6])#Disposition                                                                                   
                        c2cmobiledata.append(remarks)#Remarks                                                                                        
                        c2cmobiledata.append(a1new[7])#compain name                                                                                  

                maindata.append(c2cmobiledata)
                c2cmobiledata=[]
        D2cmobile=[]
        D2cmobiledata=[]
        cur5=connection.cursor()
        query4="select distinct lms.core_customer.mobile from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' and core_campaigndata.application_id = 'BA0000000';"%(from_date,to_date)
        cur5.execute(query4)
        query_result4 = cur5.fetchall()
        if query_result4:
            for k in query_result4:
                D2cmobile.append(k[0])
            for l in D2cmobile:
                cur6=connection.cursor()
                query5="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.last_call_time between '%s' and '%s' and lms.core_customer.mobile='%s' and lms.core_campaigndata.application_id = 'BA0000000' order by last_call_time asc;" %(from_date,to_date,l)
                cur6.execute(query5)
                query_result5= cur6.fetchall()
                if query_result5:
                    for lnew in query_result5:
                        remarks=""
                        if lnew[9]:
                            remarks = lnew[9].replace('\n',' ')
                        if l in D2cmobiledata:
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('page_name')))#drop page                                               
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('tracker_id')))#source                                                 
                            D2cmobiledata.append(lnew[4])#last_call_time                                                                             
                            D2cmobiledata.append(lnew[5])#next_call_time                                                                             
                            D2cmobiledata.append(lnew[8])#header disposition                                                                         
                            D2cmobiledata.append(lnew[6])#Disposition                                                                                
                            D2cmobiledata.append(remarks)#Remarks                                                                                    
                            D2cmobiledata.append(lnew[7])#compain name                                                                               
                        else:
                            D2cmobiledata.append(lnew[0])#application_ID                                                                             
                            D2cmobiledata.append(lnew[1])#username                                                                                   
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('first_name')+" "+json.loads(lnew[10]).get('last_name')))#customer     
                            D2cmobiledata.append(lnew[2])#mobile                                                                                     
                            D2cmobiledata.append(lnew[3])#created                                                                                    
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('page_name')))#drop page                                               
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('tracker_id')))#source                                                 
                            D2cmobiledata.append(lnew[4])#last_call_time                                                                             
                            D2cmobiledata.append(lnew[5])#next_call_time                                                                             
                            D2cmobiledata.append(lnew[8])#header disposition                                                                         
                            D2cmobiledata.append(lnew[6])#Disposition                                                                                
                            D2cmobiledata.append(remarks)#Remarks                                                                                    
                            D2cmobiledata.append(lnew[7])#compain name                                                                               

                    maindata.append(D2cmobiledata)
                    D2cmobiledata=[]
        for linew in maindata:
            if linew!=[]:
                #print linew                                                                                                                         
                writer.writerow([k for k in linew])

        return response
    else:
        return response

@login_required
def call_reports_created(request):
    df = DateForm(request.GET)
    cur = connection.cursor()
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Unique_Call_Report_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response,delimiter=';')
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")

        query="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data,lms.core_campaigndata.online_created_date from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' order by online_created_date desc;" %(from_date,to_date)

        cur.execute(query)
        query_result = cur.fetchall()
        row_count = cur.rowcount
        srno = 1
        l=[]
        camp = []
        if query_result:

            for i in list(query_result):
                remarks=""
                if i[9]:
                    remarks=i[9].replace('\n','')
                row=[
                    ("Sr no", srno),
                    ("Application ID", str(i[0])),
                    ("Username", str(i[1])),
                    ("Customer", str(json.loads(i[10]).get('first_name')+" "+ json.loads(i[10]).get('last_name'))),
                    ("Mobile", str(i[2])),
                    ("Application Created Date", str(i[11])),
                    ("Created on", str(i[3])),
                    ("Last call time", str(i[4])),
                    ("Next call time", str(i[5])),
                    ("Head Disposition",str(i[8])),
                    ("Disposition", str(i[6])),
                    ("Remarks", str(remarks)),
                    ("Campaign Name", str(i[7])),
                        ("Drop Page", str(json.loads(i[10]).get('page_name'))),
                    ("Source", str(json.loads(i[10]).get('tracker_id'))),

                    ]
                if srno == 1:
                    writer.writerow([k[0] for k in row])

                writer.writerow([k[1] for k in row])
                srno = srno + 1
            return response
        else:
            return response

def multiple_reports_created(request):
    df = DateForm(request.GET)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="multiple_Call_Report_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    writer = csv.writer(response)
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
        cur = connection.cursor()
        query="select distinct lms.core_campaigndata.application_id from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' order by online_created_date desc;" %(from_date,to_date)
 
        cur.execute(query)
        query_result = cur.fetchall()
        applicationno=[]
        applicationdata=[]
        maindata=[]
        maindataheader=['Application ID','Username','Customer','mobile','Created On']
        maindata_opt=['Drop Page','Source','Last Call Time','Next Call Time','Head Dispostion','Dispostion','Remarks','Campaign Name']
        maindataheader.extend(["%s-%s" %(co,str(i)) for i in range(1,31) for co in maindata_opt])
        maindata.append(maindataheader)
        cur1=connection.cursor()
        if query_result:
            for a in query_result:
                applicationno.append(a[0])
            if 'NAd41d8cd98f' in applicationno:
                applicationno.remove('NAd41d8cd98f')
            if 'BA0000000' in applicationno:
                applicationno.remove('BA0000000')
        srno=0
        for i in applicationno:

            cur1=connection.cursor()
            query1="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' and lms.core_campaigndata.application_id='%s'  order by online_created_date asc;" %(from_date,to_date,i)

            cur1.execute(query1)
            query_result1 = cur1.fetchall()
            if query_result1:
                for a1 in query_result1:
                    remarks=""
                    if a1[9]:
                        remarks = a1[9].replace('\n',' ')
                    if i in applicationdata:
                        applicationdata.append(str(json.loads(a1[10]).get('page_name')))#drop page                                                   
                        applicationdata.append(str(json.loads(a1[10]).get('tracker_id')))#source                                                     
                        applicationdata.append(a1[4])#last_call_time                                                                                 
                        applicationdata.append(a1[5])#next_call_time                                                                                 
                        applicationdata.append(a1[8])#header disposition                                                                             
                        applicationdata.append(a1[6])#Disposition                                                                                    
                        applicationdata.append(remarks)#Remarks                                                                                      
                        applicationdata.append(a1[7])#compain name  
                    else:
                        applicationdata.append(a1[0])#application_ID                                                                                 
                        applicationdata.append(a1[1])#username                                                                                       
                        applicationdata.append(str(json.loads(a1[10]).get('first_name')+" "+json.loads(a1[10]).get('last_name')))#customer           
                        applicationdata.append(a1[2])#mobile                                                                                         
                        applicationdata.append(a1[3])#created                                                                                        
                        applicationdata.append(str(json.loads(a1[10]).get('page_name')))#drop page                                                   
                        applicationdata.append(str(json.loads(a1[10]).get('tracker_id')))#source                                                     
                        applicationdata.append(a1[4])#last_call_time                                                                                 
                        applicationdata.append(a1[5])#next_call_time                                                                                 
                        applicationdata.append(a1[8])#header disposition                                                                             
                        applicationdata.append(a1[6])#Disposition                                                                                    
                        applicationdata.append(remarks)#Remarks                                                                                      
                        applicationdata.append(a1[7])#compain name                                                                                   

                maindata.append(applicationdata)
                applicationdata=[]
        c2cmobile=[]
        c2cmobiledata=[]
        cur2=connection.cursor()
        query2="select distinct lms.core_customer.mobile from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' and core_campaigndata.application_id = 'NAd41d8cd98f';"%(from_date,to_date)
        cur2.execute(query2)
        query_result2 = cur2.fetchall()
        if query_result2:
            for j in query_result2:
                c2cmobile.append(j[0])
        for i1 in c2cmobile:

            cur3=connection.cursor()
            query3="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' and lms.core_customer.mobile='%s' and lms.core_campaigndata.application_id = 'NAd41d8cd98f' order by last_call_time asc;" %(from_date,to_date,i1)
            cur3.execute(query3)
            query_result3 = cur3.fetchall()
            if query_result3:
                for a1new in query_result3:
                    remarks=""
                    if a1new[9]:
                        remarks = a1new[9].replace('\n','')
                    if i1 in c2cmobiledata:
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('page_name')))#drop page                                                  
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('tracker_id')))#source                                                    
                        c2cmobiledata.append(a1new[4])#last_call_time                                                                                
                        c2cmobiledata.append(a1new[5])#next_call_time                                                                                
                        c2cmobiledata.append(a1new[8])#header disposition                                                                            
                        c2cmobiledata.append(a1new[6])#Disposition                                                                                   
                        c2cmobiledata.append(remarks)#Remarks                                                                                        
                        c2cmobiledata.append(a1new[7])#compain name                                                                                  
                    else:
                        c2cmobiledata.append(a1new[0])#application_ID                                                                                
                        c2cmobiledata.append(a1new[1])#username                                                                                      
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('first_name')+" "+json.loads(a1new[10]).get('last_name')))#customer       
                        c2cmobiledata.append(a1new[2])#mobile                                                                                        
                        c2cmobiledata.append(a1new[3])#created                                                                                       
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('page_name')))#drop page                                                  
                        c2cmobiledata.append(str(json.loads(a1new[10]).get('tracker_id')))#source                                                    
                        c2cmobiledata.append(a1new[4])#last_call_time                                                                                
                        c2cmobiledata.append(a1new[5])#next_call_time                                                                                
                        c2cmobiledata.append(a1new[8])#header disposition                                                                            
                        c2cmobiledata.append(a1new[6])#Disposition                                                                                   
                        c2cmobiledata.append(remarks)#Remarks   
                        c2cmobiledata.append(a1new[7])#compain name                                                                                  

                maindata.append(c2cmobiledata)
                c2cmobiledata=[]
        D2cmobile=[]
        D2cmobiledata=[]
        cur5=connection.cursor()
        query4="select distinct lms.core_customer.mobile from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' and core_campaigndata.application_id = 'BA0000000';"%(from_date,to_date)
        cur5.execute(query4)
        query_result4 = cur5.fetchall()
        if query_result4:
            for k in query_result4:
                D2cmobile.append(k[0])
            #print D2cmobile
            for l in D2cmobile:
             #   print l
                cur6=connection.cursor()
                query5="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.online_created_date between '%s' and '%s' and lms.core_customer.mobile='%s' and lms.core_campaigndata.application_id = 'BA0000000' order by last_call_time asc;" %(from_date,to_date,l)

                cur6.execute(query5)
                query_result5= cur6.fetchall()
                if query_result5:
                    for lnew in query_result5:
                        remarks=""
                        if lnew[9]:
                            remarks = lnew[9].replace('\n','')
                        if l in D2cmobiledata:
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('page_name')))#drop page                                               
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('tracker_id')))#source                                                 
                            D2cmobiledata.append(lnew[4])#last_call_time                                                                             
                            D2cmobiledata.append(lnew[5])#next_call_time                                                                             
                            D2cmobiledata.append(lnew[8])#header disposition                                                                         
                            D2cmobiledata.append(lnew[6])#Disposition                                                                                
                            D2cmobiledata.append(remarks)#Remarks                                                                                    
                            D2cmobiledata.append(lnew[7])#compain name                                                                               
                        else:
                            D2cmobiledata.append(lnew[0])#application_ID                                                                             
                            D2cmobiledata.append(lnew[1])#username                                                                                   
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('first_name')+" "+json.loads(lnew[10]).get('last_name')))#customer     
                            D2cmobiledata.append(lnew[2])#mobile                                                                                     
                            D2cmobiledata.append(lnew[3])#created                                                                                    
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('page_name')))#drop page                                               
                            D2cmobiledata.append(str(json.loads(lnew[10]).get('tracker_id')))#source                                                 
                            D2cmobiledata.append(lnew[4])#last_call_time                                                                             
                            D2cmobiledata.append(lnew[5])#next_call_time                                                                             
                            D2cmobiledata.append(lnew[8])#header disposition                                                                         
                            D2cmobiledata.append(lnew[6])#Disposition                                                                                
                            D2cmobiledata.append(remarks)#Remarks                                                                                    
                            D2cmobiledata.append(lnew[7])#compain name                                                                               

                    maindata.append(D2cmobiledata)
                    D2cmobiledata=[]
        for linew in maindata:
            if linew!=[]:
                #print linew
                writer.writerow([k for k in linew])

        return response
    else:
        return response

@login_required
def call_reports_lms_created(request):
    df = DateForm(request.GET)
    cur = connection.cursor()
    data_row_list=[]
    # response = HttpResponse(content_type='text/csv')
    # response['Content-Disposition'] = 'attachment; filename="Unique_Call_Report_lms_created_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
    # writer = csv.writer(response)
    if df.is_valid():
        from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
        to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
        

        query="select distinct lms.core_campaigndata.application_id,lms.core_campaigndata.id,lms.core_history.id,lms.auth_user.username,lms.core_customer.mobile,lms.core_history.created_on,lms.core_history.call_time,lms.core_history.changed_data,lms.core_campaigndata.last_call_disposition,lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition,lms.core_campaigndata.call_notes,lms.core_campaigndata.data,lms.core_campaigndata.online_created_date,lms.core_history.call_status,lms.core_history.call_disposition,lms.core_campaigndata.aspectcall_start_date,lms.core_campaigndata.aspectcall_end_date,lms.core_campaigndata.aspectcall_duration,lms.core_campaigndata.aspectcall_dialflag from lms.core_campaigndata,lms.core_customer,lms.auth_user,lms.core_campaign,lms.core_history,lms.core_campaigndata_history where lms.core_campaigndata.customer_id=lms.core_customer.id and lms.core_campaigndata.assigned_to_id=lms.auth_user.id and lms.core_campaigndata.campaign_id=lms.core_campaign.id and lms.core_campaigndata_history.campaigndata_id = lms.core_campaigndata.id and lms.core_campaigndata_history.history_id =lms.core_history.id and lms.core_campaigndata.created_on between '%s' and '%s' order by created_on desc;" %(from_date,to_date)
        #query="select * from lms.uniquecreatedon where created_on between '%s' and '%s';" %(from_date,to_date)
        cur.execute(query)
        query_result = cur.fetchall()
        print query_result
        row_count = cur.rowcount
        srno = 1
        filename="Unique_Call_Report_lms_created_%s.xls" % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
        header_row = ["Sr no","Application ID","Username","Customer","Mobile","Application Created Date","Created on","Last call time","Next call time","Application created date","Call Status","Head Disposition","Disposition","Remarks","Campaign Name","Drop Page","Source", "Tracker Channel", "Aspect Call Start Time","Aspect Call End Time","Aspect Call Duration","Aspect Dial Flag"]
        if query_result:
            for i in list(query_result):
                head_disp=''
                for k,v in putils.DISPOSITION_DB.items():
                    for j in v['sub_disposition']:
                        if j[0] == i[15]:
                            head_disp = k
                    row=[srno, str(i[0]), str(i[3]), str(json.loads(i[12]).get('first_name')+" "+ json.loads(i[12]).get('last_name')), str(i[4]), str(i[13]), str(i[5]), str(i[6]), str(json.loads(i[7]).get('later_time')), str(i[13]), str(i[14]),str(head_disp), str(i[15]), str(i[11]), str(i[9]), str(json.loads(i[12]).get('page_name')), str(json.loads(i[12]).get('tracker_id')), str(json.loads(i[12]).get('tracker_channel')), str(i[16]),str(i[17]),str(i[18]),str(i[19])]
                data_row_list.append(row)
                srno = srno + 1
            time.sleep(5) 
            return render_excel(filename, header_row, data_row_list)
        else:
            return render_excel(filename, header_row, data_row_list)
 
        #return HttpResponseRedirect("http://%s/static/downloads/%s" % (settings.SITE_URL, filename))
    return HttpResponse("OK")


# @login_required
# def call_reports_lms_created(request):
#     df = DateForm(request.GET)
#     cur = connection.cursor()
#     response = HttpResponse(content_type='text/csv')
#     response['Content-Disposition'] = 'attachment; filename="Unique_Call_Report_lms_created_%s.csv"' % (datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))
#     writer = csv.writer(response,delimiter=';')
#     if df.is_valid():
#         from_date = df.cleaned_data['from_date'].strftime("%Y-%m-%d %H:%M:%S")
#         to_date = df.cleaned_data['to_date'].strftime("%Y-%m-%d 23:59:59")
#         query="select distinct lms.core_campaigndata.application_id,lms.auth_user.username, lms.core_customer.mobile,lms.core_campaigndata.created_on,lms.core_campaigndata.last_call_time, lms.core_campaigndata.next_call_time, lms.core_campaigndata.last_call_disposition, lms.core_campaign.name,lms.core_campaigndata.last_call_head_disposition, lms.core_campaigndata.call_notes,lms.core_campaigndata.data,lms.core_campaigndata.online_created_date, lms.core_campaigndata.aspectcall_start_date,lms.core_campaigndata.aspectcall_end_date,lms.core_campaigndata.aspectcall_duration,lms.core_campaigndata.aspectcall_dialflag from lms.core_campaigndata left join lms.core_customer on lms.core_campaigndata.customer_id=lms.core_customer.id left join lms.auth_user on lms.core_campaigndata.assigned_to_id=lms.auth_user.id left join lms.core_campaign on lms.core_campaigndata.campaign_id=lms.core_campaign.id where lms.core_campaigndata.created_on between '%s' and '%s' order by created_on desc;" %(from_date,to_date)
#         #query="select * from lms.uniquecreatedon where created_on between '%s' and '%s';" %(from_date,to_date)                                      
#         cur.execute(query)
#         query_result = cur.fetchall()
#         row_count = cur.rowcount
#         srno = 1
#         l=[]
#         camp = []
#         if query_result:
#             for i in list(query_result):
#                 head_disp=''
#                 for k,v in putils.DISPOSITION_DB.items():
#                     for j in v['sub_disposition']:
#                         if j[0] == i[6]:
#                             head_disp = k


#                 row=[
#                     ("Sr no", srno),
#                     ("Application ID", str(i[0])),
#                     ("Username", str(i[1])),
#                     ("Customer", str(json.loads(i[10]).get('first_name')+" "+ json.loads(i[10]).get('last_name'))),
#                     ("Mobile", str(i[2])),
#                     ("Application Created Date", str(i[11])),
#                     ("Created on", str(i[3])),
#                     ("Last call time", str(i[4])),
#                     ("Next call time", str(i[5])),
#                     ("Head Disposition",str(head_disp)),
#                     ("Disposition", str(i[6])),
#                     ("Remarks", str(i[9])),
#                     ("Campaign Name", str(i[7])),
#                     ("Drop Page", str(json.loads(i[10]).get('page_name'))),
#                     ("Source", str(json.loads(i[10]).get('tracker_id'))),

#                     ]
#                 if srno == 1:
#                     writer.writerow([k[0] for k in row])

#                 writer.writerow([k[1] for k in row])
#                 srno = srno + 1
#                     # response.write(i[0])                                                                                                           

#             return response
#         else:

#             return response

@csrf_exempt
@login_required
def make_call(request,mobile,application,cid):                                                                                                           
    dsn = 'sqlserverdatasource'
    user = 'user_click;'
    password = 'pass@123;'
    database = 'ACR;'
#    mobile = mobile.decode('base64')                                                                                                                
    asp_name = request.user.userprofile.aspect_username
    con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)

    cnxn = pyodbc.connect(con_string)
    cur=cnxn.cursor()
    try:
        query="Insert into ClickToDial (SubANI,Field1,App_ID,App_Name,Field2) values('%s','%s','%s','LMS','%s')" %(mobile,asp_name,application,cid)
        cur.execute(query)
        cnxn.commit()
        return HttpResponse('OK')
    except:
        print "Exception in Click to dial"
        return HttpResponse('NOK')


@csrf_exempt
def send_mail(request,application,mobile,email,types):

    data = {'Appno':application,'mobile':mobile,'email':email,'type':types}


    r = requests.get("http://10.155.1.16/buy-term-insurance-online/Calculator/LMSEmail",params=data)

    return HttpResponse(r.text)

@csrf_exempt
@login_required
@utils.profile_type_only("CALLER", 'MANAGER', 'ADMIN')
def ajax_load_inprocess_popup(request):
     current_time_extra = datetime.datetime.now()+datetime.timedelta(minutes=5)
     current_time_extra = current_time_extra.strftime("%Y-%m-%d %H:%M")
     today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
     in_process_calls = CampaignData.objects.filter(Q(
          status = 'IN_PROCESS',
          next_call_time__gte = today_start,
          next_call_time__lte = today_start+datetime.timedelta(days=1),
          assigned_to = request.user,
     )).order_by("-next_call_time")

     l=[]
     inprocess="NA"
     for i in in_process_calls:

          if i.next_call_time.strftime("%Y-%m-%d %H:%M") == current_time_extra:
               inprocess = i.mini_json()

          return HttpResponse(simplejson.dumps(inprocess))
     return HttpResponse(simplejson.dumps(inprocess))


def upload_policy_file(request):
      
      if request.POST or request.FILES:  
          upload_status="upload unsuccessful"    
          try:
              upload_file=request.FILES['upload_file']

              from django.core.files.storage import default_storage

              filename = upload_file._name.replace(' ', '_')
              file_obj = upload_file

              def write_to_disk():
                  with open(default_storage.path('/home/projects/bslilms/static/tmp/'+filename), 'wb+') as destination:
                      for chunk in file_obj.chunks():
                          destination.write(chunk)
                                 
              status = write_to_disk()
              upload_status="upload successful"
              

          except Exception as e:
              print (e)
          
          return HttpResponse(upload_status)
      else:
          return HttpResponseRedirect('/lms/upload/')
import xlrd
def add_plan(request):
    plans=xlrd.open_workbook('/home/projects/bslilms/static/tmp/Plan_Mapping.xlsx')
    worksheet=plans.sheet_by_index(0)
    print worksheet
    offset = 5
    rows = []
    for i ,row in enumerate(range(worksheet.nrows)):
        if i < offset:
             continue
        r = []
        for j,col in enumerate(range(worksheet.ncols)):
             
            r.append(row)
            rows.append(r)
        
    for i in rows:
        print i
        p=Policy.objects.create(data_policy_id=i[0],policy_name=i[1])
    return HttpResponse("data added")


class PolicyPlan(Xl2Python):
   def clean_app(self,val):
          return Policy.object.get(data_policy_id=val)

@never_cache
@utils.profile_type_only("POLICY_PLAN_NAME")
def policy_plan_name_upload(request):
    parse_error = []
    upload_status= " "
    print "dfdfdf"
    if request.POST or request.FILES:      
        try:           
            upload_file=request.FILES['upload_file']
            upfile=UploadFile(upload_file=upload_file,created_by=request.user)
            upfile.save()
            upload_file=upfile.upload_file
            saved = 0
            xl_field_map = {
                '0':'PLAN ID',
                '1':'PLAN DESC'
                }
            error = None
            xlm=PolicyPlan(xl_field_map,upload_file.read())
            print xlm
            if xlm.is_vaild():
               upload_status="upload successfull"
               if not xlm.cleaned_data:
                   upload_status="the first column should be filled"
          
               i = 0
               for d in xlm.cleaned_data:
                   try:
                       i += 1
                       data_policy_id = d['PLAN ID']
                       data_id,created =Policy.objects.get_or_create(data_policy_id=data_policy_id)
                       data_id.data_policy_id= d['PLAN ID']
                       data_id.policy_name = d['PLAN DESC']
                    
                   except Exception as e:
                       print "error to upload plan name and ID",e
                    
                   try:
                       data_id.save()
                       print "data saved",data_id
                   except Exception as e:
                       print "unsucessfull upload"

        except Exception as e:
            print (e)

        return HttpResponse(upload_status)
    else:
        return HttpResponseRedirect('/lms/upload/')


#6043
@login_required
@utils.profile_type_only("MANAGER","ADMIN")
def user_activity(request):
     ''' user activity tab in manager menu:
     1) dashboard : to show all the data where fresh, fresh_data: all unassigned calls, user_name: all to be called calls today, call_cons: all consumed calls and on s\
earch all disposition wise call
     2) checkinform to mark call assign for that particular user as true'''
     campaigns = Campaign.objects.all()
     
     t = date.today()
     t1 = str(t) + " " + "00:00:00"
     t2 = str(t) + " " + "23:59:59"
     user_names = []
     fresh_data = [(camp, CampaignData.objects.filter(status="FRESH", assigned_to__isnull=True, campaign=camp).count())
                   for camp in Campaign.objects.all()]
     fresh_count = sum(x[1] for x in fresh_data)
     dispositions = [k for k,v in putils.DISPOSITION_DB.items()]
     # for no of calls
     user_name = [(user, CampaignData.objects.filter(status__in=['IN_PROCESS','FRESH'], assigned_to_id=user.id, next_call_time__gte=t1, next_call_time__lte=t2).count()\
                       ) for user in User.objects.filter(userprofile__role='CALLER')]
     
     # for no of consumed calls
     call_cons = [(CampaignData.objects.filter(assigned_to_id=user.id, last_call_time__gte=t1, last_call_time__lte=t2).count())
                  for user in User.objects.filter(userprofile__role='CALLER')]

     user_names = [user_name + (call_cons,) for user_name, call_cons in zip(user_name, call_cons)]
     all_call_counts = []
     inprocess_calls = []
     users = [user for user in User.objects.filter(userprofile__role='CALLER')]

     if request.method == 'POST':
          if "calldetails_submit" in request.POST:
               camp = get_object_or_404(Campaign, pk=request.POST.get('campaign'))
               print camp
               fresh_calls = [(user, CampaignData.objects.filter(status__in=['FRESH'], assigned_to_id=user.id, campaign_id=camp.id).count()) for user in User.objects.filter(userprofile__role='CALLER')]
               all_calls = [(CampaignData.objects.filter(status__in=['FRESH','IN_PROCESS'], assigned_to_id=user.id, campaign_id=camp.id).count()) for user in User.objects.filter(userprofile__role='CALLER')]
               all_call_counts = [fresh_calls + (all_calls,) for fresh_calls, all_calls in zip(fresh_calls, all_calls)]
               for user in users:
                    for d in dispositions:
                         inprocess_call = [(user, d, CampaignData.objects.filter(
                                        Q(status = 'IN_PROCESS') &
                                        Q(last_call_head_disposition=d) &
                                        Q(campaign_id=camp.id) &
                                        Q(assigned_to_id=user.id)
                                        ).count())]
                         inprocess_calls.extend(inprocess_call)
                         ############################# call_assignment
          checkin_form = CheckinForm(initial={'callers':[i.id for i in UserProfile.objects.filter(callers_enable=True)]})
          if "checkin_submit" in request.POST:

               a= UserProfile.objects.filter(callers_enable=True),
               checkin_form = CheckinForm(request.POST)
               if checkin_form.is_valid():
                    checkin_form.save()
          
          return render_to_response("core/user_activity.html", {
                     'fresh_data' : fresh_data,
                     'fresh_count' : fresh_count,
                     'user_names' : user_names,
                     'dispositions' : dispositions,
                     'camp' : camp,
                     'users' : users,
                     'all_call_counts' : all_call_counts,
                     'inprocess_calls' : inprocess_calls,
                     'checkin_form':checkin_form,
                     'campaigns' : campaigns,
                     },
                      context_instance=RequestContext(request)
               )
     else:
          checkin_form = CheckinForm(initial={'callers':[i.id for i in UserProfile.objects.filter(callers_enable=True)]})
          return render_to_response("core/user_activity.html", {
                         'fresh_data' : fresh_data,
                         'fresh_count' : fresh_count,
                         'user_names' : user_names,
                         'checkin_form':checkin_form,
                         'campaigns' : campaigns,

                         },

           context_instance=RequestContext(request)
                                    )


@never_cache
@csrf_exempt
def ajax_assign_calls(request):
     data = User.objects.filter(userprofile__role="CALLER", is_active=True,userprofile__callers_enable=True).filter(Q(campaigndata__status__in=("IN_PROCESS","FRESH"))|\
Q(campaigndata__status__isnull=True)).annotate(count = Count('campaigndata__id')).values('username', 'count')
     limit_calls = request.POST['limit_calls']


     campaign = request.POST['assign_campaign']
     print "XXXXXXXXXXXXX",campaign

     if not limit_calls:
          return HttpResponse("INVALID")

     
     if campaign:
          fresh_data = CampaignData.objects.filter(status="FRESH", assigned_to__isnull=True,campaign__id=campaign).order_by('created_on')[:limit_calls]
     else:
          fresh_data = CampaignData.objects.filter(status="FRESH", assigned_to__isnull=True).order_by('created_on')


     if fresh_data:
            try:
               for i in fresh_data:
                    print "value of i ",i
                    tracker_id = i.tracker_id if i.tracker_id else simplejson.loads(i.data).get('tracker_id')
                    print "tracker id is present",tracker_id
                    
                    if not tracker_id or tracker_id=="0":
                        tmpdata = User.objects.filter(userprofile__role="CALLER", is_active=True,userprofile__callers_enable=True,usersession__session__isnull=False,caller_for_campaigns=i.campaign_id).filter(Q(campaigndata__status__in=("FRESH"))|Q(campaigndata__status__isnull=True)).annotate(count = Count('campaigndata__id')).values('username', 'count','id')#Q(campaigndata__status__in=("IN_PROCESS","FRESH")
                        #print "DATAquery_____________", data
                        tmpdata = data 
                        if data:
                            minCount = min(data, key=lambda x:x['count'])
                            #print "MIn w/o tracker:", minCount
                            #print i.id
                            if minCount:
                                # print "___________", mincount
                                i.assigned_to = User.objects.filter(username=minCount.get('username'))[0]
                                i.save()
                        else:
                            print ("No Callers found")
                    else:
                        tmpdata = User.objects.filter(userprofile__role="CALLER", is_active=True,userprofile__callers_enable=True, \
                                                          usersession__session__isnull=False, \
                                                          caller_for_campaigns=i.campaign_id,userprofile__tracker_campaign=tracker_id).filter(Q(campaigndata__status__in=("IN_PROCESS","FRESH")) or Q(campaigndata__status__isnull=True)).annotate(count = Count('campaigndata__id')).values('username', 'count','id')
                        tmpdata = data
                        if len(data) > 0:
                            minCount = min(data, key=lambda x:x['count'])
                            #print i.id
                            if minCount:
                                #print "MIn w tracker:", minCount
                                i.assigned_to = User.objects.filter(username=minCount.get('username'))[0]
                                i.tracker_id = tracker_id
                                i.save()
                        else:
                            print ("No Callers found")

               return HttpResponse("True")

            except Exception as e:
               print e
               return HttpResponse("False")


def call_assign(final_data,campaign_name):
     try:
          campaign_id = Campaign.objects.filter(name=campaign_name)

          tracker_id = TrackerMaster.objects.filter(tracker_id=final_data.get('tracker_id'))
          print "tracker",tracker_id

          if not tracker_id or tracker_id=="0":
               data = User.objects.filter(userprofile__role="CALLER", is_active=True,userprofile__callers_enable=True,usersession__session__isnull=False,caller_for_campaigns=campaign_id[0]).filter(Q(campaigndata__status__in=("FRESH"))|Q(campaigndata__status__isnull=True)).annotate(count = Count('campaigndata__id')).values('username','count','id') #Q(campaigndata__status__in=("IN_PROCESS","FRESH")
               minCount = min(data, key=lambda x:x['count'])
               print "mincount",minCount.get('username')
               return User.objects.filter(id=minCount.get('id'))
          else:
               data = User.objects.filter(userprofile__role="CALLER", is_active=True,userprofile__callers_enable=True,usersession__session__isnull=False,caller_for_campaigns=campaign_id[0],userprofile__tracker_campaign=tracker_id[0]).filter(Q(campaigndata__status__in=("IN_PROCESS","FRESH"))|Q(campaigndata__status__isnull=True)).annotate(count = Count('campaigndata__id')).values('username', 'count','id')
               minCount = min(data, key=lambda x:x['count'])
               print "call_assign", data.query
               print "mincount",minCount.get('username')

               return User.objects.filter(id=minCount.get('id'))
     except Exception as e:
          print e
     else:
          return None
def tracker_assign(request):
     tracker_form = TrackerIdForm()
     user_list = User.objects.filter(userprofile__isnull=False, is_active=True)
     if request.method == "POST":
          tracker_form = TrackerIdForm(request.POST)
          if tracker_form.is_valid():
               tracker_form.save()

          return render_to_response("core/tracker_assign.html", { 'tracker_form':tracker_form,
                                                             'user_list' : user_list,
                                                             'active' : 'users',
                                                        },
                               context_instance=RequestContext(request)
                          )
     else:
          return render_to_response("core/tracker_assign.html", { 'tracker_form':tracker_form,
                                                             'user_list' : user_list,
                                                             'active' : 'users',
                                                        },
                               context_instance=RequestContext(request))


@never_cache
@csrf_exempt
def ajax_get_tracker(request):
     user= request.POST['user']
     used=[]
     if user:
          use = UserProfile.objects.filter(user__id=user).values_list('tracker_campaign')
          for i in use:
               if i not in used:
                    used.append(i[0])
          print used
     else:
          use=""
     return HttpResponse(simplejson.dumps(used))
#6043




# new webservice for policy bazaar and new d2c joint life infosys 6733
# added new header in json insurer = secondary
# 6733  
# date 1 feb 2017

@csrf_exempt
def create_application(request, campaign_name=None):


    print "Name Is Present",campaign_name
    print "API HIT RECORD"
    
    if not request.POST.get('data'):
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Payload missing"}))
        #a =  HttpResponse(simplejson.dumps({'success' : False, 'error' : "payload missing"}).encode('base64','strict'))
        #return(a)

    data = request.POST['data']
    print data


    try:
       rdata = eval(simplejson.loads(data)['data'])
    except:
        try:
            rdata = simplejson.loads(data)
        except:
            try:
                rdata = simplejson.loads(str(data))
            except:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Incorrect serialization"}))
    
    
    try:
        if rdata["Proposer"]:
            rdata = rdata
            is_insurer = "YES"
    except:
        rdata = rdata
        is_insurer = "NO"

    if is_insurer == "YES":
        # added to new d2c
        if rdata["Proposer"]["product_category"] == "SecureSelf" or rdata["Proposer"]["product_category"] == "SecureChild" or  rdata["Proposer"]["product_category"] =="SecureSpouse" or rdata["Proposer"]["product_category"] == "ProtectSelf" or rdata["Proposer"]["product_category"] == "JointLife" or rdata["Proposer"]["product_category"] == "C2C" or  rdata["Proposer"]["product_category"] == "VisionStar" or rdata["Proposer"]["product_category"] == "CancerShield" or rdata["Proposer"]["product_category"]== "WealthProtection" or rdata["Proposer"]["product_category"] == "VisionSelf" or rdata["Proposer"]["product_category"] == "VisionSpouse" or rdata["Proposer"]["product_category"] == "CancerSelf" or rdata["Proposer"]["product_category"] == "CancerSpouse" or rdata["Proposer"]["product_category"] == "WealthSelf" or rdata["Proposer"]["product_category"] == "WeatlhSpouse" or rdata["Proposer"]["product_category"] == "WealthChild":
            try:
                try:
                    if rdata["Proposer"]:
                        pdata = rdata["Proposer"]
                        insurer = rdata["Insurer"]
                        insurer = simplejson.dumps(insurer)
                        final_data, response, rdata_logger = normalize_api_data(pdata)
                except Exception as e:
                    return HttpResponse(simplejson.dumps({'success': False, 'error_msg': "new D2C Json Error", 'error': str(e)}))

                utils.response_logger.info(rdata_logger)
                if response:
                    return HttpResponse(response)

              

                #if campaign_name:
                if rdata["Proposer"]["product_category"] == "C2C":
                    #campaign = Campaign.objects.get(name=campaign_name)
                    campaign = Campaign.objects.get(name="C2C")
                else:
                    # campaign = Campaign.objects.get(name="D2C") change 18 nov
                    if final_data.get('application_id') == "BA0000000":  # 6043

                        campaign = Campaign.objects.get(name="D2CQ")
                    else:

                        campaign = Campaign.objects.get(name="D2C")

                (rdata_logger, response) = conclude_save_lead(final_data, campaign, insurer)
                print "******************\n", rdata_logger, "************************\n"
                utils.response_logger.info(rdata_logger)
                return HttpResponse(response)
            except Exception as e:
                return HttpResponse(simplejson.dumps({'success': False, 'error': "Joint life json error", 'error': e}))
  
    else:    
        try:            
            final_data, response, rdata_logger = normalize_api_data(rdata)
            
            utils.response_logger.info(rdata_logger)
            if response:
                return HttpResponse(response)

            if campaign_name:
                campaign = Campaign.objects.get(name=campaign_name)
            else:
                # campaign = Campaign.objects.get(name="D2C") change 18 nov
                if final_data.get('application_id') == "BA0000000":  # 6043

                    campaign = Campaign.objects.get(name="D2CQ")
                else:
                    campaign = Campaign.objects.get(name="D2C")
            # insurer data should be blank for old d2c 6733
            # 6733
            insurer = ""
            (rdata_logger, response) = conclude_save_lead(final_data, campaign, insurer)
            print "******************\n", rdata_logger, "************************\n"
            utils.response_logger.info(rdata_logger)
            return HttpResponse(response)
        except Exception, e:
            return HttpResponse(simplejson.dumps({'success': False, 'error': str(e)}))


# same infy web service for policy bazaar 6733
# 6733
# date jan feb 2017
@csrf_exempt
@login_required
def create_pb_application(request, campaign_name=None):
    """ 
    Enpoint for PolicyBazaar Incoming Applications 
    Direct Http Data push""" 
    
    if not request.POST.get('data'):
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Payload missing"}))
    
    print "API HIT RECORD:::"
    print "______________________________________________"
    print request.POST['data']
    data = request.POST['data']
    try:
        rdata = simplejson.loads(data)
    except:
        return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Incorrect serialization"}))
    
    try:
        final_data, response, rdata_logger = normalize_api_data(rdata)
        utils.response_logger.info(rdata_logger)
        if response:
            return HttpResponse(response)

        if campaign_name:
            campaign = Campaign.objects.get(name=campaign_name)
        else:
            #return HttpResponse(simplejson.dumps({'success' : False, 'error' : "Campaign name not given."}))
            campaign = Campaign.objects.get(name="D2C")
        (rdata_logger, response) = conclude_save_lead(final_data, campaign)
        print "******************\n", rdata_logger, "************************\n"
        utils.response_logger.info(rdata_logger)
        return HttpResponse(response)
    except Exception, e:

        return HttpResponse(simplejson.dumps({'success': False, 'error' : str(e)}))
