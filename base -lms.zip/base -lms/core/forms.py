from django import forms
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib.auth import authenticate
from django.db.models import Q

import random
import datetime,time
import uuid
import re
import hashlib
from captcha.fields import CaptchaField

from fhurl import RequestForm, RequestModelForm
from customforms.ajaxfield import AjaxField
import json

from core.models import *
import project_utils as putils

class SearchForm(forms.Form):
    query = forms.CharField(required=False)
    from_user = forms.ModelChoiceField(queryset=User.objects.filter(caller_for_campaigns__isnull=False).distinct().order_by('-is_active'), required=False)
    to_user = forms.ModelChoiceField(queryset=User.objects.filter(caller_for_campaigns__isnull=False, is_active=True).distinct(), required=False)
    campaign = forms.ModelChoiceField(queryset=Campaign.objects.all(), required=False)
    is_concluded = forms.BooleanField(required=False)
    from_date = forms.DateField(required=False)
    to_date = forms.DateField(required=False)
    limit_calls = forms.IntegerField(required=False)
    page_choices = forms.ChoiceField(choices=putils.PAGE_CHOICES, required=False)

    # ADD LAST DISPOSITION OF CALL AS A FILTER

    def __init__(self, *args, **kwargs):
        super(SearchForm, self).__init__(*args, **kwargs)
        all_site_ids = [(val['site_id'], val['site_id']) for val in CampaignData.objects.values('site_id').distinct() if val['site_id']]
        all_site_ids.insert(0, ("","-----"))
        self.fields['site_id'] = forms.ChoiceField(choices=all_site_ids, required=False)
        all_product_codes = [(val['product_code'], val['product_code']) for val in CampaignData.objects.values('product_code').distinct() if val['product_code']]
        all_product_codes.insert(0, ("","-----"))
        self.fields['product_code'] = forms.ChoiceField(choices=all_product_codes, required=False)

    def get_query(self, request):
        if request.user.is_authenticated():
            u = request.user
        else:
            u = None

        print "D--------->", self.cleaned_data
        d = self.cleaned_data.get
        query = Q()
        # if d('is_concluded'):
        #     query = query & Q(status__in = ['FRESH','IN_PROCESS','CONCLUDED'])
        # else:
        query = query & Q(status__in = ['FRESH','IN_PROCESS','CONCLUDED'])

        if d('from_date') and d('to_date'):
            query = query & Q(created_on__gte=d('from_date'), created_on__lte=d('to_date'))

        if d('query'):
            query = query & (Q(application_id = d('query')) |
          
            Q(customer__email=d('query')) |
            Q(customer__mobile__icontains=d('query')))

        if d('from_user'):
            query = query & Q(assigned_to = d('from_user'))
        #else:
        # FROM LINE 59  Q(customer__name__icontains=d('query')) |
#   if u.userprofile.role != 'CALLER':
        #        query = query & Q(assigned_to__isnull=True)

 #      if u.userprofile.role == 'CALLER':
  #          query = query & Q(assigned_to=u)

        if d('campaign'):
            query = query & Q(campaign=d('campaign'))

        if d('site_id'):
            query = query & Q(site_id = d('site_id'))
        if d('product_code'):
            query = query & Q(product_code = d('product_code'))
        if d('page_choices'):
            query = query & Q(page_id = d('page_choices'))

        return query

class CampaignForm(RequestModelForm):
    callers = forms.ModelMultipleChoiceField(queryset=User.objects.filter(is_active=True,userprofile__role="CALLER"), widget=forms.CheckboxSelectMultiple())
    admins = forms.ModelMultipleChoiceField(queryset=User.objects.filter(~Q(userprofile__role="CALLER") & Q(is_active=True, is_superuser=False)), widget=forms.CheckboxSelectMultiple())

    class Meta:
        model = Campaign
        exclude = ('upload_schemas','data', 'created_on')

    def init(self, cid=None):
        if cid:
            self.instance = Campaign.objects.get(id=cid)

    def save(self):
        super(CampaignForm, self).save()
        return {'success': True}

class CallForm(forms.Form):
    name = forms.CharField(max_length=255, required=False)

    head_disposition = forms.ChoiceField(choices=[(d, dict(putils.DISPOSITIONS)[d]) for d in putils.VISIBLE_DISPOSITION_MAP.keys()])
    disposition = forms.ChoiceField(choices=putils.DISPOSITIONS)
    later_time = forms.DateTimeField(required=False)

    # Editable fields with Campaign
    #TODO: validation checks for likely_date_of_payment for 3 dispositions : Decision Pending, Payment pending, payment not recvd
    likely_date_of_payment = forms.DateTimeField(required=False)
    notes = forms.CharField(widget=forms.Textarea(attrs={'cols':28,'rows':5}), required=False)
    auto_notes = forms.ChoiceField(choices=putils.DROP_OFF_AUTO_NOTES, required=False)

    #Editable fields with customer
    alt_numbers = forms.CharField(widget=forms.Textarea(attrs={'cols':28, 'rows':3}), required=False) #Save with customer model

class UserManagementForm(RequestForm):
    first_name = forms.CharField(max_length=30)
    last_name = forms.CharField(max_length=30, required=False)
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password", required=False)
    password2 = forms.CharField(widget=forms.PasswordInput, label="Re-enter Password", required=False)
    email = forms.EmailField(required=False)
    status = forms.ChoiceField(choices = (("ENABLED","Active"),("DISABLED","Disabled")), widget=forms.RadioSelect)
    role = forms.ChoiceField(choices=putils.USER_ROLES)
    campaigns = forms.ModelMultipleChoiceField(queryset=Campaign.objects.all(), widget=forms.CheckboxSelectMultiple())
    aspect_username = forms.CharField(max_length=40, required=False)

    def init(self, uid=None):
        all_site_ids = [val['site_id'] for val in CampaignData.objects.values('site_id').distinct() if val['site_id']]
        all_product_codes = [val['product_code'] for val in CampaignData.objects.values('product_code').distinct() if val['product_code']]
        filter_choices = []
        for sid in all_site_ids:
            for pcode in all_product_codes:
                filter_choices.append(("%s--%s" % (sid, pcode), "%s--%s" % (sid, pcode)))
        print filter_choices
        for c in Campaign.objects.all():
            self.fields['campaign_%s' % c.id] = forms.CharField(max_length=255, label="%s SiteID Filter" % c.name, required=False, help_text='e.g. OGOOG, 0WEB')
            #self.fields['campaign_%s' % c.id] = forms.ChoiceField(label="%s Filter" % c.name, required=False, choices=filter_choices)
        self.uid = uid
        if uid:
            u = User.objects.get(id=uid)
            up = u.userprofile
            if up.role == "CALLER": campaign_list = [c for c in u.caller_for_campaigns.all()]
            if up.role == "MANAGER": campaign_list = [c for c in u.manager_for_campaigns.all()]
            if up.role == "ADMIN": campaign_list = [c for c in u.admin_for_campaigns.all()]

            self.fields['tracker_map'] = forms.ModelMultipleChoiceField(UserProfile.objects.get(id=up.id).tracker_campaign.all(),widget=forms.CheckboxSelectMultiple(attrs={'disabled': 'disabled'}),required=False) #6043           

            self.initial = {
                'first_name': u.first_name,
                'last_name': u.last_name,
                'email': u.email,
                'role': u.userprofile.role,
                'status' : "ENABLED" if u.is_active else "DISABLED",
                'aspect_username': u.userprofile.aspect_username,
                'campaigns' : campaign_list
            }
            self.initial.update(up.get_data('call_condition', {}))
        else:
            self.fields['password1'].required = True
            self.fields['password2'].required = True
            self.fields['username'] = forms.CharField(max_length=30)

    def clean_username(self):
        d = self.cleaned_data.get
        u = User.objects.filter(username=d('username'))
        if u:
            raise forms.ValidationError("Username already exists, please choose another username")
        else:
            return d('username')

    def clean_first_name(self):
        d = self.cleaned_data.get
        first_name = d('first_name').strip()
        pattern = "^[a-zA-Z\s]*$"
        match = re.match(pattern, first_name)
        print first_name
        if not match:
            print "blah"
            raise forms.ValidationError("Special characters not allowed in name.")
        return first_name

    def clean_last_name(self):
        d = self.cleaned_data.get
        last_name = d('last_name').strip()
        pattern = "^[a-zA-Z\s]*$"
        match = re.match(pattern, last_name)
        if not match:
            raise forms.ValidationError("Special characters not allowed in name.")
        return last_name

    def clean_password2(self):
        d = self.cleaned_data.get
        if d("password2") != d("password1"):
            raise forms.ValidationError("Passwords do not match.")
        return d("password2")

    def save(self):
        if self.uid: #Existing User
            u = User.objects.get(id=self.uid)
            d = self.cleaned_data.get
            u.first_name = d('first_name')
            u.last_name = d('last_name')
            if d('password1'):
                u.set_password(d('password1'))
            u.email = d('email')
            if d('status') == 'ENABLED':
                u.is_active = True
            else:
                u.is_active = False

            up = UserProfile.objects.filter(user=u)[0]
            up.role = d('role')
            up.aspect_username = d('aspect_username')
            up.save()
            u.save()
        else: #New User
            d = self.cleaned_data.get
            u = User.objects.create_user(
                username = d('username'),
                password = '',
            )
            u.set_password(d('password1'))
            u.first_name = d('first_name')
            u.last_name = d('last_name')
            u.email = d('email')

            if d('status') == 'ENABLED':
                u.is_active = True
            else:
                u.is_active = False
            u.save()
            up = UserProfile(user=u)
            up.role = d('role')
            up.aspect_username = d('aspect_username')
            up.save()

        u.caller_for_campaigns.clear()
        if u.userprofile.role == "CALLER":
            u.caller_for_campaigns.add(*d('campaigns'))

        u.admin_for_campaigns.clear()
        if u.userprofile.role == "ADMIN":
            u.admin_for_campaigns.add(*d('campaigns'))

        campaign_data = [(f, self.cleaned_data.get(f)) for f in self.fields if f.startswith('campaign_') and self.cleaned_data.get(f)]
        up.set_data('call_condition', campaign_data)
        return {'success':True}

class UploadForm(forms.Form):
    upload_file = forms.FileField(max_length=255)

class EmailCampaignForm(forms.Form):
    mobile = forms.CharField(required=True, max_length=200)
    name = forms.CharField(required=True, max_length=200)
    captcha = CaptchaField()
    #dob = forms.CharField(required=True, max_length=200)
    #gender = forms.CharField(required=True, max_length=10)
    tnc = forms.BooleanField()

    def clean_tnc(self):
        tnc = self.cleaned_data.get('tnc', False)
        if not tnc:
            raise forms.ValidationError("Please accept terms and conditions")
        return tnc

    def clean_mobile(self):
        mobile = self.cleaned_data['mobile']
        if not (mobile.isdigit() and len(mobile) == 10):
            raise forms.ValidationError("Please enter valid mobile")
        return mobile

    def clean_name(self):
        name = self.cleaned_data['name']
        if not name.replace(" ","").isalpha():
            raise forms.ValidationError("Please enter valid name")
        return name


class DateForm(forms.Form):
    current_year = datetime.datetime.now().year
    from_date = forms.DateField()
    to_date = forms.DateField()
    campaign = forms.ModelChoiceField(queryset = Campaign.objects.all(), required=False)
    
    # LMS call disposition project - ID 293   
    # LMS disposition - 293  MAy 2017 new D2C
    product = forms.ModelChoiceField(queryset = Product.objects.all(),required=False)


# project worklow 6355 oct 20
#6043
class CheckinForm(forms.Form):
    callers =  forms.ModelMultipleChoiceField(
        queryset=UserProfile.objects.filter(user__is_active=True,role="CALLER"),
        help_text = "Select users to assign calls",widget=forms.CheckboxSelectMultiple(attrs={'class':'callers'}),required=False)
    class Meta:
        model = UserProfile
        fields = ('callers_enable')
    def save(self):
        d = self.cleaned_data.get('callers',False)
        print d
        queryset=UserProfile.objects.filter(user__is_active=True,role="CALLER")

        if not d:
            UserProfile.objects.all().update(callers_enable=False)
        else:

            total_list=[]
            update_list = []
            for k in queryset:
               total_list.append(k.id)
            for i in d:
                update_list.append(i.id)
                userObj=  UserProfile.objects.filter(id=i.id).update(callers_enable=True)
            empty_list = list(set(total_list)-set(update_list))
            for i in empty_list:
                userObj=  UserProfile.objects.filter(id=i).update(callers_enable=False)

class TrackerIdForm(forms.Form):
    callers = forms.ModelChoiceField(queryset=User.objects.filter(is_active=True,userprofile__role="CALLER"))
    tracker_campaign = forms.ModelMultipleChoiceField(queryset=TrackerMaster.objects.all(),
                                                widget=forms.CheckboxSelectMultiple(attrs={'class': 'three'}))
    class Meta:
        model = UserProfile
        fields = ('tracker_campaign')


    def save(self):
        d= self.cleaned_data.get
        for i in  UserProfile.objects.filter(user=d('callers')):
            i.tracker_campaign.clear()
            i.tracker_campaign.add(*d('tracker_campaign'))
            i.save()

#6043
