# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'State'
        db.create_table('core_state', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('is_enabled', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('core', ['State'])

        # Adding model 'City'
        db.create_table('core_city', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('state', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.State'])),
            ('is_major', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('is_enabled', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('is_approved', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('core', ['City'])

        # Adding model 'UploadFile'
        db.create_table('core_uploadfile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('upload_file', self.gf('django.db.models.fields.files.FileField')(max_length=100)),
            ('upload_schema', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.UploadSchema'], null=True, blank=True)),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('output', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('is_processed', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal('core', ['UploadFile'])

        # Adding model 'Campaign'
        db.create_table('core_campaign', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=200)),
            ('manager', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='manager_for_campaigns', null=True, to=orm['auth.User'])),
            ('data', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal('core', ['Campaign'])

        # Adding M2M table for field callers on 'Campaign'
        db.create_table('core_campaign_callers', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('campaign', models.ForeignKey(orm['core.campaign'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('core_campaign_callers', ['campaign_id', 'user_id'])

        # Adding M2M table for field upload_schemas on 'Campaign'
        db.create_table('core_campaign_upload_schemas', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('campaign', models.ForeignKey(orm['core.campaign'], null=False)),
            ('uploadschema', models.ForeignKey(orm['core.uploadschema'], null=False))
        ))
        db.create_unique('core_campaign_upload_schemas', ['campaign_id', 'uploadschema_id'])

        # Adding M2M table for field admins on 'Campaign'
        db.create_table('core_campaign_admins', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('campaign', models.ForeignKey(orm['core.campaign'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('core_campaign_admins', ['campaign_id', 'user_id'])

        # Adding model 'UploadSchema'
        db.create_table('core_uploadschema', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=150)),
            ('raw_data', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('field_map', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal('core', ['UploadSchema'])

        # Adding model 'UserProfile'
        db.create_table('core_userprofile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['auth.User'], unique=True)),
            ('role', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('data', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('aspect_username', self.gf('django.db.models.fields.CharField')(max_length=40, null=True, blank=True)),
            ('callers_enable', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('core', ['UserProfile'])

        # Adding M2M table for field tracker_campaign on 'UserProfile'
        db.create_table('core_userprofile_tracker_campaign', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('userprofile', models.ForeignKey(orm['core.userprofile'], null=False)),
            ('trackermaster', models.ForeignKey(orm['core.trackermaster'], null=False))
        ))
        db.create_unique('core_userprofile_tracker_campaign', ['userprofile_id', 'trackermaster_id'])

        # Adding model 'TimeTracker'
        db.create_table('core_timetracker', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('start_time', self.gf('django.db.models.fields.DateTimeField')(blank=True)),
            ('end_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('data', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal('core', ['TimeTracker'])

        # Adding model 'Customer'
        db.create_table('core_customer', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, blank=True)),
            ('mobile', self.gf('django.db.models.fields.CharField')(max_length=20, db_index=True)),
            ('alt_numbers', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('email', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=200, blank=True)),
        ))
        db.send_create_signal('core', ['Customer'])

        # Adding model 'History'
        db.create_table('core_history', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('changed_data', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('caller', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('call_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('call_disposition', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('next_call_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('call_status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
        ))
        db.send_create_signal('core', ['History'])

        # Adding model 'PageMaster'
        db.create_table('core_pagemaster', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('page_name', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('page_weight', self.gf('django.db.models.fields.IntegerField')(max_length=20, null=True, blank=True)),
            ('page_enabled', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('core', ['PageMaster'])

        # Adding model 'TrackerMaster'
        db.create_table('core_trackermaster', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('tracker_id', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('agent_code', self.gf('django.db.models.fields.CharField')(max_length=100, null=True, blank=True)),
            ('tracker_source', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('tracker_channel', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('cms_code', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('ingenium_code', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('tracker_campaign', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('tracker_enabled', self.gf('django.db.models.fields.BooleanField')(default=True)),
        ))
        db.send_create_signal('core', ['TrackerMaster'])

        # Adding model 'UserSession'
        db.create_table('core_usersession', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['auth.User'], unique=True)),
            ('session', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['sessions.Session'])),
        ))
        db.send_create_signal('core', ['UserSession'])

        # Adding model 'CampaignData'
        db.create_table('core_campaigndata', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('data', self.gf('django.db.models.fields.TextField')()),
            ('application_id', self.gf('django.db.models.fields.CharField')(max_length=20, blank=True)),
            ('status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('assigned_to', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'], null=True, blank=True)),
            ('created_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('uploaded_on', self.gf('django.db.models.fields.DateTimeField')(auto_now_add=True, blank=True)),
            ('campaign', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.Campaign'])),
            ('customer', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['core.Customer'])),
            ('last_call_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('last_call_disposition', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('last_call_head_disposition', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('call_notes', self.gf('django.db.models.fields.CharField')(max_length=200, null=True, blank=True)),
            ('next_call_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('is_taken', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('site_id', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=200, blank=True)),
            ('product_code', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=200, blank=True)),
            ('source', self.gf('django.db.models.fields.CharField')(db_index=True, max_length=200, blank=True)),
            ('in_emerge', self.gf('django.db.models.fields.CharField')(max_length=10, blank=True)),
            ('in_emerge_status', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('emerge_transaction_end_time', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('online_created_date', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('page_weight', self.gf('django.db.models.fields.IntegerField')(max_length=20, null=True, blank=True)),
            ('page_id', self.gf('django.db.models.fields.IntegerField')(max_length=20, null=True, blank=True)),
            ('aspectcall_start_date', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('aspectcall_end_date', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('aspectcall_duration', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('aspectcall_dialflag', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('tracker_id', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
        ))
        db.send_create_signal('core', ['CampaignData'])

        # Adding M2M table for field history on 'CampaignData'
        db.create_table('core_campaigndata_history', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('campaigndata', models.ForeignKey(orm['core.campaigndata'], null=False)),
            ('history', models.ForeignKey(orm['core.history'], null=False))
        ))
        db.create_unique('core_campaigndata_history', ['campaigndata_id', 'history_id'])


    def backwards(self, orm):
        # Deleting model 'State'
        db.delete_table('core_state')

        # Deleting model 'City'
        db.delete_table('core_city')

        # Deleting model 'UploadFile'
        db.delete_table('core_uploadfile')

        # Deleting model 'Campaign'
        db.delete_table('core_campaign')

        # Removing M2M table for field callers on 'Campaign'
        db.delete_table('core_campaign_callers')

        # Removing M2M table for field upload_schemas on 'Campaign'
        db.delete_table('core_campaign_upload_schemas')

        # Removing M2M table for field admins on 'Campaign'
        db.delete_table('core_campaign_admins')

        # Deleting model 'UploadSchema'
        db.delete_table('core_uploadschema')

        # Deleting model 'UserProfile'
        db.delete_table('core_userprofile')

        # Removing M2M table for field tracker_campaign on 'UserProfile'
        db.delete_table('core_userprofile_tracker_campaign')

        # Deleting model 'TimeTracker'
        db.delete_table('core_timetracker')

        # Deleting model 'Customer'
        db.delete_table('core_customer')

        # Deleting model 'History'
        db.delete_table('core_history')

        # Deleting model 'PageMaster'
        db.delete_table('core_pagemaster')

        # Deleting model 'TrackerMaster'
        db.delete_table('core_trackermaster')

        # Deleting model 'UserSession'
        db.delete_table('core_usersession')

        # Deleting model 'CampaignData'
        db.delete_table('core_campaigndata')

        # Removing M2M table for field history on 'CampaignData'
        db.delete_table('core_campaigndata_history')


    models = {
        'auth.group': {
            'Meta': {'object_name': 'Group'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'auth.permission': {
            'Meta': {'ordering': "('content_type__app_label', 'content_type__model', 'codename')", 'unique_together': "(('content_type', 'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'core.campaign': {
            'Meta': {'object_name': 'Campaign'},
            'admins': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'admin_for_campaigns'", 'symmetrical': 'False', 'to': "orm['auth.User']"}),
            'callers': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'caller_for_campaigns'", 'symmetrical': 'False', 'to': "orm['auth.User']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'data': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'manager': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'manager_for_campaigns'", 'null': 'True', 'to': "orm['auth.User']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '200'}),
            'upload_schemas': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['core.UploadSchema']", 'null': 'True', 'blank': 'True'})
        },
        'core.campaigndata': {
            'Meta': {'object_name': 'CampaignData'},
            'application_id': ('django.db.models.fields.CharField', [], {'max_length': '20', 'blank': 'True'}),
            'aspectcall_dialflag': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'aspectcall_duration': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'aspectcall_end_date': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'aspectcall_start_date': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'assigned_to': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']", 'null': 'True', 'blank': 'True'}),
            'call_notes': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'campaign': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['core.Campaign']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'customer': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['core.Customer']"}),
            'data': ('django.db.models.fields.TextField', [], {}),
            'emerge_transaction_end_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'history': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['core.History']", 'symmetrical': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'in_emerge': ('django.db.models.fields.CharField', [], {'max_length': '10', 'blank': 'True'}),
            'in_emerge_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'is_taken': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_call_disposition': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'last_call_head_disposition': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'last_call_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'next_call_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'online_created_date': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'page_id': ('django.db.models.fields.IntegerField', [], {'max_length': '20', 'null': 'True', 'blank': 'True'}),
            'page_weight': ('django.db.models.fields.IntegerField', [], {'max_length': '20', 'null': 'True', 'blank': 'True'}),
            'product_code': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'site_id': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'source': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'tracker_id': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'uploaded_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'})
        },
        'core.city': {
            'Meta': {'object_name': 'City'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_approved': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_enabled': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_major': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'state': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['core.State']"})
        },
        'core.customer': {
            'Meta': {'object_name': 'Customer'},
            'alt_numbers': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'email': ('django.db.models.fields.CharField', [], {'db_index': 'True', 'max_length': '200', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'mobile': ('django.db.models.fields.CharField', [], {'max_length': '20', 'db_index': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'})
        },
        'core.history': {
            'Meta': {'object_name': 'History'},
            'call_disposition': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'call_status': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'call_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'caller': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'changed_data': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'next_call_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'})
        },
        'core.pagemaster': {
            'Meta': {'object_name': 'PageMaster'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'page_enabled': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'page_name': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'page_weight': ('django.db.models.fields.IntegerField', [], {'max_length': '20', 'null': 'True', 'blank': 'True'})
        },
        'core.state': {
            'Meta': {'object_name': 'State'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_enabled': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'core.timetracker': {
            'Meta': {'object_name': 'TimeTracker'},
            'data': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'end_time': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'start_time': ('django.db.models.fields.DateTimeField', [], {'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'core.trackermaster': {
            'Meta': {'object_name': 'TrackerMaster'},
            'agent_code': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'cms_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'ingenium_code': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'tracker_campaign': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'tracker_channel': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'tracker_enabled': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'tracker_id': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'}),
            'tracker_source': ('django.db.models.fields.CharField', [], {'max_length': '200', 'null': 'True', 'blank': 'True'})
        },
        'core.uploadfile': {
            'Meta': {'object_name': 'UploadFile'},
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'created_on': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_processed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'output': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'upload_file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            'upload_schema': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['core.UploadSchema']", 'null': 'True', 'blank': 'True'})
        },
        'core.uploadschema': {
            'Meta': {'object_name': 'UploadSchema'},
            'field_map': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'raw_data': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '150'})
        },
        'core.userprofile': {
            'Meta': {'object_name': 'UserProfile'},
            'aspect_username': ('django.db.models.fields.CharField', [], {'max_length': '40', 'null': 'True', 'blank': 'True'}),
            'callers_enable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'data': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'tracker_campaign': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'tracker_for_campaigns'", 'symmetrical': 'False', 'to': "orm['core.TrackerMaster']"}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['auth.User']", 'unique': 'True'})
        },
        'core.usersession': {
            'Meta': {'object_name': 'UserSession'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'session': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['sessions.Session']"}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['auth.User']", 'unique': 'True'})
        },
        'sessions.session': {
            'Meta': {'object_name': 'Session', 'db_table': "'django_session'"},
            'expire_date': ('django.db.models.fields.DateTimeField', [], {'db_index': 'True'}),
            'session_data': ('django.db.models.fields.TextField', [], {}),
            'session_key': ('django.db.models.fields.CharField', [], {'max_length': '40', 'primary_key': 'True'})
        }
    }

    complete_apps = ['core']