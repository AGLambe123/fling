from django.conf.urls.defaults import patterns, url, include
from django.views.generic.simple import direct_to_template

from fhurl import fhurl
from core.forms import *

from django.views.generic.base import TemplateView

urlpatterns = patterns('core.views',
    url(r'^$', 'index'),
    url(r'^create-application/', 'create_application'),


    url(r'^create-application/(?P<campaign_name>[\w\ ]+)/$', 'create_application'),
    #url(r'^create-application/C2C/$', 'create_application', {'campaign_name' : 'C2C'}),



    url(r'^create-pb-application/$', 'create_pb_application'),     
    url(r'^call-form/(?P<pid>[\w-]+)/$', 'call_form'),
    url(r'^call-detail/(?P<pid>[\w-]+)/$', 'call_detail'),

    fhurl(r'^ajax/user-add/$', UserManagementForm, template="core/ajax_user_form.html", json=True),
    fhurl(r'^ajax/user-add/(?P<uid>[\w-]+)/$', UserManagementForm, template="core/ajax_user_form.html", json=True),

    url(r'^ajax/save-notes/$', 'ajax_save_notes'),
    url(r'^ajax/activity-log/$', 'ajax_activity_log'),
    url(r'^ajax/stats/daily/$', 'ajax_daily_stats'),
    url(r'^ajax/stats/monthly/$', 'ajax_monthly_stats'),
    url(r'^ajax/stats/yearly/$', 'ajax_yearly_stats'),

    url(r'^ajax/load-initial-calls/$', 'ajax_load_initial_calls'),
    url(r'^ajax/search/$', 'ajax_search'),
    #url(r'^ajax/calls-by-user/$', 'ajax_calls_by_user'),
    url(r'^ajax/load-calls/$', 'ajax_load_calls'),
    url(r'^ajax/load-waiting-calls/$', 'ajax_load_waiting_calls'),
    url(r'^ajax/inprocess_popup/$', 'ajax_load_inprocess_popup'), #6125    
    url(r'^caller/dashboard/$', 'caller_dashboard'),
    url(r'^report/dashboard/$', 'report_dashboard'),

    url(r'^manager/dashboard/$', 'manager_dashboard'),

    fhurl(r'^manager/dashboard/campaign/add/$', CampaignForm, template="core/mcampaign_manage.html"),
    fhurl(r'^manager/dashboard/campaign/(?P<cid>[\w-]+)/$', CampaignForm, template="core/mcampaign_manage.html"),
    fhurl(r'^ajax/campaign-add/$', CampaignForm, template="core/ajax_campaign_form.html", json=True),
    fhurl(r'^ajax/campaign-add/(?P<cid>[\w-]+)/$', CampaignForm, template="core/ajax_campaign_form.html", json=True),


    url(r'^manager/dashboard/preset-upload/$', 'preset_upload'),
    url(r'^manager/dashboard/preset-upload/(?P<upload_type>[\w-]+)/$', 'campaign_preset_upload'),
    url(r'^manager/dashboard/upload-history/$', 'upload_history'),
    url(r'^manager/dashboard/upload-history/(?P<uid>[\w-]+)/$', 'upload_history'),

    url(r'^manager/dashboard/campaign/(?P<cid>[\w-]+)/upload-config/$', 'setup_upload'),
    url(r'^manager/dashboard/campaign/(?P<cid>[\w-]+)/upload-config/(?P<uid>[\w-]+)/$','setup_upload_edit'),
    url(r'^manager/dashboard/campaign/(?P<cid>[\w-]+)/upload/(?P<uid>[\w-]+)/$', 'campaign_upload'),


    url(r'^manager/dashboard/report/$', 'manager_reports'),

    url(r'^manager/dashboard/reassign-calls/$', 'manager_reassign_calls'),
#    url(r'^manager/dashboard/user-session/$', 'user_sessions'), #6109                                                                                


    url(r'^manager/dashboard/workload/', 'workload'),
    url(r'^manager/dashboard/search/$', 'manager_search'),
    url(r'^reports/last-call-disposition-report/$', 'last_call_disposition_reports'),

    url(r'^reports/call-report/$', 'call_report'),
    url(r'^reports/unique-customerwise-report/$', 'unique_customerwise_report'),   
    #url(r'^reports/unique-customerwise-report/$', 'call_reports'),
    url(r'^reports/unique-call-reports/$', 'call_reports'),

    url(r'^reports/callhistory-report/$', 'callhistory_report'),
    url(r'^reports/disposition-agent-wise/$', 'report_disposition_agent_wise'),
    url(r'^reports/disposition-month-wise/$', 'report_disposition_month_wise'),
    url(r'^reports/last-call-customerwise-dump/$', 'last_call_customerwise_dump'),
    url(r'^reports/last-call-campaignwise-dump/$', 'last_call_campaignwise_dump'),
    url(r'^reports/multipledisposition_report/$', 'multipledisposition_report'),
    url(r'^reports/call-reports-created/$', 'call_reports_created'),
    url(r'^reports/multiple-reports-created/$', 'multiple_reports_created'),
    url(r'^reports/call-reports-lms-created/$', 'call_reports_lms_created'),
    #url(r'^c2c/(?P<source_code>[\w-]+)/(?P<promo_id>[\w-]+)/(?P<site_id>[\w-]+)/(?P<banner_id>[\w-]+)/(?P<agent_code>[\w-]+)/$', 'c2c_campaign'),
    url(r'^c2c/$', 'c2c_campaign'),
    url(r'^c2c-success/$', 'c2c_campaign_success'),
    url(r'^make-call/(?P<mobile>[\d-]+)/(?P<application>[\w-]+)/(?P<cid>[\d-]+)', 'make_call'),
    url(r'^send_mail/(?P<application>[\w-]+)/(?P<mobile>[\d-]+)/(?P<email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/(?P<types>[\w-]+)', 'send_mail'),


    url(r'^lms/upload/$',TemplateView.as_view(template_name='core/data_upload.html')),
    url(r'^policy-plan-name-upload/$','upload_policy_file'),
    url(r'^policy_plan/$','add_plan'),
    #url(r'^policy_plans/$','policy_plan_name_upload')

    url(r'^manager/dashboard/user-activity/', 'user_activity'), #6043
    url(r'^ajax/get-tracker/$', 'ajax_get_tracker'),  #6043
    url(r'^ajax/assign-calls/$', 'ajax_assign_calls'), #6043
    url(r'^manager/dashboard/tracker-assign/$', 'tracker_assign'),# 6043 
    url(r'^manager/dashboard/activity/$', 'user_activity'), ##6043##


)
