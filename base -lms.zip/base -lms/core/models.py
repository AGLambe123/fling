from django.db import models
from django.contrib.auth.models import User
from customdb.uuidfield import UUIDField
from django.core import serializers
import os
import datetime, simplejson, json
from django.core.serializers.json import DjangoJSONEncoder
from django.db.models import Count
from django.utils.html import escape
from django.template.defaultfilters import timesince
import project_utils as putils

#6109
from django.contrib.auth.signals import user_logged_in
from django.contrib.sessions.models import Session

from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
#6109

User.__str__ = lambda x: x.get_full_name() if x.get_full_name() else "%s" % (x.username)
User.__unicode__ = lambda x: x.get_full_name() if x.get_full_name() else "%s" % (x.username)

#6109
def user_logged_in_handler(sender, request, user, **kwargs):
    try:
        UserSession.objects.get_or_create(
            user = user,
            session_id = request.session.session_key
        )
    except IntegrityError as e:
        return HttpResponseRedirect('/accounts/login')

user_logged_in.connect(user_logged_in_handler)

def delete_user_sessions(user):
    user_sessions = UserSession.objects.filter(user = user)
    for user_session in user_sessions:
        user_session.session.delete()
#6109

class State(models.Model):
    name = models.CharField(max_length=100)
    is_enabled = models.BooleanField()
    def __str__(self):
        return self.name

class City(models.Model):
    name = models.CharField(max_length=100)
    state = models.ForeignKey('State')
    is_major = models.BooleanField()
    is_enabled = models.BooleanField()
    is_approved = models.BooleanField()

    def __str__(self):
        return "%s" % (self.name)

class UploadFile(models.Model):
    upload_file = models.FileField(upload_to=putils.get_file_path)
    upload_schema = models.ForeignKey('UploadSchema', null=True, blank=True)
    created_by = models.ForeignKey(User) #User who uploaded file
    output = models.TextField(blank=True) #Output of the upload
    is_processed = models.BooleanField(default=False) # for sftp or delayed processing, use this flag
    created_on = models.DateTimeField(auto_now_add=True)

class Campaign(models.Model):
    """ Campaign models, user dashboard depend on the campaign
    """
    name = models.CharField(max_length=200)
    callers = models.ManyToManyField(User, related_name="caller_for_campaigns", verbose_name="Calling Agents")  # Must be of role CALLER, user.userprofile.role = "CALLER"
    upload_schemas = models.ManyToManyField('UploadSchema', blank=True, null=True)
    manager = models.ForeignKey(User, related_name="manager_for_campaigns", null=True, blank=True)   # Must be of role manager, user.userprofile.role = "MANAGER"
    data = models.TextField(blank=True) # Color codes, pics, text etc.
    created_on = models.DateTimeField(auto_now_add=True)
    admins = models.ManyToManyField(User, related_name="admin_for_campaigns", verbose_name="Campaign Admins")  # Must be of role ADMIN, user.userprofile.role = "ADMIN"

    def __str__(self):
        return "%s" % (self.name)


# LMS Call disposition project - ID 293
class Product(models.Model):
    pro_name = models.CharField(max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "%s"%(self.pro_name)







class UploadSchema(models.Model):
    title = models.CharField(max_length=150)
    raw_data = models.TextField(blank=True)  #json serialized setup value
    field_map = models.TextField(blank=True) #json serialized data, dependent on the type

class UserProfile(models.Model):
    """ CALLER gets calls
    MANAGER manages calling group(s)
    ADMING manages everything
    REPORT gets all reports
    UPLOAD does uploads for campaigns
    """
    user = models.OneToOneField(User)
    role = models.CharField(max_length=100, choices=putils.USER_ROLES, blank=True)
    data = models.TextField(blank=True)
    aspect_username = models.CharField(max_length=40, blank=True, null=True)
    callers_enable = models.BooleanField(default=False) #6043
    tracker_campaign = models.ManyToManyField('TrackerMaster',related_name="tracker_for_campaigns", verbose_name = "Tracker campaigns") 

    def __str__(self):
        return "%s - %s" % (self.user.username, self.role)

    def set_data(self, key, jdata):
        if self.data:
            udata = json.loads(self.data)
        else:
            udata = {}
        udata[key] = jdata
        self.data = json.dumps(udata)
        self.save()

    def get_data(self, key, default=None):
        if self.data:
            udata = json.loads(self.data)
            return udata.get(key, default)
        else:
            return default

class TimeTracker(models.Model):
    """ Track time-in and time-out for
    multiple breaks and events
    """
    user = models.ForeignKey(User)
    type = models.CharField(max_length=100, choices=putils.EVENT_TYPES)
    start_time = models.DateTimeField(blank=True)
    end_time = models.DateTimeField(blank=True, null=True)
    data = models.TextField(blank=True)

    def __str__(self):
        return "%s - %s" % (self.user.username, self.type)

class Customer(models.Model):
    name = models.CharField(max_length=255, blank=True)
    mobile = models.CharField(max_length=20, db_index=True)
    alt_numbers = models.TextField(blank=True)
    email = models.CharField(max_length=200, blank=True, db_index=True)

    def __str__(self):
        return self.mobile

class History(models.Model):
    changed_data = models.TextField(blank=True)
    caller = models.ForeignKey(User)
    call_time = models.DateTimeField(null=True, blank=True)
    call_disposition = models.CharField(max_length=100, choices = putils.DISPOSITIONS)
    next_call_time = models.DateTimeField(null=True, blank=True)
    call_status = models.CharField(max_length=100, choices=putils.CAMPAIGN_DATA_STATUS, blank=True)
    created_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "%d - %s - %s" % (self.id, self.call_disposition, self.caller.get_full_name())

    def get_main_disposition(self):
        rvmap = putils.REV_DISTRIBUTION_MAP.copy()
        rvmap.update({
            'FRESH_CALLS': 'SYSTEM',
            'DUPLICATE_API' : 'SYSTEM',
            'LIMIT_EXCEEDED' : 'SYSTEM',
            'DONE' : 'SYSTEM',
            'PAYMENT_SUCCESSFUL' : 'SYSTEM',
        })
        dispo_dict = dict(putils.VERBOSE_DISPOSITION)
        dispo_dict.update({
            'FRESH_CALLS' : 'Fresh Calls',
            'DUPLICATE_API' : 'Duplicate Disposed',
            'LIMIT_EXCEEDED' : 'Limit exceeded',
            'SYSTEM' : 'System',
            'DONE' : 'System Done',
            'PAYMENT_SUCCESSFUL' : 'Payment successfull'
        })
        return dispo_dict[rvmap[self.call_disposition]]

FRESH_NEXT_CALLTIME = datetime.timedelta(hours=3)
INTERESTED_NEXT_CALLTIME = datetime.timedelta(hours=32)

class PageMaster(models.Model):
    page_name = models.CharField(max_length=200, blank=True, null=True)
    page_weight = models.IntegerField(max_length=20, blank=True, null=True)
    page_enabled = models.BooleanField(default=False)

##6043                                                                                                                                                                  
class TrackerMaster(models.Model):
    tracker_id = models.CharField(max_length=200, blank=True, null=True)
    agent_code = models.CharField(max_length=100, blank=True, null=True)
    tracker_source = models.CharField(max_length=200, blank=True, null=True)
    tracker_channel = models.CharField(max_length=200, blank=True, null=True)
    cms_code=models.CharField(max_length=200, blank=True, null=True)
    ingenium_code=models.CharField(max_length=200, blank=True, null=True)
    tracker_campaign = models.CharField(max_length=200, blank=True, null=True)
    created_on = models.DateTimeField(auto_now_add=True)
    tracker_enabled = models.BooleanField(default=True)
    def __str__(self):
        return "%s (%s - %s - %s - %s )" % (self.tracker_id,self.agent_code ,self.tracker_source,self.tracker_channel,self.tracker_campaign)

# 6109
class UserSession(models.Model):
    user = models.OneToOneField(User)
    session = models.ForeignKey(Session)

#create to identify policy type 10 sept 2016
class Policy(models.Model):
    data_policy_id = models.CharField(max_length=50, blank=True, null=True)
    policy_name = models.CharField(max_length=100, blank=True, null=True)
    notes = models.CharField(max_length=100, blank=True, null=True)
    coverage_no = models.CharField(max_length =100, blank=True, null =True)
    policy_type = models.CharField(max_length =100, blank=True, null =True)
    policy_cvg  = models.CharField(max_length =100, blank=True, null =True)
    policy_connect_cvg = models.CharField(max_length =100, blank=True, null =True)

class UserDefinedGlobal(models.Model):
    field_name = models.CharField(max_length=50, blank=True)
    field_value = models.CharField(max_length =100, blank=True)
    is_active_field = models.BooleanField(default=True)
    created_field = models.DateTimeField(auto_now_add=True)    

#create table to dnc no data 13 sept 2016 15523
class CampaignDataStaging(models.Model):
    data = models.TextField()
    application_id = models.CharField(max_length=20, blank=True)
    status = models.CharField(max_length=100, choices=putils.CAMPAIGN_DATA_STATUS, blank=True)
    assigned_to = models.ForeignKey(User, blank=True, null=True)
    history = models.ManyToManyField('History')
    created_on = models.DateTimeField(auto_now_add=True)
    uploaded_on = models.DateTimeField(auto_now_add=True)
    campaign = models.ForeignKey('Campaign')
    customer = models.ForeignKey('Customer')

    last_call_time = models.DateTimeField(null=True, blank=True)
    last_call_disposition = models.CharField(max_length=100, choices = putils.DISPOSITIONS)
    last_call_head_disposition = models.CharField(max_length=200,null=True, blank=True)
    call_notes = models.CharField(max_length=200,null=True, blank=True)
    next_call_time = models.DateTimeField(null=True, blank=True)
    is_taken = models.BooleanField(default=False)
    site_id = models.CharField(max_length=200, db_index=True, blank=True)
    product_code = models.CharField(max_length=200, db_index=True, blank=True)
    source = models.CharField(max_length=200, db_index=True, blank=True)

    in_emerge = models.CharField(max_length=10, blank=True)
    in_emerge_status = models.CharField(max_length=100, choices=putils.EMERGE_STATUS, blank=True)
    emerge_transaction_end_time = models.DateTimeField(null=True, blank=True)
    online_created_date = models.DateTimeField(null=True, blank=True)
    page_weight = models.IntegerField(max_length=20, blank=True, null=True) #5820
    page_id = models.IntegerField(max_length=20, blank=True, null=True)#5820
    aspectcall_start_date = models.DateTimeField(null=True, blank=True)#5896-aspect data
    aspectcall_end_date = models.DateTimeField(null=True, blank=True)#5896
    aspectcall_duration= models.CharField(max_length=30, blank=True)#5896
    #aspectcall_created_on = models.DateTimeField(null=True, blank=True)#5896
    aspectcall_dialflag = models.CharField(max_length=30, blank=True)#5896
    tracker_id = models.CharField(max_length=30, blank=True)#6043
    #web_id = models.CharField(max_length=30, blank=True) # 6346
    #web_source = models.CharField(max_length=30, blank=True) # 6346
   
    #added to identify policy type 12 sept 2016
    #base_plan = models.ForeignKey('Policy', null=True, blank=True)

    def __str__(self):
        return "%s-%s" % (self.customer.mobile, self.application_id)

class CampaignData(models.Model):
    data = models.TextField()
    application_id = models.CharField(max_length=20, blank=True)
    status = models.CharField(max_length=100, choices=putils.CAMPAIGN_DATA_STATUS, blank=True)
    assigned_to = models.ForeignKey(User, blank=True, null=True)
    history = models.ManyToManyField('History')
    created_on = models.DateTimeField(auto_now_add=True)
    uploaded_on = models.DateTimeField(auto_now_add=True)
    campaign = models.ForeignKey('Campaign')
    customer = models.ForeignKey('Customer')
    last_call_time = models.DateTimeField(null=True, blank=True)
    last_call_disposition = models.CharField(max_length=100, choices = putils.DISPOSITIONS)
    last_call_head_disposition = models.CharField(max_length=200,null=True, blank=True)
    call_notes = models.CharField(max_length=200,null=True, blank=True)
    next_call_time = models.DateTimeField(null=True, blank=True)
    is_taken = models.BooleanField(default=False)
    site_id = models.CharField(max_length=200, db_index=True, blank=True)
    product_code = models.CharField(max_length=200, db_index=True, blank=True)
    source = models.CharField(max_length=200, db_index=True, blank=True)
    in_emerge = models.CharField(max_length=10, blank=True)
    in_emerge_status = models.CharField(max_length=100, choices=putils.EMERGE_STATUS, blank=True)
    emerge_transaction_end_time = models.DateTimeField(null=True, blank=True)
    online_created_date = models.DateTimeField(null=True, blank=True)
    page_weight = models.IntegerField(max_length=20, blank=True, null=True) #5820 
    page_id = models.IntegerField(max_length=20, blank=True, null=True)#5820
    aspectcall_start_date = models.DateTimeField(null=True, blank=True)#5896-aspect data
    aspectcall_end_date = models.DateTimeField(null=True, blank=True)#5896
    aspectcall_duration= models.CharField(max_length=30, blank=True)#5896
    #aspectcall_created_on = models.DateTimeField(null=True, blank=True)#5896
    aspectcall_dialflag = models.CharField(max_length=30, blank=True)#5896
    tracker_id = models.CharField(max_length=30, blank=True)#6043
    #web_id = models.CharField(max_length=30, blank=True) # 6346                                                                                                       
    #web_source = models.CharField(max_length=30, blank=True) # 6346    
    #base_plan = models.ForeignKey('Policy', null=True, blank=True, default='')
    

    #added extra column for insurer AND secondary insurer 3 feb 2017 6733
    insurer_data = models.TextField(default = '') # 6733
    
    product_name = models.CharField(max_length=200, blank=True) # 6733 

    def __str__(self):
        return "%s-%s" % (self.customer.mobile, self.application_id)

    def get_complete_history(self):
        history_list = History.objects.filter(campaigndata__customer=self.customer).order_by('-id')
        for h in  history_list:
            h.changed_data = simplejson.loads(h.changed_data)
            h.changed_data['auto_notes'] = putils.VERBOSE_DROP_OFF_AUTO_NOTES.get(h.changed_data.get('auto_notes',''))
        return history_list

    def get_other_campaigns_of_customer(self):
        #return [(cp['campaign__name'], cp['count']) for cp in self.customer.campaigndata_set.values('campaign__name').annotate(count=Count('campaign__name'))]
        return self.customer.campaigndata_set.order_by('created_on')

    def mini_json(self):
        od = simplejson.loads(self.data)
        
        #6733
        try:
            od1 = simplejson.loads(self.insurer_data)
        except:
            od1 = {}


        cassigned_to = ""
        cassigned_to_id = ""
        cnext_call_time = ""
        clast_call_time = ""

        if self.assigned_to:
            cassigned_to =  "%s" % (self.assigned_to.get_full_name() if self.assigned_to.get_full_name() else self.assigned_to.username)
            cassigned_to_id = self.assigned_to.id

        if self.next_call_time:
            cnext_call_time = "%s" % self.next_call_time.strftime("%d/%m/%Y %H:%M %p") if self.next_call_time else ""

        if self.last_call_time:
            clast_call_time = "%s" % self.last_call_time.strftime("%d/%m/%Y %H:%M %p") if self.next_call_time else ""

        if od.get('dob'):
            try:
                od['dob'] = datetime.datetime.strptime(od.get('dob'), "%d-%m-%Y")
                age = timesince(od['dob'])
            except:
                age = od['dob']
        else:
            age = None

        last_history = self.history.order_by('-created_on')
        if last_history:
            rvmap = putils.REV_DISTRIBUTION_MAP.copy()
            rvmap.update({
                'FRESH_CALLS': 'SYSTEM',
                'DUPLICATE_API' : 'SYSTEM',
                'LIMIT_EXCEEDED' : 'SYSTEM',
                'DONE' : 'SYSTEM',
                'PAYMENT_SUCCESSFUL' : 'SYSTEM',
            })
            last_call_disposition = rvmap[last_history[0].call_disposition]
        else:
            last_call_disposition = "NEW"

        dob = "NANANA"
        if od.get('dob'):
            try:
                dob = "{0}{1}-{2}{3}-{4}{5}{6}{7}".format(*od['dob']),
            except:
                print dob
        term = "NA"
        if  od.get('term_period'):
            term =  od.get('term_period')
        smoker = "NA"
        if  od.get('smoker'):
            smoker =  od.get('smoker')
        interval = "NA"
        if  od.get('interval'):
            interval =  od.get('interval')
        errcode=""
        if od.get('errcode'):
            errcode = od.get('errcode')
  #### 5820
        page_id =""
        if od.get('page_name'):
            pg_name = od.get('page_name').lower()
            try:
                page_id = putils.PAGE_WEIGHTAGE[pg_name][2]
            except Exception as e:
                print "Page error:", e
                pass
##### 5820        
        return_data = {
            'campaign' : self.campaign.name,
            'campaign_id' : self.campaign.id,
            'tracker_id' : od.get('tracker_id'),
            'first_name' : od.get('first_name'),
            'last_name' : od.get('last_name'),
            'email' : od.get('email'),
            'age' : age,
            'gender' : od.get('gender'),
            'page_name' : od.get('page_name'),
            'page_id':page_id,# 5820-h
            'weight':self.page_weight,# 5820-h                                        
            'sum_assured' : od.get('sum_assured'),
            'state' : od.get('state'),
            'city' : od.get('city'),
            'dob' : dob,
            'education' : od.get('education'),
            'mobile' : od.get('mobile'),
            'smoker' : smoker,
            'term_period' : term, 
            'interval' : interval, 
            'errcode':errcode,#payment errorcode
            'application_id' : self.application_id,
            'created_on' : self.created_on.strftime("%d %b'%y %I:%M %p"),
            'status' : "%s %s" % (self.get_status_display(), " Unfinished" if self.is_taken else ""),
            'assigned_to' : cassigned_to,
            'next_call_time' : cnext_call_time,
            'last_call_time' : clast_call_time,
            'pref_calltime':od.get('pref_calltime'), #6027
            'id' : self.id,
            'is_taken' : self.is_taken,
            'assigned_to_id' : cassigned_to_id,
            'in_emerge_status': self.in_emerge_status, 
            'emerge_transaction_end_time': self.emerge_transaction_end_time,
            'in_emerge': self.in_emerge,
            'tracker_channel':od.get('tracker_channel'), #6109
            'call_history_count' : "%s / %s" % (
                History.objects.filter(campaigndata=self).count(),
                History.objects.filter(campaigndata__customer=self.customer).count()
            ),
            'call_history_summary' : [ "%s | %s" % (h.get_main_disposition(), h.created_on.strftime("%d/%m/%Y")) for h in self.history.order_by('-created_on')[:4]],
            'last_call_disposition' : last_call_disposition,
            'accidentaldeath' : od.get('accidentaldeath'),
            'criticalillness' : od.get('criticalillness'),
            'hospitalcareillness' : od.get('hospitalcareillness'),
            'surgicalcare' : od.get('surgicalcare'),
            'accidentaldeathpre' : od.get('accidentaldeathpre'),
            'criticalillnesspre' : od.get('criticalillnesspre'),
            'hospitalcareillnesspre' : od.get('hospitalcareillnesspre'),
            'surgicalcarepre' : od.get('surgicalcarepre'),
            'riderdisc' : od.get('riderdisc'), #5842-D         
              #ADB New Rider Added 22 sept
            'accidentalDeathAndBenefitPlus': od.get('accidentalDeathAndBenefitPlus'),
            'accidentalDeathAndBenefitPlusPre': od.get('accidentalDeathAndBenefitPlusPre'),
            
            # 6733 wop rider 
            'waiverofPremium': od.get('waiverofPremium'),
            'waiverofPremiumpre': od.get('waiverofPremiumpre'),
            #6733 insurer data
            'ins_first_name':od1.get('ins_first_name',''),
            'ins_education':od1.get('ins_education',''),
            'ins_sum_assured':od1.get('ins_sum_assured',''),
            'ins_dob':od1.get('ins_dob',''),
            'ins_smoker':od1.get('ins_smoker',''),
            'ins_interval':od1.get('ins_interval',''),
            'ins_state':od1.get('ins_state',''),
            'ins_city':od1.get('ins_city',''),
            'ins_last_name':od1.get('ins_last_name',''),
            'ins_tracker_channel':od1.get('ins_tracker_channel',''),

            'ins_employer_name':od1.get('ins_employer_name',''),
            'ins_annual_income':od1.get('ins_annual_income',''),
            'ins_designation':od1.get('ins_designation',''),
            'ins_occupation':od1.get('ins_occupation',''),

            'product_name': self.product_name

        }
        cleaned_return_data = {}
        for k,v in return_data.items():
            if k in ['campaign', 'source', 'first_name', 'last_name', 'email', 'age', 'gender', 'action_type','mobile','application_id','banner_id', 'promo_id','product_code','site_id','fsc_channel','objective','page','status']:
                cleaned_return_data[k] = escape(v)
            else:
                cleaned_return_data[k] = v
        return cleaned_return_data

    def dispose_manually(self, status, next_call_time=None):
        status = status.upper()
        print "Status", status
        try:
            u = User.objects.get(username="system")
        except User.DoesNotExist:
            u = User.objects.create_user('system', 'system@glitterbug.in')
            u.first_name = "System"
            u.save()

        history = History(
            caller = u,
            call_time = datetime.datetime.now(),
            call_disposition = status,
            next_call_time = next_call_time,
            changed_data = "{}",
            
)
        history.save()
        self.history.add(history)
        self.last_call_disposition = status

        getattr(self, 'dispose_%s' % status)(None, None)
        self.status = "CONCLUDED"
        self.is_taken = False
        self.last_call_time = datetime.datetime.now()
        self.save()

    def save_call_form(self, request, call_form):
        #import pdb; pdb.set_trace()
        # Save customer related fields
        customer = self.customer
        customer.alt_numbers = call_form.cleaned_data.get('alt_numbers','')
        customer.name = call_form.cleaned_data.get('name','')
        customer.save()

        # Create Call history and save times and dispositions
        data = simplejson.loads(self.data)
        print self.status
        history = History(
            changed_data = simplejson.dumps(
                dict([(k,v) for k,v in call_form.cleaned_data.items() if call_form.cleaned_data[k] != data.get(k, None)]),
                cls = DjangoJSONEncoder
            ),
            caller = request.user,
            call_time = datetime.datetime.now(),
            call_disposition = call_form.cleaned_data['disposition'],
            next_call_time = call_form.cleaned_data.get('next_call_time'),
            call_status = self.status
            
        )
        history.save()
        self.history.add(history)

        # Update data with all call_form changes
        data.update(call_form.cleaned_data)
        self.data = simplejson.dumps(data, cls=DjangoJSONEncoder)

        # If last_call_disposition was duplicate, dispose this call as duplicate and conclude it
        # This will happen, if while the caller is making a call, another record for the same customer
        # enters the system, the call will get disposed 2 times as DUPLICATE, once by system, once by
        # the caller
        if self.last_call_disposition == 'DUPLICATE_API':
            call_form.cleaned_data['head_disposition'] = 'DUPLICATE_API'

        # Update dispositions and next_call_time for record
        getattr(self, 'dispose_%s' % call_form.cleaned_data['head_disposition'])(call_form, request)
        self.last_call_disposition = call_form.cleaned_data['disposition']
        self.last_call_head_disposition = call_form.cleaned_data['head_disposition']
        self.call_notes = call_form.cleaned_data['notes']
        self.is_taken = False
        self.last_call_time = datetime.datetime.now()
        self.save()

    def dispose_DONE(self, call_form, request):
        self.next_call_time = None
        self.status = 'CONCLUDED'

    def dispose_DUPLICATE_API(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_PAYMENT_SUCCESSFUL(self, call_form, request):
        print "PAyment dispose hit"
        self.dispose_DONE(call_form, request)
        
    def dispose_LIMIT_EXCEEDED(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_INTERESTED(self, call_form, request):
        if not call_form.cleaned_data.get('later_time'):
            self.next_call_time = datetime.datetime.now() + INTERESTED_NEXT_CALLTIME
        else:
            self.next_call_time = call_form.cleaned_data['later_time']
        self.status = 'IN_PROCESS'

    def dispose_NOT_CONTACTABLE(self, call_form, request):
        if not call_form.cleaned_data.get('later_time'):
            self.next_call_time = datetime.datetime.now() + FRESH_NEXT_CALLTIME
        else:
            self.next_call_time = call_form.cleaned_data['later_time']
        if call_form.cleaned_data.get('disposition') == "PAYMENT_MADE":
            self.status='CONCLUDED'
        else:
            self.status = 'IN_PROCESS'


    def dispose_CALLBACK_LATER(self, call_form, request):
        if not call_form.cleaned_data.get('later_time'):
            self.next_call_time = datetime.datetime.now() + FRESH_NEXT_CALLTIME
        else:
            self.next_call_time = call_form.cleaned_data['later_time']
        if call_form.cleaned_data.get('disposition') == "PAYMENT_MADE":
            self.status='CONCLUDED'
        else:
            self.status = 'IN_PROCESS'

    def dispose_NOT_INTERESTED(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_NONCONTACTABLE(self, call_form, request):
        self.next_call_time = datetime.datetime.now() + FRESH_NEXT_CALLTIME
        self.status = 'IN_PROCESS'

    def dispose_NOT_ELIGIBLE(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_LOST_CASES(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_DO_NOT_CALL(self, call_form, request):
        self.dispose_DONE(call_form, request)

    def dispose_PAYMENT_RECEIVED(self, call_form, request):
        self.dispose_DONE(call_form, request)
     
