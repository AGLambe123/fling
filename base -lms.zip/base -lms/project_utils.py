import os
import datetime
from collections import OrderedDict
import string
from django.db.models import Q
from operator import itemgetter

NUMBER_CHOICES = [(i,i) for i in range(0,11)]
NUMBER_CHOICES.append((" ","--"))

EMERGE_STATUS = (
    ('MOBILE','MOBILE'),
    ('APPID','APPID'),
)

EVENT_TYPES = (
    ('COFFEE','Coffee'),
    ('TOILET','Toilet'),
    ('MUSHROOM','Mushroom'),
)

USER_ROLES = (
    ('CALLER', 'CALLER'),
    ('MANAGER', 'MANAGER'),
    ('REPORT', 'REPORT'),
    ('UPLOAD', 'UPLOAD'),
    ('ADMIN', 'ADMIN'),
)

DROP_OFF_AUTO_NOTES = (
    ('','-------------'),
    ('FAKE_ENTRY','Customer was just playing'),
    ('CUSTOMER_NOT_INTERESTED','Customer is not interested'),
    ('CUSTOMER_NO_CREDIT_CARD','Customer has no Credit Card'),
    ('CUSTOMER_FACING_BROWSER_ISSUES','Customer Facing browser issues'),
    ('ILLITERATE_CUSTOMER','Customer is illiterate'),
)

VERBOSE_DROP_OFF_AUTO_NOTES = dict([(k,v) for k,v in DROP_OFF_AUTO_NOTES])

#### SYSTEM DISPOSITIONS
# DUPLICATE_API
# LIMIT_EXCEEDED
# PAYMENT_SUCCESSFUL

DISPOSITION_DB = {
    'PAYMENT_RECEIVED': {
            'sub_disposition': [('PAYMENT_RECEIVED', 'Payment Received', False)]
    },
    'CALLBACK_LATER': {
            'sub_disposition': [('CALLBACK_LATER', 'Callback Later', True),
                                ('NOT_CONTACTABLE ', 'Not Contactable', True),
                                ('CALL_BACK', 'Call Back Non Contactable', True)] #new
    },
    'DO_NOT_CALL': {
        'sub_disposition': [('DO_NOT_CALL', 'Do Not Call', True),
                            ('WRONG_NUMBER', 'Wrong Number', True),
                            ('DUMMY_CASE', 'Dummy Case', True)]
    },
    'INTERESTED': {
        'sub_disposition': [('INTERESTED', 'Interested', False),
                            ('DECISION_PENDING', 'Decision Pending', True),
                            ('PAYMENT_PENDING', 'Payment Pending', True),
                            ('APPLICATION_NOT_FOUND', 'Application Not Found', True),
                            ('PAYMENT_NOT_RECEIVED', 'Payment Not Received', True),
                            ('PAYMENT_RECEIVED_CALL', 'Payment Received - Call', False),
                            ('INTERESTED_NONCONTACTABLE', 'Non-Contactable', True),
                            ('SEND_ADVISOR', 'Send me an Advisor', True),
                            ('PAYMENT_MADE', 'Payment Made', True)]
    },
    'LOST_CASES': {
        'sub_disposition': [('LOST_CASES', 'Lost Cases', False),
                            ('ALREADY_PURCHASED_PRODUCT', 'Already Purchased Product', True),
                            ('NOT_ASSISTED', 'Not Assisted', True),
                            ('DUPLICATE_SOURCE', 'Duplicate Source', True),
                            ('SOLD_BY_AGENT', 'Sold By Agent', True)]
    },
    'NONCONTACTABLE': {
        'sub_disposition': [('NONCONTACTABLE', 'Noncontactable', False),
                            ('CALL_DROPPED', 'Call Dropped', True),
                            ('BUSY', 'Busy', True),
                            ('ENGAGED', 'Engaged', True),
                            ('OUT_OF_COVERAGE', 'Out Of Coverage', True),
                            ('RINGING', 'Ringing', True),
                            ('SWITCHED_OFF', 'Switched Off', True),
                            ('FAILED_CONTACT', 'Failed Contact', True),
                            ('INVALID_NO.', 'Invalid No.', True)] #new 
    },
    'NOT_ELIGIBLE': {
        'sub_disposition': [('NOT_ELIGIBLE', 'Not Eligible', False),
                            ('DUPLICATE', 'Duplicate', True),
                            ('NOT_ELIGIBLE_CITY', 'Not Eligible City', True),
                            ('NOT_ELIGIBLE_PAYMENT', 'Not Eligible Payment', True),
                            ('NOT_ELIGIBLE_PROFILE', 'Not Eligible Profile', True)]
    },
    'NOT_INTERESTED': {
        'sub_disposition': [('NOT_INTERESTED', 'Not Interested', False),
                            ('ALREADY_PURCHASED_NON_BSLI', 'Already Purchased Non BSLI', True),
                            ('DIDNT_FILL_LEAD', 'Didnt Fill Lead', True),
                            ('INTERESTED_IN_COMPETITION', 'Interested In Competition', True),
                            ('JUST_CHECKING', 'Just Checking', True),
                            ('WANTS_AGENT', 'Wants Agent', True),
                            ('WANTS_CRITICAL_ILLNESS_RIDER', 'Wants Critical Illness Rider', True), #new
                            ('WANTS_DISABILITY_RIDER', 'Wants Disability Rider', True),
                            ('WANTS_MONEY_BACK_POLICY', 'Wants Money Back Policy', True),
                            ('WANTS_PREMIUM_WAIVER_RIDER', 'Wants Premium Waiver Rider', True),
                                                                                        
                            ('WANTS_MORE_POLICY_TERM', 'Wants More Policy Term', True),
                            ('WANTS_ADBR_RIDER', 'Wants ADBR Rider', True),
                            ('WANTS_INCOME_BENEFIT_RIDER', 'Wants Income Benefit Rider', True),
                            ('DOES_N0T_HAVE_SUITABLE_DC', 'Doesnt Have Suitable DC', True),
                            ('EXISTING_POLICY_ENQUIRY', 'Wants Existing Policy Enquiry', True), #remove wants from key
                            ('INTERESTED_FOR_CHILD_PLAN', 'Wants Child Plan', True), 
                            ('INTERESTED_FOR_BANK_PLAN', 'Money Bank Plan', False), #add 
                            ('INTERESTED_FOR_PENSION_PLAN', 'Wants Pension Plan', True), 
                            ('INTERESTED_FOR_ALREADY_PURCHASED_BSLI', 'Already Purchased BSLI', True), 
                            ('INTERESTED_FOR_LANGUAGE_BARRIER', 'Language Barrier', True),                             
                            ('WANTS_MORE_TERM_PLAN', 'Wants More Term', True),
                            ('WANTS_LESS_PREMIUM__PLAN', 'Wants Less Premium', True)] #add one more _ before plan  
        }
}

DISPOSITION_MAP = dict([(k, [i[0] for i in v['sub_disposition'] if i[2]]) for k,v in DISPOSITION_DB.items()])

VISIBLE_DISPOSITION_MAP = dict([(k, [i[0] for i in v['sub_disposition'] if i[2]]) for k,v in DISPOSITION_DB.items()])
VISIBLE_DISPOSITION_MAP.pop('PAYMENT_RECEIVED')

REV_DISTRIBUTION_MAP = dict([(i[0],k) for k,v in DISPOSITION_DB.items() for i in v['sub_disposition'] if i[2] !=False])

REV_DISTRIBUTION_MAP_ALL = dict([(i[0],k) for k,v in DISPOSITION_DB.items() for i in v['sub_disposition']]) #add

DISPOSITIONS  = [(k[0], k[1]) for sublist in [i['sub_disposition'] for i in DISPOSITION_DB.values()] for k in sublist]

VERBOSE_DISPOSITION  = dict([(k[0], k[1]) for sublist in [i['sub_disposition'] for i in DISPOSITION_DB.values()] for k in sublist])

CAMPAIGN_DATA_STATUS = (
    ("FRESH", "Fresh"),
    ("IN_PROCESS", "In Process"),
    ("CONCLUDED", "Concluded"),
)

## [ API_KEY, key, Verbose Name, Default Value ]

FIELD_LIST = [
    [ 'app_id', 'application_id', 'Application ID', "str" ],
    [ 'tracker_id', 'tracker_id', 'Tracker ID', "str" ],
    [ 'page_name', 'page_name', 'Page Name', "str" ],

    [ 'sum_assured', 'sum_assured', 'Sum Assured', "str" ],
    [ 'annual_premium', 'annual_premium', 'Annual Premium', "str" ],

    [ 'first_name', 'first_name', 'First Name', "str" ],
    [ 'last_name', 'last_name', 'Last Name', "str" ],
    [ 'gender', 'gender', 'Gender', "str" ],
    [ 'dob', 'dob', 'Date of Birth', "str" ],
    [ 'marital_status', 'marital_status', 'Marital Status', "str" ],
    [ 'nationality', 'nationality', 'Nationality', "str" ],
    [ 'education', 'education', 'Education', "str" ],
    [ 'mobile_no', 'mobile', 'Mobile', "str" ],
    [ 'business_nature', 'org_type', 'Organisation Type', "str" ],
   
    [ 'occupation', 'occupation', 'Occupation', "str" ],
    [ 'designation' ,'designation', 'Designation', "str" ],
    [ 'annual_income', 'annual_income', 'Annual Income', "str" ],

    [ 'father_name', 'father_name', 'Fathers name', "str" ],
    [ 'pan_no', 'pancard_number', 'PAN number', "str" ],
    [ 'uid_no', 'uid_number', 'UID number', "str" ],
  
    [ 'email_id', 'email', 'Email', "str" ],

    [ 'flat', 'flat', 'Flat', "str" ],
    [ 'building', 'building', 'Building', "str" ],
    [ 'road', 'road', 'Road', "str" ],
    [ 'area', 'area', 'Area', "str" ],
    [ 'landmark', 'landmark', 'Landmark', "str" ],
    [ 'pincode', 'pincode', 'Pincode', "str" ],
    [ 'state', 'state', 'State', "str" ],
    [ 'city', 'city', 'City', "str" ],
    [ 'landline', 'landline', 'Landline', "str" ],

    [ 'p_flat', 'p_flat', 'Permanent Flat', "str" ],
    [ 'p_building', 'p_building', 'Permanent Building', "str" ],
    [ 'p_road', 'p_road', 'Permanent Road', "str" ],
    [ 'p_area', 'p_area', 'Permanent Area', "str" ],
    [ 'p_landmark', 'p_landmark', 'Permanent Landmark', "str" ],
    [ 'p_pincode', 'p_pincode', 'Permanent Pincode', "str" ],
    [ 'p_state', 'p_state', 'Permanent State', "str" ],
    [ 'p_city', 'p_city', 'Permanent City', "str" ],
    [ 'p_landline', 'p_landline', 'Permanent Landline', "str" ],

    [ 'birth_state', 'birth_state', 'Birth State', "str" ],
    [ 'birth_city', 'birth_city', 'birth City', "str" ],
    [ 'employer_name', 'employer_name', 'Employer', "str" ],
    [ 'duty_nature', 'duty_nature', 'Nature of Duty', "str" ],
    [ 'years_withemployer', 'years_withemployer', 'Years with employer', "str" ],
    [ 'months_withemployer', 'months_withemployer', 'Months with employer', "str" ],

    [ 'eia_number', 'eia_number', 'EIA number', "str" ],
    [ 'ir_name', 'ir_name', 'IR Name', "str" ],
    [ 'ir_emailid', 'ir_emailid', 'IR email', "str" ], 
    [ 'pay_amount', 'pay_amount', 'Pay Amount', "str" ],
    [ 'id_proof', 'id_proof', 'ID Proof', "str" ],
    [ 'age_proof', 'age_proof', 'Age Proof', "str" ],  # 6733
    [ 'address_proof', 'address_proof', 'Address Proof', "str" ],
    [ 'income_proof', 'income_proof', 'Income Proof', "str" ],
    [ 'pay_status', 'pay_status', 'Payment Status', "str" ],    
    [ 'term_period', 'term_period', 'Term period', "str" ],
    [ 'smoker', 'smoker', 'Smoker Status', "str" ],
    [ 'interval', 'interval', 'Interval', "str" ],
    [ 'online_created_date', 'online_created_date', 'Online Created Date', "str" ],
    [ 'errcode', 'errcode', 'Error Code', "str" ],
    [ 'oneshotpayment', 'oneshotpayment', 'Payment', "str" ],
    [ 'tracker_source', 'tracker_source', 'Tracker Source', "str" ], #6109
    [ 'tracker_channel', 'tracker_channel', 'Tracker Channel', "str" ], #6109
    [ 'tracker_campaign', 'tracker_campaign', 'Tracker Campaign', "str" ], #6109

    [ 'accidentaldeath', 'accidentaldeath', 'Accident Rider', "str" ], # 5842-D riders start
    [ 'criticalillness', 'criticalillness', 'Critical Rider', "str" ],
    [ 'hospitalcareillness', 'hospitalcareillness', 'Health Rider', "str" ],
    [ 'surgicalcare', 'surgicalcare', 'Surgical Rider', "str" ],
    [ 'accidentalDeathAndBenefitPlus', 'accidentalDeathAndBenefitPlus', 'Accidental Death And Benefit Rider', "str"], ###  new ADB rider plus

    [ 'accidentaldeathpre', 'accidentaldeathpre', 'Accident Premium', "str" ],
    [ 'criticalillnesspre', 'criticalillnesspre', 'Critical Premium', "str" ],
    [ 'hospitalcareillnesspre', 'hospitalcareillnesspre', 'Health Premium', "str" ],
    [ 'surgicalcarepre', 'surgicalcarepre', 'Surgical Premium', "str" ],

    [ 'accidentalDeathAndBenefitPlusPre', 'accidentalDeathAndBenefitPlusPre', 'Accidental Death And Benefit Premium', "str"], ###  new ADB rider Pre    

    [ 'waiverofPremium', 'waiverofPremium', 'Waiver of Premium ', "str"],   # 6733 new WOP Rider cover
    [ 'waiverofPremiumpre', 'waiverofPremiumpre', 'Waiver of Premium ', "str"],   # 6733 new WOP Rider cover



    [ 'riderdisc', 'riderdisc', 'Rider Discount', "str" ], # 5842-D riders end ######
    [ 'pref_calltime', 'pref_calltime', 'Pref call time', "str" ], #6027 mobile lead ####

    ['policyno_quote', 'policyno_quote', 'Policy number',"str"],#5826 existingC                                                                                        
    ['clientid_quote', 'clientid_quote', 'Client ID',"str"],#5826 existingC                                                                                            
    ['firstname_quote', 'firstname_quote', 'First Name Quote',"str"],#5826 existingC                                                                                   
    ['lastname_quote', 'lastname_quote', 'Last Name Quote',"str"],#5826 existingC                                                                                      
    ['emailaddress_quote', 'emailaddress_quote', 'Email Id Quote',"str"],#5826 existingC                                                                               
    ['mobile_quote', 'mobile_quote', 'Mobile Quote',"str"],#5826 existingC                                                                                             
    ['dob_quote', 'dob_quote', 'Dob Quote',"str"],#5826 existingC                                                                                                      
    ['gender_quote', 'gender_quote', 'Gender Quote',"str"],#5826 existingC                                                                                             
    ['smoker_quote', 'smoker_quote', 'Smoker Quote',"str"],#5826 existingC                                                                                             
    ['sumassured_quote', 'sumassured_quote', 'Sum Assured Quote',"str"],#5826 existingC                                                                                
    ['sumassuredtype_quote', 'sumassuredtype_quote', 'Sum Assured Type Quote',"str"],#5826 existingC                                                                   
    ['interval_quote', 'interval_quote', 'Interval Quote',"str"],#5826 existingC                                                                                       
    ['termperiod_quote', 'termperiod_quote', 'Term period Quote',"str"],#5826 existingC                                                                                
    ['premiumfrequency_quote', 'premiumfrequency_quote', 'Premium Freq Quote',"str"],#5826 existingC                                                                   
    ['premiummode_quote', 'premiummode_quote', 'Premium Mode Quote',"str"],#5826 existingC                                                                             
    ['accidentaldeath_quote', 'accidentaldeath_quote', 'Accidental Quote',"str"],#5826 existingC                                                                       
    ['criticalillness_quote', 'criticalillness_quote', 'Critical Illness Quote',"str"],#5826 existingC                                                                 
    ['surgicalcare_quote', 'surgicalcare_quote', 'Surgical Quote',"str"],#5826 existingC                                                                               
    ['hospitalcareillness_quote', 'hospitalcareillness_quote', 'Hospital Care Quote',"str"],#5826 existingC                                                            
    ['kycflag_quote', 'kycflag_quote', 'Kyc Flag Quote',"str"],#5826 existingC                                                                                         
    ['medicalflag_quote', 'medicalflag_quote', 'Medical Flag Quote',"str"],#5826 existingC  

    ['web_id', 'web_id', 'Web ID', "str"], #6346                                                                                                                      
    ['web_source', 'web_source', 'Web Source', "str"], #6346 

    [ 'Dummy', 'dummy', 'dummy', "str"], # Dummy field to catch all
    

]

API_FIELD_DICT = dict([(i[0],i[1]) for i in FIELD_LIST])
VERBOSE_FIELD_DICT = OrderedDict([(i[1],i[2]) for i in FIELD_LIST])
#5820
PAGE_WEIGHTAGE = {
    'empty':[0,"-----",0],
    '/buy-term-insurance-online/upload/index':[4,'Upload',1], # add new page
    #'/upload/index':[4,'Upload',1], old name
    '/buy-term-insurance-online/calculator/calculatepremium':[5,'LP 5',2],
    '/buy-term-insurance-online/calculator/calculatepremiumdetails':[10,'LP 10',3],
    '/buy-term-insurance-online/applicationfill/lifeinsurer':[15,'Life Insurer',4],
    '/buy-term-insurance-online/applicationfill/contactinfo':[20,'Contact Info',5],
    '/buy-term-insurance-online/applicationfill/eiadetails':[30,'EIADetails',6],
    '/buy-term-insurance-online/applicationfill/nominee':[40,'Nominee',7],
    '/buy-term-insurance-online/applicationfill/medicalquestions':[50,'Medical Question',8],
    '/buy-term-insurance-online/applicationfill/medical_questions_2_4':[60,'Medical Questions 2 4',9],
    '/buy-term-insurance-online/applicationfill/medical_questions_3_4':[70,'Medical Questions 3 4',10],
    '/buy-term-insurance-online/applicationfill/medical_questions_4_4':[80,'Medical Questions 4 4',11],
    '/buy-term-insurance-online/preview/index':[90,'Preview Index',12],
    '/buy-term-insurance-online/preview':[90,'Preview',13],
    '/buy-term-insurance-online/payment/payment_error':[100,'Payment error',14],
    '/buy-term-insurance-online/payment/index':[100,'Payment Index',15],
    '/payment/index':[100,'Payment',16]
    }

PAGE_CHOICES = [(v[2],v[1]) for d,v in PAGE_WEIGHTAGE.items()]
PAGE_CHOICES = sorted(PAGE_CHOICES,key=itemgetter(0),reverse=True)
PAGE_CHOICES.pop()
PAGE_CHOICES.insert(0,("","------"))
#5820

def get_file_path(instance, filename):
    now = datetime.datetime.now()
    monthdir = now.strftime("%Y-%m")
    newfilename = os.path.splitext(filename)[0] + datetime.datetime.now().strftime("-%d-%H-%M") + os.path.splitext(filename)[1]
    path_to_save = "uploads/%s/%s" % (monthdir, newfilename)
    return path_to_save

import re
black_list = ['test','quality','qk','abc','adf','asd','asf','dfd','dfg','dgf','fdg','fgd','fgh','fgv','fsd','gde','gdf','gfd','gsd','hjk','pks','pqr','sdf','sdg','sds','xyz','aaa','bbb','ccc','ddd','eee','fff','ggg','hhh','iii','jjj','kkk','lll','mmm','nnn','ooo','ppp','qqq','rrr','sss','ttt','uuu','vvv','www','xxx','yyy','zzz','ega']
to_reject = re.compile("|".join(black_list))

def reject_data(fdata,insurer):
    from core.models import Campaign, CampaignData, Customer
    # from core.models import Userdeinfed
    # DNC
    # TBD
    #
   
    if fdata.get('pay_status','') in ['success','true']: # manually dispose all cases of this customer
        cu = Customer.objects.filter(mobile=fdata.get('mobile'))
        cds_disposed = []
        if cu:
            cu = cu[0]
            for cd in CampaignData.objects.filter(Q(customer=cu) & ~Q(status="CONCLUDED")):
                cds_disposed.append(cd.application_id)
                cd.dispose_manually("PAYMENT_SUCCESSFUL")
            print "Disposed PAYMENT_SUCCESSFUL", cds_disposed
        reason = "Payment Status = True, Disposed PAYMENT_SUCCESSFUL = ", ",".join(cds_disposed)
        return (True, reason)

    try:        
        match_name = to_reject.search(fdata.get('first_name','').lower())
    except:
        reason = "First Name Testing failed" 
        return (True, reason)

    if match_name:
        reason = "First Name Testing failed %s for position %s" % (match_name.group(), str(match_name.span()))
        return (True, reason)

    try:        
        if fdata.get('mobile').lower() in ['9999999999','9898989898','9892098920','9820098200','9892012345','9797979797','9696969696','9876543210','9090909090', '8800000000','0']:
            reason = "Mobile Number is blacklisted"
            return (True, reason)
    except:
        reason = "Mobile Number does not exist"
        return (True, reason)


    # start here - special charactor remove project - vapt
    #try:
    #    dump = fdata.copy()
    #    list1 = ["tracker_details",
    #             "medicalquestion_details",
    #             "online_created_date",
    #             "familymedicalhistory_details",
    #             "diabetescontrol_details",
    #             "recent_bplevel",
    #             "diabetes_datediagnosed",
    #             "diabetessugarmeasurement",
    #             "diabetes_doctorlastseen"]

    #    for rm in list1:
    #        del(dump[rm])

    #    for k,v in  dump.items():
    #            if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;'\[\]]", str(v)):
    #                print "special charactor present in Dict %s",str(k)
    #                reason =  "special charactor present in LMS Input Json %s" % (str(k))
    #                return (True,reason)

    #except:
    #   reason = "Special Charactor present"
    #    return (True,reason)

    #import simplejson
    
    # insurer  Json logic VAPT
    #if insurer != "":
    #    try:
    #        ins_dump = simplejson.loads(insurer)

    #        ins_dumpdata = ins_dump.copy()
    #        ins_list = ["ins_tracker_details",
    #                    "ins_medicalquestion_details",
    #                    "ins_online_created_date",
     #                   "ins_familymedicalhistory_details",
    #                    "ins_diabetescontrol_details",
    #                    "ins_recent_bplevel",
     #                   "ins_diabetes_datediagnosed",
      #                  "ins_diabetessugarmeasurement",
       #                 "ins_diabetes_doctorlastseen"]
            
     #       for ins_remove in ins_list:
     #           del(ins_dumpdata[ins_remove])
                
     #       for ins_key,ins_value in  ins_dumpdata.items():
     #           if re.search(r"[~\!#\$%\^&\*\(\)\+{}\":;'\[\]]", str(ins_value)):
     #               print "special charactor present in Dict %s",str(ins_key)
     #               reason =  "special charactor present in LMS Insurer Input Json %s" % (str(ins_key))
     #               return (True,reason)

     #   except:
     #       reason = "Special Charactor present in Insurer Json header"
     #       return (True,reason)

        
    # end here VAPT remove specail charactor project

    #if CampaignData.objects.filter(application_id=fdata.get('application_id','XYZ12345!@#')):'
    #    reason = "Application ID exists in the system"
    #    return (True, reason)
    return (False, "")

def excel_column(n,res):
    if n < 26:
        return string.uppercase[n]+res
    else:
        rem = n%26
        res = string.uppercase[rem]+res
        n = n/26-1
        return excel_column(n, res)

PSM_FIELD_MAP =  {
    0 : u'dummy',
    1 : u'application_id',
    2 : u'icb_id',
    3 : u'first_name',
    4 : u'last_name',
    5 : u'gender',
    6 : u'dob_dd',
    7 : u'dob_mm',
    8 : u'dob_yy',
    9 : u'marital_status',
    10 : u'nationality',
    11 : u'education',
    12 : u'occupation',
    13 : u'organisation_type',
    14 : u'designation',
    15 : u'annual_income',
    16 : u'dummy',
    17 : u'address1',
    18 : u'address2',
    19 : u'landmark',
    20 : u'city',
    21 : u'pincode',
    22 : u'state',
    23 : u'dummy',
    24 : u'email',
    25 : u'mobile',
    26 : u'std',
    27 : u'landline',
    28 : u'dummy',
    29 : u'dummy',
    30 : u'dummy',
    31 : u'dummy',
    32 : u'dummy',
    33 : u'dummy',
    34 : u'dummy',
    35 : u'dummy',
    36 : u'dummy',
    37 : u'dummy',
    38 : u'dummy',
    39 : u'dummy',
    40 : u'dummy',
    41 : u'dummy',
    42 : u'dummy',
    43 : u'dummy',
    44 : u'agent_code',
    45 : u'dummy',
    46 : u'dummy',
    47 : u'dummy',
    48 : u'dummy',
    49 : u'dummy',
    50 : u'dummy',
    51 : u'dummy',
    52 : u'dummy',
    53 : u'dummy',
    54 : u'dummy',
    55 : u'dummy',
    56 : u'dummy',
    57 : u'dummy',
    58 : u'dummy',
    59 : u'dummy',
    60 : u'dummy',
    61 : u'dummy',
    62 : u'dummy',
    63 : u'dummy',
    64 : u'dummy',
    65 : u'dummy',
    66 : u'dummy',
    67 : u'dummy',
    68 : u'dummy',
    69 : u'dummy',
    70 : u'dummy',
    71 : u'dummy',
    72 : u'dummy',
    73 : u'dummy',
    74 : u'dummy',
    75 : u'industry_type',
    76 : u'dummy',
    77 : u'dummy',
    78 : u'dummy',
    79 : u'dummy',
    80 : u'dummy',
    81 : u'dummy',
    82 : u'dummy',
    83 : u'dummy',
    84 : u'dummy',
    85 : u'dummy',
    86 : u'dummy',
    87 : u'dummy',
    88 : u'dummy',
    89 : u'dummy',
    90 : u'dummy',
    91 : u'dummy',
    92 : u'dummy',
    93 : u'dummy',
    94 : u'dummy',
    95 : u'dummy',
    96 : u'product_code',
    97 : u'source',
    98 : u'dummy',
    99 : u'dummy',
    100 : u'bre_decision',
    101 : u'dummy',
    102 : u'dummy',
    103 : u'sum_assured',
    104 : u'annual_premium',
    105 : u'dummy',
    106 : u'banner_id',
    107 : u'promo_id',
    108 : u'fsc_channel',
    109 : u'site_id',
    110 : u'dummy',
    111 : u'dummy',
    112 : u'dummy',
    113 : u'payment_amount',
    114 : u'payment_type',
    115 : u'payment_gateway',
    116 : u'dummy',
    117 : u'dummy',
    118 : u'dummy',
    119 : u'created_on',
    120 : u'payment_status',
    121 : u'payment_reason',
    122 : u'dummy',
    123 : u'transaction_id',
    124 : u'payment_bank',
    125 : u'dummy',
    126 : u'dummy',
    127 : u'dummy',
    128 : u'dummy',
}

NEWSYSTEM_FIELD_MAP = {
    0 : u'application_id',
    1 : u'agent_code',
    2 : u'bre_decision',
    3 : u' bre_decision_date',
    4 : u'created_on',
    5 : u'dummy',
    6 : u'dummy',
    7 : u'lead_id',
    8 : u'page',
    9 : u'dummy',
    10 : u'product_code',
    11 : u'dummy',
    12 : u'dummy',
    13 : u'dummy',
    14 : u'dummy',
    15 : u'dummy',
    16 : u'dummy',
    17 : u'payment_bank',
    18 : u'dummy',
    19 : u'dummy',
    20 : u'dummy',
    21 : u'dummy',
    22 : u'dummy',
    23 : u'dummy',
    24 : u'payment_reason',
    25 : u'dummy',
    26 : u'dummy',
    27 : u'dummy',
    28 : u'dummy',
    29 : u'payment_type',
    30 : u'dummy',
    31 : u'dummy',
    32 : u'payment_status',
    33 : u'payment_status',
    34 : u'policy_name',
    35 : u'dummy',
    36 : u'dummy',
    37 : u'dummy',
    38 : u'source',
    39 : u'dummy',
    40 : u'payment_amount',
    41 : u'transaction_id',
    42 : u'dummy',
    43 : u'dummy',
    44 : u'dummy',
    45 : u'dummy',
    46 : u'dummy',
    47 : u'dummy',
    48 : u'dummy',
    49 : u'dummy',
    50 : u'dummy',
    51 : u'dummy',
    52 : u'dummy',
    53 : u'dummy',
    54 : u'dummy',
    55 : u'dummy',
    56 : u'dummy',
    57 : u'dummy',
    58 : u'dummy',
    59 : u'dummy',
    60 : u'dummy',
    61 : u'dummy',
    62 : u'dummy',
    63 : u'dummy',
    64 : u'dummy',
    65 : u'dummy',
    66 : u'dummy',
    67 : u'fsc_channel',
    68 : u'dummy',
    69 : u'site_id',
    70 : u'banner_id',
    71 : u'promo_id',
    72 : u'dummy',
    73 : u'dummy',
    74 : u'dummy',
    75 : u'dummy',
    76 : u'dummy',
    77 : u'dummy',
    78 : u'dummy',
    79 : u'dummy',
    80 : u'dummy',
    81 : u'dummy',
    82 : u'dummy',
    83 : u'dummy',
    84 : u'dummy',
    85 : u'first_name',
    86 : u'middle_name',
    87 : u'last_name',
    88 : u'landline',
    89 : u'mobile',
    90 : u'email',
    91 : u'dob',
    92 : u'marital_status',
    93 : u'gender',
    94 : u'dummy',
    95 : u'dummy',
    96 : u'dummy',
    97 : u'dummy',
    98 : u'dummy',
    99 : u'dummy',
    100 : u'nationality',
    101 : u'dummy',
    102 : u'dummy',
    103 : u'dummy',
    104 : u'dummy',
    105 : u'dummy',
    106 : u'dummy',
    107 : u'dummy',
    108 : u'dummy',
    109 : u'dummy',
    110 : u'dummy',
    111 : u'dummy',
    112 : u'dummy',
    113 : u'dummy',
    114 : u'dummy',
    115 : u'dummy',
    116 : u'dummy',
    117 : u'dummy',
    118 : u'dummy',
    119 : u'dummy',
    120 : u'dummy',
    121 : u'dummy',
    122 : u'dummy',
    123 : u'dummy',
    124 : u'dummy',
    125 : u'dummy',
    126 : u'dummy',
    127 : u'dummy',
    128 : u'dummy',
    129 : u'dummy',
    130 : u'dummy',
    131 : u'dummy',
    132 : u'dummy',
    133 : u'address1',
    134 : u'address2',
    135 : u'address3',
    136 : u'city',
    137 : u'state',
    138 : u'pincode',
    139 : u'dummy',
    140 : u'dummy',
    141 : u'dummy',
    142 : u'dummy',
    143 : u'dummy',
    144 : u'landmark',
    145 : u'dummy',
    146 : u'dummy',
    147 : u'dummy',
    148 : u'dummy',
    149 : u'dummy',
    150 : u'dummy',
    151 : u'dummy',
    152 : u'dummy',
    153 : u'dummy',
    154 : u'dummy',
    155 : u'dummy',
    156 : u'dummy',
    157 : u'annual_income',
    158 : u'dummy',
    159 : u'dummy',
    160 : u'dummy',
    161 : u'objective',
    162 : u'dummy',
    163 : u'dummy',
    164 : u'dummy',
    165 : u'dummy',
    166 : u'dummy',
    167 : u'dummy',
    168 : u'dummy',
    169 : u'dummy',
    170 : u'dummy',
    171 : u'dummy',
    172 : u'dummy',
    173 : u'dummy',
    174 : u'dummy',
    175 : u'dummy',
    176 : u'dummy',
    177 : u'occupation',
    178 : u'organisation_type',
    179 : u'industry_type',
    180 : u'organisation_name',
    181 : u'dummy',
    182 : u'industry_type',
    183 : u'dummy',
    184 : u'dummy',
    185 : u'sum_assured',
    186 : u'annual_premium',
    187 : u'total_premium',
    188 : u'dummy',
    189 : u'dummy',
    190 : u'dummy',
    191 : u'dummy',
    192 : u'dummy',
    193 : u'dummy',
    194 : u'dummy',
    195 : u'dummy',
    196 : u'dummy',
    197 : u'dummy',
    198 : u'dummy',
    199 : u'dummy',
    200 : u'dummy',
    201 : u'dummy',
    202 : u'dummy',
    203 : u'dummy',
}
